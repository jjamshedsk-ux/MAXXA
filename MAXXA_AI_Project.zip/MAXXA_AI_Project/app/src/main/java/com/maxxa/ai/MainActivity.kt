package com.maxxa.ai

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { MaxxaScreen(this) }
    }
    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault() }
    fun speak(text: String) { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "maxxa_reply") }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}

@Composable
private fun MaxxaScreen(activity: MainActivity) {
    val context = activity
    var input by remember { mutableStateOf("") }
    var torchOn by remember { mutableStateOf(false) }
    var messages by remember { mutableStateOf(listOf("MAXXA AI: Namaste! Main tumhara assistant hoon. Abhi basic demo mode mein hoon.")) }
    val cameraManager = remember { context.getSystemService(Context.CAMERA_SERVICE) as CameraManager }
    val cameraId = remember { cameraManager.cameraIdList.firstOrNull { id -> cameraManager.getCameraCharacteristics(id).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true } }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF9C8DF5), background = Color(0xFF10131B), surface = Color(0xFF1B2030))) {
        Column(Modifier.fillMaxSize().background(Color(0xFF10131B)).padding(18.dp)) {
            Text("MAXXA AI", color = Color(0xFFB8AEFF), fontSize = 28.sp)
            Text("Your smart Android assistant", color = Color.LightGray, fontSize = 13.sp)
            Spacer(Modifier.height(16.dp))
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(messages) { msg -> Surface(color = Color(0xFF202638), shape = RoundedCornerShape(14.dp)) { Text(msg, color = Color.White, modifier = Modifier.padding(12.dp)) } }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), label = { Text("Ask MAXXA...") }, singleLine = true)
                Button(onClick = {
                    if (input.isNotBlank()) {
                        val question = input.trim()
                        val reply = "Abhi main demo mode mein hoon. Gemini AI connect karne ke liye API key aur network integration configure karna hoga. Tumne poocha: $question"
                        messages = messages + "You: $question" + "MAXXA AI: $reply"
                        activity.speak(reply); input = ""
                    }
                }) { Text("Send") }
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(modifier = Modifier.weight(1f), onClick = {
                    try {
                        if (cameraId != null) { torchOn = !torchOn; cameraManager.setTorchMode(cameraId, torchOn) }
                        else messages = messages + "MAXXA AI: Is device par flashlight available nahi hai."
                    } catch (_: Exception) { messages = messages + "MAXXA AI: Flashlight access nahi ho saka." }
                }) { Text(if (torchOn) "Torch OFF" else "Torch ON") }
                OutlinedButton(modifier = Modifier.weight(1f), onClick = {
                    if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        messages = messages + "MAXXA AI: Microphone permission allow karo, phir voice feature add/configure kiya ja sakta hai."
                    } else {
                        messages = messages + "MAXXA AI: Voice input ke liye speech recognition flow abhi configure karna baaki hai."
                    }
                }) { Text("Voice") }
            }
            Spacer(Modifier.height(8.dp))
            Text("Starter project • Gemini API not connected yet", color = Color.Gray, fontSize = 11.sp)
        }
    }
}
