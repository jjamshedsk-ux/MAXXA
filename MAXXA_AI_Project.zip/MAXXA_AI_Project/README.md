# MAXXA AI Android starter

This is a starter Android Studio/Gradle project for MAXXA AI. It includes a Jetpack Compose interface, text-to-speech responses, and a basic flashlight toggle. It is **not** a complete Gemini-powered assistant yet: Gemini API networking and speech recognition still need to be implemented and tested.

## Build in Termux

1. Extract this ZIP into a folder.
2. Confirm `ANDROID_HOME` points to a valid Android SDK and `java -version` works.
3. From this project directory run:

```sh
gradle assembleDebug
```

4. APK output (if build succeeds): `app/build/outputs/apk/debug/app-debug.apk`

If Android SDK platform 35 or Build Tools are broken/missing, fix those SDK components first. This project does not include an Android SDK or Gradle wrapper.
