# MAXXA AI — Itachi Edition

A Kotlin + Jetpack Compose futuristic voice-assistant starter project, package `com.maxxa.ai`.

## Build
1. Upload this folder's contents to a GitHub repository.
2. Open **Actions** and run **Build MAXXA AI APK** (or push to `main`).
3. Open the completed workflow run and download `MAXXA-AI-debug-apk`.
4. Extract the artifact ZIP to get `app-debug.apk`.

## Local build
Requires JDK 17, Android SDK platform 35, and Gradle 8.9 or compatible.
Run `gradle assembleDebug` from the project root.

## Permissions
The app requests microphone permission at runtime. Android may use an online service for speech recognition depending on device settings. Torch control uses CameraManager and may be unavailable on some devices.

## Gemini setup and security
The current starter UI accepts a key in memory only; it does not save it to disk and does not yet connect it to Gemini. Never commit a Gemini key or ship it in an APK. For a real production Gemini integration, put the key behind an authenticated backend and call that backend from the app. Obtain a key through Google's official AI developer tooling and review current API/model docs before configuring a backend.

## Scope / verification
This is a starter build with a functional Compose home screen, voice recognition entry point, TextToSpeech, local time/date commands, torch commands, and YouTube search/open actions. The additional menu destinations are clearly labelled placeholders rather than complete feature screens. Gemini network calls, persistent DataStore preferences/history, accessibility automation, coding screen, adaptive launcher icon set, and custom commands are not implemented in this starter. No build was run in the generation environment; run the GitHub Actions workflow to check compilation.
