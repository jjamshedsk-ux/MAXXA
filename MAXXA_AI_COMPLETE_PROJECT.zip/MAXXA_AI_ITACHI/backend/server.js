import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";

const app = express();
app.use(helmet());
app.use(express.json({ limit: "24kb" }));
app.use(rateLimit({ windowMs: 60_000, limit: 30, standardHeaders: true, legacyHeaders: false }));

const API_KEY = process.env.GEMINI_API_KEY;
const MODEL = process.env.GEMINI_MODEL || "gemini-2.5-flash";
const PORT = Number(process.env.PORT || 8080);
const APP_TOKEN = process.env.MAXXA_APP_TOKEN;

app.get("/health", (_req, res) => res.json({ ok: true, service: "MAXXA AI backend" }));

app.post("/api/chat", async (req, res) => {
  try {
    if (APP_TOKEN && req.get("authorization") !== `Bearer ${APP_TOKEN}`) {
      return res.status(401).json({ error: "Unauthorized client." });
    }
    if (!API_KEY) return res.status(503).json({ error: "Server Gemini API key is not configured." });
    const { message, language = "Auto", personality = "Friendly", responseLength = "Balanced", codingMode = false, codingLanguage = "Kotlin" } = req.body ?? {};
    if (typeof message !== "string" || !message.trim()) return res.status(400).json({ error: "message is required." });
    if (message.length > 8000) return res.status(413).json({ error: "Message too long (max 8000 characters)." });

    const system = [
      "You are MAXXA, a friendly fictional female AI assistant. Do not claim to be human or encourage emotional dependency.",
      `Respond in: ${language}. Personality: ${personality}. Length: ${responseLength}.`,
      "Be honest about capabilities. Never claim you performed phone actions; the Android app handles local commands.",
      codingMode ? `Act as a careful coding assistant for ${codingLanguage}. Explain code and errors. Never claim code was executed.` : ""
    ].filter(Boolean).join("\n");

    const upstream = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL)}:generateContent?key=${encodeURIComponent(API_KEY)}`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: system }] },
        contents: [{ role: "user", parts: [{ text: message.trim() }] }],
        generationConfig: { temperature: 0.7, maxOutputTokens: responseLength === "Detailed" ? 1600 : responseLength === "Short" ? 250 : 800 }
      }),
      signal: AbortSignal.timeout(30_000)
    });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      const detail = data?.error?.message || `Gemini returned HTTP ${upstream.status}`;
      return res.status(upstream.status >= 500 ? 502 : upstream.status).json({ error: detail });
    }
    const reply = data?.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("").trim();
    if (!reply) return res.status(502).json({ error: "Gemini returned no text." });
    return res.json({ reply, model: MODEL });
  } catch (error) {
    console.error("chat request failed:", error?.message || error);
    return res.status(502).json({ error: "AI request failed. Check server logs and Gemini configuration." });
  }
});

app.listen(PORT, "0.0.0.0", () => console.log(`MAXXA backend listening on ${PORT}; model=${MODEL}`));
