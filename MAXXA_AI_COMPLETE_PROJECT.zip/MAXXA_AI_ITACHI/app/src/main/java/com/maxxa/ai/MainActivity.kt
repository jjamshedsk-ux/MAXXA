package com.maxxa.ai

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Path
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

private val Bg = Color(0xFF08080C)
private val Panel = Color(0xFF171219)
private val Red = Color(0xFF42D6C5)
private val White = Color(0xFFF5F3F5)
private val Muted = Color(0xFFAAA0AA)
private val http = OkHttpClient.Builder().callTimeout(35, TimeUnit.SECONDS).build()
private const val PREFS = "maxxa_preferences"

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { MaxxaApp(this) }
    }
    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) tts?.language = Locale("hi", "IN")
    }
    fun speak(text: String) { if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "maxxa-utterance") }
    fun stopSpeaking() { tts?.stop() }
    override fun onDestroy() { tts?.stop(); tts?.shutdown(); super.onDestroy() }
}

@Composable
private fun MaxxaApp(activity: MainActivity) {
    val ctx = activity
    val prefs = remember { ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    var screen by remember { mutableStateOf("Home") }
    var menu by remember { mutableStateOf(false) }
    var state by remember { mutableStateOf("IDLE") }
    var transcript by remember { mutableStateOf("Your next command awaits.") }
    var response by remember { mutableStateOf("Namaste! Main MAXXA hoon. Batao, main tumhari kya help kar sakti hoon?") }
    var backendUrl by remember { mutableStateOf(prefs.getString("backend_url", "") ?: "") }
    var language by remember { mutableStateOf(prefs.getString("language", "Auto") ?: "Auto") }
    var personality by remember { mutableStateOf(prefs.getString("personality", "Friendly") ?: "Friendly") }
    var responseLength by remember { mutableStateOf(prefs.getString("length", "Balanced") ?: "Balanced") }
    var codingLanguage by remember { mutableStateOf("Kotlin") }
    var codingPrompt by remember { mutableStateOf("") }
    var codingAnswer by remember { mutableStateOf("") }
    var customPhrase by remember { mutableStateOf("") }
    var customAction by remember { mutableStateOf("Open YouTube") }
    var customRows by remember { mutableStateOf(loadCustom(prefs)) }
    var history by remember { mutableStateOf(loadHistory(prefs)) }
    var torchOn by remember { mutableStateOf(false) }
    var showInteractionInfo by remember { mutableStateOf(false) }

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) { state = "LISTENING"; listen(ctx, language) { heard, err ->
            if (err != null) { state = "ERROR"; response = err }
            else if (heard != null) {
                transcript = heard
                val local = runLocalCommand(ctx, heard, { torchOn = it }, customRows)
                if (local != null) {
                    response = local; state = "SPEAKING"; activity.speak(local)
                    history = saveHistory(prefs, history, "You: $heard", "MAXXA: $local")
                } else {
                    state = "THINKING"
                    scope.launch {
                        val answer = callBackend(backendUrl, heard, language, personality, responseLength, false, codingLanguage)
                        response = answer
                        state = if (answer.startsWith("Connection error:") || answer.startsWith("Backend error:")) "ERROR" else "SPEAKING"
                        activity.speak(answer)
                        history = saveHistory(prefs, history, "You: $heard", "MAXXA: $answer")
                    }
                }
            }
        } } else { state = "ERROR"; response = "Microphone permission denied. Android Settings se allow karo." }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = Bg, surface = Panel, onSurface = White)) {
        Scaffold(containerColor = Bg, topBar = {
            Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 18.dp, vertical = 12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("MAXXA AI", color = White, fontSize = 23.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                    Text("ITACHI EDITION • PERSONAL AI", color = Red, fontSize = 9.sp, letterSpacing = 2.sp)
                }
                IconButton(onClick = { menu = true }) { Icon(Icons.Default.Menu, "Navigation", tint = White) }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)) {
                when (screen) {
                    "Home" -> HomeScreen(state, transcript, response, torchOn,
                        onMic = {
                            if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                state = "LISTENING"
                                listen(ctx, language) { heard, err ->
                                    if (err != null) { state = "ERROR"; response = err }
                                    else if (heard != null) {
                                        transcript = heard
                                        val local = runLocalCommand(ctx, heard, { torchOn = it }, customRows)
                                        if (local != null) {
                                            response = local; state = "SPEAKING"; activity.speak(local)
                                            history = saveHistory(prefs, history, "You: $heard", "MAXXA: $local")
                                        } else {
                                            state = "THINKING"
                                            scope.launch {
                                                val answer = callBackend(backendUrl, heard, language, personality, responseLength, false, codingLanguage)
                                                response = answer
                                                state = if (answer.startsWith("Connection error:") || answer.startsWith("Backend error:")) "ERROR" else "SPEAKING"
                                                activity.speak(answer)
                                                history = saveHistory(prefs, history, "You: $heard", "MAXXA: $answer")
                                            }
                                        }
                                    }
                                }
                            } else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                        },
                        onStop = { activity.stopSpeaking(); state = "IDLE" },
                        onTorch = { val msg = setTorch(ctx, !torchOn); torchOn = !torchOn; response = msg },
                        onYoutube = { openYoutube(ctx, "") },
                        onApps = { screen = "App Controls" },
                        onCoding = { screen = "Coding Assistant" })
                    "Gemini API Settings", "Voice Settings", "AI Companion", "Privacy and Security", "Permissions", "About MAXXA AI" -> SettingsScreen(
                        screen, backendUrl, { backendUrl = it; prefs.edit().putString("backend_url", it).apply() },
                        language, { language = it; prefs.edit().putString("language", it).apply() },
                        personality, { personality = it; prefs.edit().putString("personality", it).apply() },
                        responseLength, { responseLength = it; prefs.edit().putString("length", it).apply() },
                        onTest = { scope.launch { response = callBackend(backendUrl, "Reply with the single word connected.", language, personality, responseLength, false, codingLanguage); state = if (response.startsWith("Backend error:") || response.startsWith("Connection error:")) "ERROR" else "IDLE" } },
                        onClearHistory = { history = emptyList(); prefs.edit().remove("history").apply() },
                        onAccessibility = { showInteractionInfo = true; screen = "Screen Interaction" })
                    "Coding Assistant" -> CodingScreen(codingLanguage, { codingLanguage = it }, codingPrompt, { codingPrompt = it }, codingAnswer,
                        onAsk = {
                            if (codingPrompt.isBlank()) codingAnswer = "Pehle apna coding question likho."
                            else scope.launch {
                                codingAnswer = "Thinking…"
                                codingAnswer = callBackend(backendUrl, codingPrompt, language, personality, responseLength, true, codingLanguage)
                                history = saveHistory(prefs, history, "Coding ($codingLanguage): $codingPrompt", codingAnswer)
                            }
                        })
                    "Conversation History" -> HistoryScreen(history, onClear = { history = emptyList(); prefs.edit().remove("history").apply() })
                    "Custom Commands" -> CustomCommandsScreen(customPhrase, { customPhrase = it }, customAction, { customAction = it },
                        customRows, onAdd = {
                            if (customPhrase.isNotBlank()) {
                                customRows = customRows + (customPhrase.trim() to customAction)
                                saveCustom(prefs, customRows); customPhrase = ""
                            }
                        }, onDelete = { row -> customRows = customRows.filterNot { it == row }; saveCustom(prefs, customRows) })
                    "Screen Interaction" -> ScreenInteractionScreen(onEnable = { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, showInfo = showInteractionInfo)
                    "YouTube Controls" -> YoutubeScreen(onSearch = { openYoutube(ctx, it) })
                    "App Controls" -> AppControlsScreen(onOpen = { openApp(ctx, it) })
                    else -> SettingsScreen(screen, backendUrl, { backendUrl = it; prefs.edit().putString("backend_url", it).apply() }, language,
                        { language = it }, personality, { personality = it }, responseLength, { responseLength = it }, {}, {}, {})
                }
            }
        }
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }, modifier = Modifier.background(Panel)) {
            listOf("Home", "AI Companion", "Voice Settings", "Gemini API Settings", "App Controls", "Screen Interaction", "YouTube Controls", "Coding Assistant", "Conversation History", "Custom Commands", "Permissions", "Privacy and Security", "About MAXXA AI").forEach { item ->
                DropdownMenuItem(text = { Text(item, color = White) }, onClick = { screen = item; menu = false })
            }
        }
        if (showInteractionInfo) AlertDialog(
            onDismissRequest = { showInteractionInfo = false },
            title = { Text("Screen Interaction — optional") },
            text = { Text("Enable MAXXA's Accessibility Service only if you want user-triggered taps/scrolls. Android will show a system permission screen. This service does not read passwords, OTPs, banking fields, or silently monitor the screen.") },
            confirmButton = { TextButton(onClick = { showInteractionInfo = false; ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Text("OPEN SETTINGS") } },
            dismissButton = { TextButton(onClick = { showInteractionInfo = false }) { Text("CANCEL") } })
    }
}

@Composable
private fun HomeScreen(state: String, transcript: String, response: String, torchOn: Boolean, onMic: () -> Unit, onStop: () -> Unit, onTorch: () -> Unit, onYoutube: () -> Unit, onApps: () -> Unit, onCoding: () -> Unit) {
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Stat("SYSTEM", "READY"); Stat("MODE", "VOICE AI"); Stat("CORE", state)
        }
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { AiCore(state) }
        Text(state, color = Red, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
        Text(transcript, color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
        Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) {
            Text(response, color = White, fontSize = 14.sp, modifier = Modifier.padding(15.dp))
        }
        Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Quick("TORCH", Icons.Default.FlashlightOn, onTorch, Modifier.weight(1f))
            Quick("YOUTUBE", Icons.Default.PlayArrow, onYoutube, Modifier.weight(1f))
            Quick("APPS", Icons.Default.Apps, onApps, Modifier.weight(1f))
            Quick("CODING", Icons.Default.Code, onCoding, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = onMic, modifier = Modifier.weight(1f).height(54.dp), shape = RoundedCornerShape(15.dp)) { Icon(Icons.Default.Mic, null); Spacer(Modifier.width(8.dp)); Text("TAP TO SPEAK") }
            OutlinedButton(onClick = onStop, modifier = Modifier.size(54.dp), shape = RoundedCornerShape(15.dp)) { Icon(Icons.Default.Stop, "Stop speaking") }
        }
    }
}
@Composable private fun Stat(title: String, value: String) {
    Surface(color = Panel, shape = RoundedCornerShape(9.dp)) { Column(Modifier.padding(horizontal = 9.dp, vertical = 7.dp)) {
        Text(title, color = Muted, fontSize = 8.sp); Text(value, color = Red, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    } }
}
@Composable private fun AiCore(state: String) {
    val t = rememberInfiniteTransition(label = "core")
    val pulse by t.animateFloat(0.94f, 1.06f, infiniteRepeatable(tween(if (state == "LISTENING") 450 else 1300), RepeatMode.Reverse), label = "pulse")
    Box(Modifier.size(260.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val c = androidx.compose.ui.geometry.Offset(size.width/2, size.height/2)
            for (i in 0..3) drawCircle(Red.copy(alpha = .10f + i*.025f), size.minDimension*(.48f-i*.08f), c, style=Stroke(1.4.dp.toPx()))
            drawCircle(Brush.radialGradient(listOf(Red.copy(alpha=.28f), Color.Transparent), c, size.minDimension*.44f), size.minDimension*.44f, c)
        }
        Box(Modifier.size(138.dp).scale(pulse).background(Brush.radialGradient(listOf(Color(0xFF6E1028), Color(0xFF160910), Bg)), CircleShape).border(2.dp, Red, CircleShape), contentAlignment=Alignment.Center) {
            Column(horizontalAlignment=Alignment.CenterHorizontally) {
                Icon(Icons.Default.GraphicEq, null, tint=Red, modifier=Modifier.size(38.dp))
                Text("M", color=White, fontSize=38.sp, fontWeight=FontWeight.Black, letterSpacing=3.sp)
                Text("AI CORE", color=Red, fontSize=9.sp, letterSpacing=3.sp)
            }
        }
    }
}
@Composable private fun Quick(label:String, icon: androidx.compose.ui.graphics.vector.ImageVector, click:()->Unit, modifier:Modifier=Modifier) {
    Surface(modifier.clickable { click() }, color=Panel, shape=RoundedCornerShape(12.dp)) { Column(Modifier.padding(vertical=10.dp).fillMaxWidth(), horizontalAlignment=Alignment.CenterHorizontally) {
        Icon(icon, null, tint=Red, modifier=Modifier.size(20.dp)); Text(label, color=White, fontSize=8.sp)
    } }
}
@Composable private fun SettingsScreen(title:String, backend:String, onBackend:(String)->Unit, language:String, onLanguage:(String)->Unit, personality:String, onPersonality:(String)->Unit, length:String, onLength:(String)->Unit, onTest:()->Unit, onClearHistory:()->Unit, onAccessibility:()->Unit) {
    var testStatus by remember { mutableStateOf("Backend URL blank ho to pehle apna deployed backend URL add karo.") }
    LazyColumn(verticalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(bottom=20.dp)) {
        item { Text(title, color=White, fontSize=23.sp, fontWeight=FontWeight.Bold) }
        item { Text("Gemini is called through your private backend. Do not put a Gemini API key in this app.", color=Muted, fontSize=12.sp) }
        item { OutlinedTextField(backend, onBackend, label={Text("Backend base URL (https://...)")}, modifier=Modifier.fillMaxWidth(), singleLine=true) }
        item { Button(onClick={onTest(); testStatus="Connection test requested — check response on Home."}, modifier=Modifier.fillMaxWidth()) { Text("TEST BACKEND CONNECTION") } }
        item { Text(testStatus, color=Muted, fontSize=12.sp) }
        item { Text("Response language", color=White); ChoiceRow(listOf("Auto","Hindi","Hinglish","English"), language, onLanguage) }
        item { Text("AI personality", color=White); ChoiceRow(listOf("Friendly","Playful","Professional"), personality, onPersonality) }
        item { Text("Response length", color=White); ChoiceRow(listOf("Short","Balanced","Detailed"), length, onLength) }
        item { OutlinedButton(onClick=onClearHistory, modifier=Modifier.fillMaxWidth()) { Text("CLEAR LOCAL HISTORY") } }
        item { OutlinedButton(onClick=onAccessibility, modifier=Modifier.fillMaxWidth()) { Text("ACCESSIBILITY SETTINGS") } }
        item { Text("The backend URL is saved locally. API keys must remain on the backend server environment, never in this APK.", color=Muted, fontSize=12.sp) }
    }
}
@Composable private fun ChoiceRow(options:List<String>, current:String, onPick:(String)->Unit) {
    Column { options.chunked(2).forEach { row -> Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
        row.forEach { option -> FilterChip(selected=current==option, onClick={onPick(option)}, label={Text(option)}, modifier=Modifier.weight(1f)) }
    } } }
}
@Composable private fun CodingScreen(lang:String, onLang:(String)->Unit, prompt:String, onPrompt:(String)->Unit, answer:String, onAsk:()->Unit) {
    val clipboard = androidx.compose.ui.platform.LocalClipboardManager.current
    LazyColumn(verticalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(bottom=24.dp)) {
        item { Text("CODING ASSISTANT", color=White, fontSize=22.sp, fontWeight=FontWeight.Bold) }
        item { Text("Generate code, explain errors, or debug. Code is not executed on this device.", color=Muted, fontSize=12.sp) }
        item { var expanded by remember { mutableStateOf(false) }
            Box { OutlinedButton(onClick={expanded=true}, modifier=Modifier.fillMaxWidth()) { Text("Language: $lang") }
                DropdownMenu(expanded, {expanded=false}) { listOf("Kotlin","Java","Python","HTML","CSS","JavaScript","C","C++","SQL","Gradle").forEach { DropdownMenuItem(text={Text(it)}, onClick={onLang(it); expanded=false}) } }
            }
        }
        item { OutlinedTextField(prompt, onPrompt, label={Text("Describe your coding task")}, modifier=Modifier.fillMaxWidth().heightIn(min=130.dp)) }
        item { Button(onClick=onAsk, modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Code, null); Spacer(Modifier.width(8.dp)); Text("ASK MAXXA") } }
        item { Surface(color=Panel, shape=RoundedCornerShape(14.dp)) { Text(answer.ifBlank { "Your answer will appear here." }, color=White, modifier=Modifier.padding(14.dp)) } }
        item { OutlinedButton(onClick={clipboard.setText(androidx.compose.ui.text.AnnotatedString(answer))}, enabled=answer.isNotBlank(), modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.ContentCopy, null); Spacer(Modifier.width(8.dp)); Text("COPY ANSWER") } }
    }
}
@Composable private fun HistoryScreen(history:List<String>, onClear:()->Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) { Text("CONVERSATION HISTORY", color=White, fontSize=18.sp, fontWeight=FontWeight.Bold); TextButton(onClick=onClear) { Text("CLEAR") } }
        if (history.isEmpty()) Text("No saved conversations yet.", color=Muted)
        LazyColumn { items(history.reversed()) { row -> Surface(color=Panel, shape=RoundedCornerShape(10.dp), modifier=Modifier.fillMaxWidth().padding(vertical=4.dp)) { Text(row, color=White, modifier=Modifier.padding(12.dp), fontSize=13.sp) } } }
    }
}
@Composable private fun CustomCommandsScreen(phrase:String, onPhrase:(String)->Unit, action:String, onAction:(String)->Unit, rows:List<Pair<String,String>>, onAdd:()->Unit, onDelete:(Pair<String,String>)->Unit) {
    LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp), contentPadding=PaddingValues(bottom=20.dp)) {
        item { Text("CUSTOM COMMANDS", color=White, fontSize=22.sp, fontWeight=FontWeight.Bold) }
        item { OutlinedTextField(phrase, onPhrase, label={Text("Voice phrase")}, modifier=Modifier.fillMaxWidth()) }
        item { var expanded by remember { mutableStateOf(false) }
            Box { OutlinedButton(onClick={expanded=true}, modifier=Modifier.fillMaxWidth()) { Text("Action: $action") }
                DropdownMenu(expanded, {expanded=false}) { listOf("Open YouTube","Open Settings","Torch on","Torch off","Tell time","Tell date").forEach { DropdownMenuItem(text={Text(it)}, onClick={onAction(it); expanded=false}) } }
            }
        }
        item { Button(onClick=onAdd, modifier=Modifier.fillMaxWidth()) { Text("SAVE COMMAND") } }
        items(rows) { row -> Surface(color=Panel, shape=RoundedCornerShape(12.dp), modifier=Modifier.fillMaxWidth()) { Row(Modifier.padding(12.dp), verticalAlignment=Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text(row.first, color=White); Text("→ ${row.second}", color=Muted, fontSize=12.sp) }
            IconButton(onClick={onDelete(row)}) { Icon(Icons.Default.Delete, null, tint=Red) }
        } } }
        item { Text("Custom commands map only to this fixed allowlist. They cannot execute shell commands.", color=Muted, fontSize=12.sp) }
    }
}
@Composable private fun ScreenInteractionScreen(onEnable:()->Unit, showInfo:Boolean) {
    Column(verticalArrangement=Arrangement.spacedBy(14.dp)) {
        Text("SCREEN INTERACTION", color=White, fontSize=22.sp, fontWeight=FontWeight.Bold)
        Text("Optional Android AccessibilityService. It is disabled until you explicitly enable it in Android Accessibility settings.", color=Muted)
        Text("This starter service supports user-triggered taps on a visible text label and scroll gestures. Do not use it for passwords, OTPs, payment or banking actions.", color=White)
        Button(onClick=onEnable, modifier=Modifier.fillMaxWidth()) { Text("OPEN ACCESSIBILITY SETTINGS") }
        Text("When enabled, the system may display an accessibility indicator. You can disable it any time in system settings.", color=Muted, fontSize=12.sp)
    }
}
@Composable private fun YoutubeScreen(onSearch:(String)->Unit) {
    var q by remember { mutableStateOf("") }
    Column(verticalArrangement=Arrangement.spacedBy(12.dp)) { Text("YOUTUBE CONTROLS", color=White, fontSize=22.sp, fontWeight=FontWeight.Bold)
        OutlinedTextField(q, {q=it}, label={Text("Song, video, or search term")}, modifier=Modifier.fillMaxWidth())
        Button(onClick={onSearch(q)}, modifier=Modifier.fillMaxWidth()) { Text("SEARCH ON YOUTUBE") }
        Text("Opens official YouTube or a web search. It does not bypass ads or playback restrictions.", color=Muted, fontSize=12.sp)
    }
}
@Composable private fun AppControlsScreen(onOpen:(String)->Unit) {
    Column(verticalArrangement=Arrangement.spacedBy(10.dp)) { Text("APP CONTROLS", color=White, fontSize=22.sp, fontWeight=FontWeight.Bold)
        listOf("YouTube","Chrome","Settings","WhatsApp","Calculator").forEach { name -> OutlinedButton(onClick={onOpen(name)}, modifier=Modifier.fillMaxWidth()) { Text("OPEN $name") } }
    }
}

private fun listen(context:Context, language:String, callback:(String?,String?)->Unit) {
    if (!SpeechRecognizer.isRecognitionAvailable(context)) { callback(null, "Speech recognition service unavailable on this device."); return }
    val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
    recognizer.setRecognitionListener(object:RecognitionListener {
        override fun onReadyForSpeech(params:Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB:Float) {}
        override fun onBufferReceived(buffer:ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onError(error:Int) { callback(null, "Voice recognition error ($error). Check microphone and speech service."); recognizer.destroy() }
        override fun onResults(results:Bundle?) {
            val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (phrase.isNullOrBlank()) callback(null, "Speech not recognized. Please try again.") else callback(phrase, null)
            recognizer.destroy()
        }
        override fun onPartialResults(partialResults:Bundle?) {}
        override fun onEvent(eventType:Int, params:Bundle?) {}
    })
    val locale = when(language) { "Hindi" -> "hi-IN"; "English" -> "en-IN"; else -> "hi-IN" }
    recognizer.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, locale)
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
    })
}
private suspend fun callBackend(base:String, prompt:String, language:String, personality:String, length:String, coding:Boolean, codingLanguage:String):String = withContext(Dispatchers.IO) {
    if (base.isBlank()) return@withContext "Backend error: Open Gemini API Settings and enter your deployed backend URL. No API key belongs in the app."
    try {
        val url = base.trimEnd('/') + "/api/chat"
        val body = JSONObject().put("message", prompt).put("language", language).put("personality", personality)
            .put("responseLength", length).put("codingMode", coding).put("codingLanguage", codingLanguage).toString()
        val request = Request.Builder().url(url).post(body.toRequestBody("application/json; charset=utf-8".toMediaType())).build()
        http.newCall(request).execute().use { res ->
            val raw = res.body?.string().orEmpty()
            if (!res.isSuccessful) {
                val detail = try { JSONObject(raw).optString("error", "HTTP ${res.code}") } catch (_:Exception) { "HTTP ${res.code}" }
                return@withContext "Backend error: $detail"
            }
            JSONObject(raw).optString("reply").takeIf { it.isNotBlank() } ?: "Backend error: Empty reply."
        }
    } catch (e:Exception) { "Connection error: Cannot reach backend. Check URL, internet and server status." }
}
private fun runLocalCommand(ctx:Context, command:String, torch:(Boolean)->Unit, customs:List<Pair<String,String>>):String? {
    val c=command.lowercase(Locale.ROOT)
    customs.firstOrNull { c.contains(it.first.lowercase(Locale.ROOT)) }?.let { row ->
        return when(row.second) {
            "Open YouTube" -> { openYoutube(ctx, ""); "Opening YouTube." }
            "Open Settings" -> { ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "Opening Settings." }
            "Torch on" -> setTorch(ctx,true).also { torch(true) }
            "Torch off" -> setTorch(ctx,false).also { torch(false) }
            "Tell time" -> "The time is " + SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
            "Tell date" -> "Today is " + SimpleDateFormat("dd MMMM yyyy", Locale.getDefault()).format(Date())
            else -> null
        }
    }
    return when {
        c.contains("torch on") || c.contains("flashlight on") || c.contains("flashlight chalu") || c.contains("torch chalu") -> setTorch(ctx,true).also { torch(true) }
        c.contains("torch off") || c.contains("flashlight off") || c.contains("flashlight band") || c.contains("torch band") -> setTorch(ctx,false).also { torch(false) }
        c.contains("youtube") && (c.contains("search") || c.contains("play") || c.contains("song") || c.contains("gaana") || c.contains("bajao") || c.contains("chalao")) -> {
            val query=command.replace(Regex("(?i)(play|search|youtube par|youtube|gaana|song|chalao|bajao|par"), "").trim()
            openYoutube(ctx,query); "YouTube search opened for ${query.ifBlank { "your request" }}."
        }
        c.startsWith("open ") || c.contains(" kholo") -> {
            val app=c.removePrefix("open ").replace(" kholo","").trim()
            openApp(ctx,app); "Trying to open $app."
        }
        c.contains("time") || c.contains("samay") -> "The time is "+SimpleDateFormat("hh:mm a",Locale.getDefault()).format(Date())
        c.contains("date") || c.contains("tareekh") -> "Today is "+SimpleDateFormat("dd MMMM yyyy",Locale.getDefault()).format(Date())
        else -> null
    }
}
private fun setTorch(ctx:Context, on:Boolean):String {
    return try {
        val manager=ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id=manager.cameraIdList.firstOrNull { manager.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE)==true }
            ?: return "This device has no available torch."
        manager.setTorchMode(id,on); if(on) "Torch turned on." else "Torch turned off."
    } catch(e:Exception) { "Could not change torch state: ${e.message ?: "permission or device limitation"}" }
}
private fun openYoutube(ctx:Context, query:String) {
    val uri=if(query.isBlank()) Uri.parse("https://www.youtube.com") else Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(query)}")
    try { ctx.startActivity(Intent(Intent.ACTION_VIEW,uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_:Exception) {}
}
private fun openApp(ctx:Context, app:String) {
    val pkg=when {
        app.contains("youtube")->"com.google.android.youtube"
        app.contains("chrome")->"com.android.chrome"
        app.contains("whatsapp")->"com.whatsapp"
        app.contains("calculator")->"com.google.android.calculator"
        else -> null
    }
    if(app.contains("setting")) { ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return }
    val intent=pkg?.let { ctx.packageManager.getLaunchIntentForPackage(it) }
    if(intent!=null) ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    else if(app.contains("youtube")) openYoutube(ctx,"")
}
private fun loadHistory(prefs:android.content.SharedPreferences):List<String> =
    try { val a=JSONArray(prefs.getString("history","[]")); (0 until a.length()).map { a.getString(it) } } catch (_:Exception) { emptyList() }
private fun saveHistory(prefs:android.content.SharedPreferences, old:List<String>, user:String, answer:String):List<String> {
    val updated=(old + ("${SimpleDateFormat("HH:mm",Locale.getDefault()).format(Date())} • $user\n$answer")).takeLast(100)
    prefs.edit().putString("history",JSONArray(updated).toString()).apply()
    return updated
}
private fun loadCustom(prefs:android.content.SharedPreferences):List<Pair<String,String>> =
    try { val a=JSONArray(prefs.getString("custom_commands","[]")); (0 until a.length()).map { val o=a.getJSONObject(it); o.getString("phrase") to o.getString("action") } } catch (_:Exception) { emptyList() }
private fun saveCustom(prefs:android.content.SharedPreferences, rows:List<Pair<String,String>>) {
    val a=JSONArray(); rows.forEach { a.put(JSONObject().put("phrase",it.first).put("action",it.second)) }
    prefs.edit().putString("custom_commands",a.toString()).apply()
}

/** Opt-in accessibility service. It only performs an explicit tap/scroll command after user activation. */
class MaxxaAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event:AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onServiceConnected() { super.onServiceConnected() }
    fun tapVisibleText(label:String):Boolean {
        val root=rootInActiveWindow ?: return false
        return findAndClick(root,label)
    }
    private fun findAndClick(node:AccessibilityNodeInfo, label:String):Boolean {
        val text=node.text?.toString()
        if (text.equals(label,true) && node.isClickable) return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        for(i in 0 until node.childCount) { val child=node.getChild(i) ?: continue; if(findAndClick(child,label)) return true }
        return false
    }
    fun scroll(forward:Boolean):Boolean {
        val root=rootInActiveWindow ?: return false
        val action=if(forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        return root.performAction(action)
    }
}
