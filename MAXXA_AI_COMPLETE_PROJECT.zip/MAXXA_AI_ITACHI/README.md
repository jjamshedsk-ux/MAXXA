# MAXXA AI — Complete Android Project Package

Kotlin + Jetpack Compose Android assistant project (`com.maxxa.ai`) with a dark assistant UI, voice input/output, chat through a backend, conversation history, preferences, coding assistant screen, app/YouTube shortcuts, permissions and optional Accessibility settings.

## Important scope notes

- The Android app is the client; real Gemini replies require deploying the included `backend/` and configuring its environment variables.
- No Gemini API key is embedded in the APK. Keep `GEMINI_API_KEY` on the backend only.
- Screen interaction/automation is limited to Android APIs and user-enabled Accessibility permission. Android will show permission/consent screens; the app cannot silently control the phone.
- Screen sharing/streaming and every possible phone action are not magically enabled by the UI. These require separate Android implementation and user consent.
- This is a starter project with several functional screens/features, not a certified production assistant. Build and test on a real device before relying on it.

## Build APK with GitHub Actions
1. Upload the **contents of this project folder** to a GitHub repository (so `settings.gradle.kts`, `build.gradle.kts`, `app/`, and `.github/` are at repository root).
2. Open **Actions** → **Build MAXXA AI APK** → **Run workflow**.
3. Open the completed run and download the `MAXXA-AI-debug-apk` artifact. Extract that artifact ZIP to find `app-debug.apk`.

## Connect Gemini securely
Deploy `backend/` to a Node.js host that supports environment variables. Set:
- `GEMINI_API_KEY` = your Gemini API key (server environment only)
- `GEMINI_MODEL` = a model available to your key, e.g. `gemini-2.5-flash`
- `MAXXA_APP_TOKEN` = optional long random token if you enable client authorization in the app/backend setup

The backend has `/health` and `POST /api/chat` endpoints. In the app, open Gemini API Settings and enter your deployed backend base URL. Never commit real API keys or tokens to GitHub.

## Local build
Requires JDK 17, Android SDK platform 35, and Gradle 8.9. Run `gradle --no-daemon assembleDebug` from the project root.
