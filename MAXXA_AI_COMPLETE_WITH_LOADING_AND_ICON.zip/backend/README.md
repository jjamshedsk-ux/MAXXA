# MAXXA AI backend
1. Deploy this folder as a Node.js web service.
2. Set `GEMINI_API_KEY` in the host's environment variables. Never commit the key.
3. Health check: `GET /health` should return `{"status":"ok"}`.
4. Chat: `POST /chat` with JSON `{"message":"Hello"}`.
5. Free API usage depends on Google's current free-tier availability and quotas.
