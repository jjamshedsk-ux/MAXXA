package com.maxxa.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.Locale

private val Navy = Color(0xFF061326)
private val Panel = Color(0xFF10243B)
private val Cyan = Color(0xFF35DDF2)
private val WhiteBlue = Color(0xFFEAFBFF)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var torchOn = false
    private var cameraId: String? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var onRecognized: ((String) -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        try {
            val cm = getSystemService(CAMERA_SERVICE) as CameraManager
            cameraId = cm.cameraIdList.firstOrNull { id ->
                cm.getCameraCharacteristics(id).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
        } catch (_: Exception) {}
        setContent { MaxxaScreen(
            onSpeak = { startListening { command -> handleCommand(command) } },
            onSend = { handleCommand(it) }
        ) }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("hi", "IN")
    }

    private fun say(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "maxxa_reply")
    }

    private fun startListening(callback: (String) -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Speech recognition available nahi hai.", Toast.LENGTH_LONG).show()
            return
        }
        onRecognized = callback
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).also { recognizer ->
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    onRecognized?.invoke(spoken)
                }
                override fun onError(error: Int) {
                    Toast.makeText(this@MainActivity, "Voice nahi samajh aayi. Dobara try karo.", Toast.LENGTH_SHORT).show()
                }
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "MAXXA AI ko command do")
            }
            recognizer.startListening(intent)
        }
    }

    private fun handleCommand(raw: String) {
        val command = raw.trim()
        if (command.isBlank()) return
        val lower = command.lowercase(Locale.ROOT)
        when {
            lower.contains("torch on") || lower.contains("flashlight on") || lower.contains("टॉर्च चालू") || lower.contains("torch chalu") -> {
                setTorch(true); say("Torch chalu kar diya.")
            }
            lower.contains("torch off") || lower.contains("flashlight off") || lower.contains("टॉर्च बंद") || lower.contains("torch band") -> {
                setTorch(false); say("Torch band kar diya.")
            }
            lower.contains("youtube") || lower.contains("गाना") || lower.contains("song") -> {
                val query = command.replace(Regex("(?i)youtube|play|song|gana|gaana|chalao|चलाओ|यूट्यूब"), "").trim().ifBlank { "trending songs" }
                val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.youtube.com/results?search_query=" + android.net.Uri.encode(query)))
                startActivity(intent); say("YouTube par search khol raha hoon.")
            }
            lower.startsWith("open ") || lower.startsWith("खोलो ") -> {
                val appName = command.substringAfter(" ", "").trim().lowercase(Locale.ROOT)
                val target = when {
                    appName.contains("whatsapp") -> "com.whatsapp"
                    appName.contains("instagram") -> "com.instagram.android"
                    appName.contains("youtube") -> "com.google.android.youtube"
                    appName.contains("chrome") -> "com.android.chrome"
                    else -> null
                }
                val launch = target?.let { packageManager.getLaunchIntentForPackage(it) }
                if (launch != null) { startActivity(launch); say("App khol raha hoon.") }
                else { say("Ye app nahi mili. Aap app ka naam dobara bolo."); Toast.makeText(this, "Supported quick-open: WhatsApp, Instagram, YouTube, Chrome", Toast.LENGTH_LONG).show() }
            }
            else -> {
                val reply = "Command mili: $command. Gemini AI brain abhi connect nahi hai. README mein setup steps dekho."
                say(reply)
            }
        }
    }

    private fun setTorch(on: Boolean) {
        try {
            val id = cameraId ?: run {
                Toast.makeText(this, "Is phone mein torch available nahi hai.", Toast.LENGTH_SHORT).show()
                return
            }
            val cm = getSystemService(CAMERA_SERVICE) as CameraManager
            cm.setTorchMode(id, on)
            torchOn = on
        } catch (e: Exception) {
            Toast.makeText(this, "Torch permission/device error: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
private fun MaxxaScreen(onSpeak: () -> Unit, onSend: (String) -> Unit) {
    var input by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(listOf("MAXXA AI online. Mujhe voice command do ya message type karo.")) }
    val gradient = Brush.verticalGradient(listOf(Color(0xFF020812), Navy, Color(0xFF092B43)))
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Cyan, background = Navy, surface = Panel, onSurface = WhiteBlue
    )) {
        Column(
            Modifier.fillMaxSize().background(gradient).padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("MAXXA AI", fontSize = 28.sp, fontWeight = FontWeight.Black, color = Cyan)
            Text("PERSONAL AI ASSISTANT", fontSize = 11.sp, letterSpacing = 3.sp, color = WhiteBlue)
            Spacer(Modifier.height(22.dp))
            Box(
                Modifier.size(150.dp).background(
                    Brush.radialGradient(listOf(Color(0xFF237F9C), Color(0xFF0C2945), Color(0xFF071322))),
                    CircleShape
                ),
                contentAlignment = Alignment.Center
            ) {
                Box(Modifier.size(112.dp).background(Cyan.copy(alpha = 0.12f), CircleShape), contentAlignment = Alignment.Center) {
                    Text("M", fontSize = 64.sp, fontWeight = FontWeight.Black, color = Cyan)
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("READY • VOICE CONTROL", color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(18.dp))
            Card(
                Modifier.fillMaxWidth().weight(1f),
                colors = CardDefaults.cardColors(containerColor = Panel.copy(alpha = 0.88f)),
                shape = RoundedCornerShape(22.dp)
            ) {
                LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(messages) { msg ->
                        Text(msg, color = WhiteBlue, modifier = Modifier.fillMaxWidth()
                            .background(Color.White.copy(alpha = 0.06f), RoundedCornerShape(12.dp)).padding(12.dp))
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                    placeholder = { Text("Command likho…", color = WhiteBlue.copy(alpha = .6f)) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = WhiteBlue, unfocusedTextColor = WhiteBlue,
                        focusedBorderColor = Cyan, unfocusedBorderColor = Cyan.copy(alpha = .4f)
                    )
                )
                IconButton(onClick = onSpeak, modifier = Modifier.padding(start = 4.dp).background(Cyan.copy(alpha = .16f), CircleShape)) {
                    Icon(Icons.Default.Mic, contentDescription = "Voice command", tint = Cyan)
                }
                IconButton(onClick = {
                    val value = input.trim()
                    if (value.isNotEmpty()) { messages = messages + "You: $value"; onSend(value); input = "" }
                }, modifier = Modifier.background(Cyan.copy(alpha = .16f), CircleShape)) {
                    Icon(Icons.Default.Send, contentDescription = "Send command", tint = Cyan)
                }
            }
            Spacer(Modifier.height(6.dp))
            Text("Try: torch on • open WhatsApp • play Arijit Singh", color = WhiteBlue.copy(alpha = .6f), fontSize = 10.sp)
        }
    }
}
