# MAXXA AI — Android starter project

Dark navy + cyan Compose UI, voice input/output, flashlight commands, and basic app/YouTube intents.

## Important status
This is a **starter project**, not a finished JARVIS clone. Gemini chat is not connected yet. Commands not explicitly implemented return a setup message. WhatsApp/Instagram message sending, calling, call rejection, and broad device automation are not implemented; Android restricts these and may require user confirmation, default-role setup, Accessibility permission, or other special permissions.

## Build
- Android Studio: open this folder, use JDK 17, let Gradle sync, then Build > Build APK.
- GitHub: upload these files to your repository root and enable Actions if you add a workflow.

## Voice permissions
The app requests microphone permission when Android needs it. If voice doesn't work, grant Microphone permission in Android Settings and ensure speech recognition is installed.

## Gemini integration next
Configure Firebase AI Logic / Gemini Developer API for the Firebase project, add the correct `google-services.json`, apply the Google Services Gradle plugin and Firebase dependencies, and handle API errors. Do not commit private API keys or debug tokens. Verify the current supported model name in Firebase AI Logic documentation before selecting it.

## App icon
Replace the launcher icon resources under `app/src/main/res/mipmap-*` with your final MAXXA logo when available.
