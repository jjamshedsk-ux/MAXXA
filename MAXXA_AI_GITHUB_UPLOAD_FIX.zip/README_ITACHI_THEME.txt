MAXXA AI — Itachi Sakura Theme project
Package: com.maxxa.ai
Stack: Kotlin + Jetpack Compose + Gradle

Theme changes in this build:
- Cute Itachi/Sakura splash artwork bundled in app/src/main/res/drawable-nodpi/itachi_splash_art.png
- Crimson / sakura-pink theme palette across existing UI components
- Main home, chat/conversation, voice, API key, voice pack, permissions, preferences, automation and additional settings screens retained
- Side menu includes shortcuts for the broader reference screen set
- Selected reference collage stored at app/src/main/assets/maxxa_ui_reference.png

Build:
Open this folder as an Android Studio project or build with a compatible Gradle/Android SDK setup.
The archive has been structurally checked, but this environment did not have a Gradle executable/wrapper available, so a successful Android compile/device test is NOT claimed.

Important implementation notes:
- Gemini calls currently use a key saved on-device. This is not production-secure; a backend proxy is recommended before public release.
- Some advanced items (e.g. image generation, code generation as separate tools, phone automation, help/about) are navigation-ready placeholder pages, not fully implemented integrations. Android permissions and OS restrictions apply.
- The reference collage is a visual guide, not a pixel-perfect screenshot guarantee; device sizes/fonts differ.
