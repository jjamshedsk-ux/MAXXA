# MAXXA AI — GitHub Android Project

Package: `com.maxxa.ai`  
Stack: Kotlin, Jetpack Compose, Gradle  
Theme: crimson / sakura-pink with bundled Itachi-themed artwork

## Build on GitHub
1. Create a GitHub repository.
2. Extract this ZIP and upload its **contents** (the files inside the ZIP, not the ZIP itself) to the repository root.
3. Open **Actions** and run **Build MAXXA AI APK** (or push a commit to `main`/`master`).
4. When the workflow succeeds, open the workflow run and download the `MAXXA-AI-debug-APK` artifact.

## Current status — read before public release
This is a starter Android project, **not yet verified as a complete production app**. The ZIP structure is checked, but it has not been compiled or tested on a device in this environment. Some advanced screens are navigation/placeholder pages. A successful GitHub Actions build is still required to establish whether it compiles.

The current client stores the Gemini API key on-device and calls Gemini directly. **Do not publish this build publicly with a production API key**: a key embedded in a client app can be extracted. Before Play Store release, move Gemini calls behind a secured backend, implement and test all advertised features, add privacy policy/data-safety disclosures, and test on real devices.

The included Itachi/Naruto-related artwork may be copyrighted. For a public/commercial Play Store release, replace it with original artwork or assets you have commercial rights to use.

## Requirements
- Android SDK suitable for `compileSdk 35`
- JDK 17
- Gradle 8.9 (GitHub Actions workflow configures this)

## No guarantees
Do not describe the app as error-free until the CI build succeeds and the app has been tested on target devices.
