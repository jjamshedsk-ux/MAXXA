package com.maxxa.ai

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.content.Intent
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.google.firebase.FirebaseApp
import com.google.firebase.Firebase
import com.google.firebase.ai.GenerativeBackend
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.debug.DebugAppCheckProviderFactory
import kotlinx.coroutines.launch
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: android.speech.tts.TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            FirebaseApp.initializeApp(this)
            FirebaseAppCheck.getInstance().installAppCheckProviderFactory(DebugAppCheckProviderFactory.getInstance())
            Log.i("MAXXA_APP_CHECK", "Debug App Check provider enabled. Register the token shown by Firebase in Logcat in Firebase Console > App Check > Apps > Manage debug tokens.")
        } catch (e: Exception) {
            Log.e("MAXXA_FIREBASE", "Firebase initialization failed", e)
        }
        tts = android.speech.tts.TextToSpeech(this, this)
        setContent { MaxxaScreen(this) }
    }
    override fun onInit(status: Int) { if (status == android.speech.tts.TextToSpeech.SUCCESS) tts?.language = Locale.getDefault() }
    fun speak(text: String, languageTag: String? = null) {
        val engine = tts ?: return
        if (languageTag != null) {
            val loc = Locale.forLanguageTag(languageTag)
            if (engine.isLanguageAvailable(loc) >= android.speech.tts.TextToSpeech.LANG_AVAILABLE) engine.language = loc
        }
        engine.speak(text, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "maxxa_reply")
    }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}

@Composable
private fun MaxxaScreen(activity: MainActivity) {
    val context = activity
    var input by remember { mutableStateOf("") }
    var torchOn by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }
    var messages by remember { mutableStateOf(listOf("MAXXA AI: Namaste! Main MAXXA AI hoon. Tum jis language mein poochoge, main usi language mein jawab dene ki koshish karunga.")) }
    val scope = rememberCoroutineScope()
    val cameraManager = remember { context.getSystemService(Context.CAMERA_SERVICE) as CameraManager }
    val cameraId = remember { cameraManager.cameraIdList.firstOrNull { id -> cameraManager.getCameraCharacteristics(id).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true } }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startSpeechRecognition(activity) { recognized -> input = recognized }
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF9C8DF5), background = Color(0xFF10131B), surface = Color(0xFF1B2030))) {
        Column(Modifier.fillMaxSize().background(Color(0xFF10131B)).padding(18.dp)) {
            Text("MAXXA AI", color = Color(0xFFB8AEFF), fontSize = 28.sp)
            Text("Your smart Android assistant", color = Color.LightGray, fontSize = 13.sp)
            Spacer(Modifier.height(16.dp))
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(messages) { msg -> Surface(color = Color(0xFF202638), shape = RoundedCornerShape(14.dp)) { Text(msg, color = Color.White, modifier = Modifier.padding(12.dp)) } }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), label = { Text("Ask MAXXA...") }, singleLine = false, maxLines = 4)
                Button(enabled = !isLoading, onClick = {
                    if (input.isNotBlank()) {
                        val question = input.trim()
                        messages = messages + "You: $question"
                        input = ""
                        isLoading = true
                        scope.launch {
                            try {
                                val model = Firebase.ai(backend = GenerativeBackend.googleAI())
                                    .generativeModel("gemini-3.8-flash")
                                val prompt = "You are MAXXA AI, a helpful Android assistant. Reply in the same language and script the user used in their latest message. If the user uses Hinglish, reply in Hinglish; if Hindi, reply in Hindi; if Bengali, reply in Bengali; if English, reply in English. Do not announce this rule. Be clear and age-appropriate. User message: $question"
                                val response = model.generateContent(prompt)
                                val reply = response.text?.trim().takeUnless { it.isNullOrEmpty() }
                                    ?: "Sorry, mujhe jawab nahi mila. Dobara try karo."
                                messages = messages + "MAXXA AI: $reply"
                                activity.speak(reply)
                            } catch (e: Exception) {
                                Log.e("MAXXA_GEMINI", "Gemini request failed", e)
                                val error = when {
                                    e.message?.contains("App Check", ignoreCase = true) == true -> "Firebase App Check setup baaki hai. Debug token ko Firebase Console mein register karna hoga."
                                    e.message?.contains("network", ignoreCase = true) == true -> "Internet connection check karke dobara try karo."
                                    else -> "Gemini connect nahi ho paaya. Firebase AI Logic setup aur App Check check karo, phir dobara try karo."
                                }
                                messages = messages + "MAXXA AI: $error"
                            } finally { isLoading = false }
                        }
                    }
                }) { Text(if (isLoading) "..." else "Send") }
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(modifier = Modifier.weight(1f), onClick = {
                    try {
                        if (cameraId != null) { torchOn = !torchOn; cameraManager.setTorchMode(cameraId, torchOn) }
                        else messages = messages + "MAXXA AI: Is device par flashlight available nahi hai."
                    } catch (_: Exception) { messages = messages + "MAXXA AI: Flashlight access nahi ho saka." }
                }) { Text(if (torchOn) "Torch OFF" else "Torch ON") }
                OutlinedButton(modifier = Modifier.weight(1f), onClick = {
                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    } else startSpeechRecognition(activity) { recognized -> input = recognized }
                }) { Text("Voice") }
            }
            Spacer(Modifier.height(8.dp))
            Text(if (isLoading) "Gemini se jawab aa raha hai…" else "Gemini AI • Same-language replies • Voice input", color = Color.Gray, fontSize = 11.sp)
        }
    }
}

private fun startSpeechRecognition(activity: MainActivity, onResult: (String) -> Unit) {
    if (!SpeechRecognizer.isRecognitionAvailable(activity)) {
        Toast.makeText(activity, "Is phone par speech recognition available nahi hai.", Toast.LENGTH_LONG).show()
        return
    }
    val recognizer = SpeechRecognizer.createSpeechRecognizer(activity)
    recognizer.setRecognitionListener(object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onError(error: Int) { Toast.makeText(activity, "Voice samajh nahi aayi. Dobara try karo.", Toast.LENGTH_SHORT).show(); recognizer.destroy() }
        override fun onResults(results: Bundle?) {
            val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!words.isNullOrBlank()) onResult(words)
            recognizer.destroy()
        }
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    })
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
    }
    recognizer.startListening(intent)
}
