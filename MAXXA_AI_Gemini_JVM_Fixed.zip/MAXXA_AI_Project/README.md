# MAXXA AI — Firebase Gemini starter

This project now includes Firebase AI Logic (Gemini Developer API), same-language response prompting, Android speech-to-text, text-to-speech, and flashlight toggle.

## Important setup
1. Firebase Console > AI Services > AI Logic > Get started; choose Gemini Developer API and finish setup.
2. The `app/google-services.json` file is for the Firebase project `maxxa-ai` and Android package `com.maxxa.ai`.
3. This project enables the Firebase App Check debug provider for development. If Firebase AI Logic enforces App Check, run the app and register its debug token in Firebase Console > Security > App Check > Apps > Manage debug tokens. Never publish a debug token. For public release, use a production App Check provider instead.
4. Do not add a Gemini API key to the app or a public repository. Firebase AI Logic is used instead.

## Build
Use the existing GitHub Actions workflow or Android Studio. APK output is normally `app/build/outputs/apk/debug/app-debug.apk`.

Note: This is a development build. Firebase project setup, App Check registration, model availability, and network access are required for live Gemini responses.
