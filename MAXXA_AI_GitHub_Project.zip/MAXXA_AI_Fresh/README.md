# MAXXA AI — Itachi Edition (fresh starter)

Android Kotlin + Jetpack Compose assistant starter. Includes chat UI, Gemini REST integration, Android speech recognition, text-to-speech, torch toggle, YouTube search, opening WhatsApp/browser/settings, and an optional accessibility-service shell.

## Build APK on GitHub
1. Create a GitHub repository and upload the **contents** of this folder (not the ZIP itself).
2. In repository Settings → Secrets and variables → Actions, add repository secret `GEMINI_API_KEY` with your Google AI Studio Gemini API key. Keep the key private; don't put it in public source code.
3. Run Actions → Build MAXXA AI APK (or push to `main`). Download artifact `MAXXA-AI-debug-apk` from the successful workflow run.

## Local build
Install JDK 17 and Android SDK, then run `gradle assembleDebug -PGEMINI_API_KEY=YOUR_KEY` from this directory. Do not commit a real API key.

## Important limitations
- This is a starter project, not a full always-listening Jarvis clone. It does not implement a wake word, background microphone, arbitrary screen tapping, or automated WhatsApp message sending/calls.
- The accessibility service is an opt-in placeholder. Android requires manual enabling in Settings; it currently performs no screen actions.
- Speech recognition may rely on the phone's installed speech service and internet. Torch support depends on device hardware.
- Review permissions and API costs before use. Keep API keys private; for production, route AI requests through a backend rather than embedding a long-lived secret in an APK.
