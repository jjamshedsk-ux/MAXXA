package com.maxxa.ai

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var speech: SpeechRecognizer? = null
    private var torchOn = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        if (SpeechRecognizer.isRecognitionAvailable(this)) speech = SpeechRecognizer.createSpeechRecognizer(this)
        setContent { MaxxaScreen(this) }
    }
    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault() }
    fun speak(text: String) { tts?.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, null, "maxxa_reply") }
    fun listen(onResult: (String) -> Unit, onError: (String) -> Unit) {
        val recognizer = speech ?: run { onError("Speech recognition is unavailable on this phone."); return }
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { onError("Voice input failed. Try again or type your message.") }
            override fun onResults(results: Bundle?) { onResult(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()) }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Boliye, MAXXA sun raha hai")
        }
        recognizer.startListening(intent)
    }
    fun toggleTorch(): String = try {
        val manager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = manager.cameraIdList.firstOrNull { manager.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            ?: return "Is phone mein torch available nahi hai."
        torchOn = !torchOn; manager.setTorchMode(id, torchOn); if (torchOn) "Torch on kar diya." else "Torch off kar diya."
    } catch (_: Exception) { "Torch control nahi ho paya." }
    fun runCommand(raw: String): String? {
        val s = raw.lowercase(Locale.ROOT)
        return when {
            s.contains("torch on") || s.contains("flash on") || s.contains("टॉर्च चालू") || s.contains("torch chalu") -> { if (!torchOn) toggleTorch() else "Torch pehle se on hai." }
            s.contains("torch off") || s.contains("flash off") || s.contains("टॉर्च बंद") || s.contains("torch band") -> { if (torchOn) toggleTorch() else "Torch pehle se off hai." }
            s.contains("youtube") -> { val q = raw.replace(Regex("(?i)open|youtube|play|search|par|pe|chalao|dikhao"), "").trim(); startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q.ifBlank { "" })))); "YouTube khol raha hoon." }
            s.contains("whatsapp") -> { val i = packageManager.getLaunchIntentForPackage("com.whatsapp"); if (i != null) startActivity(i) else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.whatsapp.com"))); "WhatsApp khol raha hoon. Message bhejne se pehle aap confirm karein." }
            s.contains("open settings") || s.contains("settings kholo") || s.contains("setting kholo") -> { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)); "Settings khol raha hoon." }
            s.contains("open chrome") || s.contains("chrome kholo") -> { val i = packageManager.getLaunchIntentForPackage("com.android.chrome"); if (i != null) startActivity(i) else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"))); "Browser khol raha hoon." }
            s.contains("accessibility") || s.contains("screen interaction") -> { startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)); "Accessibility settings khol raha hoon. Is permission ko sirf samajh kar enable karein." }
            else -> null
        }
    }
    override fun onDestroy() { speech?.destroy(); tts?.stop(); tts?.shutdown(); super.onDestroy() }

    @Composable private fun MaxxaScreen(activity: MainActivity) {
        val scope = rememberCoroutineScope()
        var input by remember { mutableStateOf("") }
        var busy by remember { mutableStateOf(false) }
        var status by remember { mutableStateOf("Ready • MAXXA AI") }
        val messages = remember { mutableStateListOf("MAXXA: Namaste! Main MAXXA AI hoon. Aap type ya mic se baat kar sakte hain.") }
        val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) activity.listen({ input = it; status = "Voice recognized" }, { status = it }) else status = "Microphone permission nahi mili. Type karke bhi use kar sakte hain."
        }
        MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFFE53935), background = Color(0xFF101014), surface = Color(0xFF1B1B22))) {
            Column(Modifier.fillMaxSize().background(Color(0xFF101014)).padding(16.dp)) {
                Text("MAXXA AI", color = Color(0xFFFF5252), fontSize = 30.sp, fontWeight = FontWeight.Black)
                Text("ITACHI EDITION  •  Your AI assistant", color = Color.LightGray, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp)); Text(status, color = Color(0xFFBDBDBD), fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
                    Button(onClick = { if (ContextCompat.checkSelfPermission(activity, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) activity.listen({ input = it; status = "Voice recognized" }, { status = it }) else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO) }, modifier = Modifier.weight(1f)) { Text("🎙 Speak") }
                    OutlinedButton(onClick = { status = activity.toggleTorch() ; activity.speak(status) }, modifier = Modifier.weight(1f)) { Text("🔦 Torch") }
                }
                LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(messages) { msg -> Surface(color = if (msg.startsWith("You:")) Color(0xFF29202A) else Color(0xFF1B1B22), shape = RoundedCornerShape(12.dp)) { Text(msg, color = Color.White, modifier = Modifier.fillMaxWidth().padding(12.dp)) } }
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("Ask MAXXA anything…") }, maxLines = 4)
                    Button(enabled = !busy && input.isNotBlank(), onClick = {
                        val prompt = input.trim(); input = ""; messages.add("You: $prompt")
                        val command = activity.runCommand(prompt)
                        if (command != null) { messages.add("MAXXA: $command"); activity.speak(command) }
                        else {
                            busy = true; status = "Thinking…"
                            scope.launch {
                                val answer = withContext(Dispatchers.IO) { GeminiClient.ask(prompt) }
                                messages.add("MAXXA: $answer"); activity.speak(answer); status = "Ready"; busy = false
                            }
                        }
                    }) { Text(if (busy) "…" else "Send") }
                }
                Text("AI replies need a Gemini API key. Phone actions are limited to supported commands; Android may ask permissions.", color = Color.Gray, fontSize = 10.sp, modifier = Modifier.padding(top = 8.dp))
            }
        }
    }
}

private object GeminiClient {
    suspend fun ask(prompt: String): String {
        val key = BuildConfig.GEMINI_API_KEY
        if (key.isBlank()) return "Gemini connect karne ke liye GitHub Actions secret GEMINI_API_KEY set karein. Abhi phone commands kaam kar sakte hain."
        return try {
            val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", "You are MAXXA AI, a helpful Hindi/English Android assistant. Be concise and safe. User: $prompt")))))
            val response = withContext(Dispatchers.IO) {
                val conn = (URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$key").openConnection() as HttpURLConnection)
                conn.requestMethod = "POST"; conn.connectTimeout = 15000; conn.readTimeout = 20000; conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                val text = stream.bufferedReader().use { it.readText() }; val code = conn.responseCode; conn.disconnect()
                if (code !in 200..299) throw Exception("Gemini HTTP $code")
                JSONObject(text).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            }
            response
        } catch (e: Exception) { "Gemini se connect nahi ho paya. Internet/API key check karein. (${e.message ?: "network error"})" }
    }
}
