package com.maxxa.ai

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/** Optional service placeholder. Android requires the user to enable it manually in Settings. */
class MaxxaAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* Add narrowly scoped actions only with user consent. */ }
    override fun onInterrupt() {}
}
