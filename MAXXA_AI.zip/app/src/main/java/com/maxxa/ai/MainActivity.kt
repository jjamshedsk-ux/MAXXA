package com.maxxa.ai

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

private val Bg = Color(0xFF070912)
private val Panel = Color(0xFF121629)
private val Cyan = Color(0xFF35E7FF)
private val Purple = Color(0xFF9A5CFF)
private val Gold = Color(0xFFFFD36A)
private val White = Color(0xFFF4F6FF)
private val Muted = Color(0xFF9BA4C2)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale("en", "IN")
        }
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        }
        setContent { MaxxaApp(
            onListen = { onResult -> listen(onResult) },
            onSpeak = { text -> tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "maxxa-reply") }
        ) }
    }

    private fun listen(onResult: (String) -> Unit) {
        val recognizer = speechRecognizer ?: run { onResult("Speech recognition is not available on this device."); return }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "MAXXA is listening…")
        }
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { onResult("Voice input stopped. Please try again.") }
            override fun onResults(results: Bundle?) {
                onResult(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty().ifBlank { "I couldn't hear that clearly." })
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        recognizer.startListening(intent)
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}

private data class ChatLine(val text: String, val isUser: Boolean)

@Composable
private fun MaxxaApp(onListen: ((String) -> Unit) -> Unit, onSpeak: (String) -> Unit) {
    var showSplash by remember { mutableStateOf(true) }
    var menuOpen by remember { mutableStateOf(false) }
    var selectedPage by remember { mutableStateOf("Home") }
    var input by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Ready when you are") }
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("maxxa_settings", android.content.Context.MODE_PRIVATE) }
    var apiKey by remember { mutableStateOf(prefs.getString("gemini_api_key", "").orEmpty()) }
    var keyInput by remember { mutableStateOf(apiKey) }
    var showApiKey by remember { mutableStateOf(false) }
    var keySaved by remember { mutableStateOf(false) }
    var voiceEnabled by remember { mutableStateOf(true) }
    var replyLanguage by remember { mutableStateOf("Hindi / Hinglish") }
    val chats = remember { mutableStateListOf(ChatLine("Namaste! Main MAXXA AI hoon. Bolo, main kaise help karun?", false)) }
    val scope = rememberCoroutineScope()
    val pulse = rememberInfiniteTransition(label = "mic-pulse")
    val micScale by pulse.animateFloat(1f, 1.07f, infiniteRepeatable(tween(1250, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "mic-scale")

    LaunchedEffect(Unit) { delay(1450); showSplash = false }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Cyan, secondary = Purple, background = Bg, surface = Panel,
        onPrimary = Bg, onBackground = White, onSurface = White
    )) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF10152A), Bg, Color(0xFF080711))))) {
            if (showSplash) {
                SplashScreen()
            } else {
                Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
                    Row(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("☰", color = Cyan, fontSize = 29.sp, modifier = Modifier.clickable { menuOpen = true }.padding(end = 16.dp))
                        Column(Modifier.weight(1f)) {
                            Text("MAXXA AI", color = White, fontSize = 21.sp, fontWeight = FontWeight.Black)
                            Text("YOUR PERSONAL AI", color = Cyan, fontSize = 9.sp, letterSpacing = 2.sp)
                        }
                        Text("● ONLINE", color = Color(0xFF68F5B0), fontSize = 10.sp)
                    }
                    when (selectedPage) {
                        "Home" -> {
                            Spacer(Modifier.height(18.dp))
                            Text("WELCOME BACK", color = Gold, fontSize = 11.sp, letterSpacing = 3.sp)
                            Text("What can I do for you?", color = White, fontSize = 27.sp, fontWeight = FontWeight.Bold, lineHeight = 32.sp)
                            Text("Just speak. MAXXA is ready.", color = Muted, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
                            Spacer(Modifier.height(30.dp))
                            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                                Box(Modifier.size(238.dp).background(Brush.radialGradient(listOf(Color(0x4435E7FF), Color(0x229A5CFF), Color.Transparent)), CircleShape))
                                Box(Modifier.size(174.dp).scale(micScale).background(Brush.linearGradient(listOf(Color(0xFF182A4A), Color(0xFF17102C))), CircleShape), contentAlignment = Alignment.Center) {
                                    Box(Modifier.size(144.dp).background(Brush.linearGradient(listOf(Cyan, Purple)), CircleShape).padding(2.dp).background(Color(0xFF0A1020), CircleShape), contentAlignment = Alignment.Center) {
                                        Text("🎙", fontSize = 52.sp)
                                    }
                                }
                            }
                            Spacer(Modifier.height(25.dp))
                            Text(status, color = Muted, fontSize = 13.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                            Spacer(Modifier.height(18.dp))
                            Button(
                                onClick = { status = "Listening…"; onListen { spoken ->
                                    status = "You said: $spoken"
                                    val command = spoken.lowercase()
                                    when {
                                        command.contains("open conversation") || command.contains("chat kholo") -> selectedPage = "Conversation"
                                        command.contains("open preferences") || command.contains("settings kholo") -> selectedPage = "Preferences"
                                        command.contains("stop listening") -> status = "Listening stopped"
                                        else -> { input = spoken; selectedPage = "Conversation" }
                                    }
                                } },
                                modifier = Modifier.fillMaxWidth().height(54.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Bg),
                                shape = RoundedCornerShape(18.dp)
                            ) { Text("TAP TO SPEAK", fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp) }
                            Spacer(Modifier.height(14.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                QuickCard("CHAT", "Ask anything", Modifier.weight(1f)) { selectedPage = "Conversation" }
                                QuickCard("VOICE", "Talk to MAXXA", Modifier.weight(1f)) { status = "Tap the microphone to start" }
                            }
                        }
                        "Conversation" -> {
                            Text("CONVERSATION", color = Gold, fontSize = 12.sp, letterSpacing = 2.sp, modifier = Modifier.padding(vertical = 10.dp))
                            LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(chats) { line ->
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.isUser) Arrangement.End else Arrangement.Start) {
                                        Surface(color = if (line.isUser) Color(0xFF193B50) else Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.widthIn(max = 310.dp)) {
                                            Text(line.text, color = White, modifier = Modifier.padding(13.dp), fontSize = 14.sp)
                                        }
                                    }
                                }
                                if (loading) item { Text("MAXXA is thinking…", color = Cyan, fontSize = 13.sp) }
                            }
                            Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("Message MAXXA…") }, shape = RoundedCornerShape(18.dp), singleLine = true)
                                Spacer(Modifier.width(8.dp))
                                Button(enabled = !loading && input.isNotBlank(), onClick = {
                                    val msg = input.trim(); input = ""; chats.add(ChatLine(msg, true)); loading = true
                                    scope.launch {
                                        val answer = withContext(Dispatchers.IO) { askGemini(apiKey, msg) }
                                        chats.add(ChatLine(answer, false)); loading = false
                                        if (voiceEnabled) onSpeak(answer)
                                    }
                                }, shape = CircleShape, contentPadding = PaddingValues(14.dp)) { Text("➤") }
                            }
                        }
                        "Permissions" -> SimplePage("PERMISSIONS", "Microphone permission is required for voice input. Android may ask when you first use voice.", "MICROPHONE", "Check permission in Android Settings → Apps → MAXXA AI → Permissions.")
                        "Voice Pack" -> {
                            SimplePage("VOICE PACK", "Choose how MAXXA responds.", "VOICE LANGUAGE", replyLanguage)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("Hindi / Hinglish", "English").forEach { lang -> OutlinedButton(onClick = { replyLanguage = lang }, modifier = Modifier.weight(1f)) { Text(lang, fontSize = 11.sp) } }
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) { Text("Speak replies", color = White, modifier = Modifier.weight(1f)); Switch(voiceEnabled, { voiceEnabled = it }) }
                        }
                        "API Key" -> {
                            Spacer(Modifier.height(18.dp))
                            Text("GEMINI CONNECTION", color = Gold, fontSize = 11.sp, letterSpacing = 2.5.sp)
                            Text("Your AI. Your key.", color = White, fontSize = 27.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                            Text("Paste your Google AI Studio API key below to connect MAXXA directly to Gemini. No backend required.", color = Muted, fontSize = 13.sp, lineHeight = 19.sp, modifier = Modifier.padding(top = 8.dp, bottom = 20.dp))
                            Surface(color = Panel, shape = RoundedCornerShape(22.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x5535E7FF)), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(16.dp)) {
                                    Text("GEMINI API KEY", color = Cyan, fontSize = 11.sp, letterSpacing = 1.5.sp)
                                    Spacer(Modifier.height(10.dp))
                                    OutlinedTextField(value = keyInput, onValueChange = { keyInput = it; keySaved = false }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Paste API key here") }, singleLine = true, shape = RoundedCornerShape(14.dp), visualTransformation = if (showApiKey) VisualTransformation.None else PasswordVisualTransformation(), trailingIcon = { TextButton(onClick = { showApiKey = !showApiKey }) { Text(if (showApiKey) "HIDE" else "SHOW", color = Cyan) } })
                                    Spacer(Modifier.height(12.dp))
                                    Button(onClick = { apiKey = keyInput.trim(); prefs.edit().putString("gemini_api_key", apiKey).apply(); keySaved = true }, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(15.dp), colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Bg)) { Text("SAVE API KEY", fontWeight = FontWeight.Bold, letterSpacing = 1.sp) }
                                    Spacer(Modifier.height(10.dp))
                                    OutlinedButton(onClick = { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey"))) } }, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(15.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan)) { Text("OPEN GOOGLE AI STUDIO", fontWeight = FontWeight.Bold, letterSpacing = 0.6.sp) }
                                    if (keySaved) Text("✓ API key saved on this device", color = Color(0xFF68F5B0), fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
                                    Text("Get a key from Google AI Studio. Free-tier limits apply. A key stored in an APK/device is not fully secure—don't share your APK with your key saved.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp, modifier = Modifier.padding(top = 14.dp))
                                }
                            }
                        }
                        "Preferences" -> SimplePage("PREFERENCES", "Theme: Dark neon • Accent: Cyan / Purple / Gold • Animation: Smooth, lightweight.", "LANGUAGE", replyLanguage)
                        "Automation" -> SimplePage("AUTOMATION", "Voice shortcuts available in this starter: open conversation, chat kholo, open preferences, settings kholo, stop listening. Other phone actions need explicit permissions and implementation.", "STATUS", "Basic voice shortcuts only")
                        "Additional Settings" -> SimplePage("ADDITIONAL SETTINGS", "Network errors are shown as friendly messages. Repeated send taps are disabled while the AI is responding.", "API KEY STATUS", if (apiKey.isBlank()) "Not configured" else "Saved on this device")
                        else -> SimplePage(selectedPage.uppercase(), "This section is a starter placeholder; more controls need implementation.", "MAXXA AI", "Dark neon interface")
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.Center) {
                        Text("●  CHAT     ●  VOICE     ●  CONTROL", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
                    }
                }
                AnimatedVisibility(
                    visible = menuOpen,
                    enter = fadeIn(tween(160)) + slideInHorizontally(tween(220)) { -it },
                    exit = fadeOut(tween(120)) + slideOutHorizontally(tween(180)) { -it }
                ) {
                    Row(Modifier.fillMaxSize().background(Color(0xAA000000))) {
                        Column(Modifier.fillMaxHeight().fillMaxWidth(0.82f).background(Brush.verticalGradient(listOf(Color(0xFF171C35), Bg))).padding(20.dp)) {
                            Text("MAXXA AI", color = White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                            Text("PERSONAL ASSISTANT", color = Cyan, fontSize = 10.sp, letterSpacing = 2.sp)
                            Spacer(Modifier.height(22.dp))
                            listOf("Home", "Permissions", "Voice Pack", "API Key", "Conversation", "Preferences", "Automation", "Additional Settings").forEach { item ->
                                Row(Modifier.fillMaxWidth().clickable { selectedPage = item; menuOpen = false }.padding(vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(menuIcon(item), color = if (selectedPage == item) Cyan else Gold, fontSize = 18.sp, modifier = Modifier.width(36.dp))
                                    Text(item, color = if (selectedPage == item) Cyan else White, fontSize = 15.sp, fontWeight = if (selectedPage == item) FontWeight.Bold else FontWeight.Normal)
                                }
                            }
                            Spacer(Modifier.weight(1f))
                            Text("Built for your voice.", color = Muted, fontSize = 12.sp)
                        }
                        Box(Modifier.fillMaxSize().clickable { menuOpen = false })
                    }
                }
            }
        }
    }
}

private fun menuIcon(item: String) = when (item) {
    "Home" -> "⌂"; "Permissions" -> "◈"; "Voice Pack" -> "♫"; "API Key" -> "⌘"
    "Conversation" -> "☷"; "Preferences" -> "⚙"; "Automation" -> "⌁"; else -> "⋯"
}

@Composable
private fun SplashScreen() {
    val transition = rememberInfiniteTransition(label = "splash")
    val pulse by transition.animateFloat(0.94f, 1.06f, infiniteRepeatable(tween(950), RepeatMode.Reverse), label = "splash-pulse")
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(150.dp).scale(pulse).background(Brush.radialGradient(listOf(Color(0x6635E7FF), Color(0x339A5CFF), Color.Transparent)), CircleShape), contentAlignment = Alignment.Center) {
                Box(Modifier.size(105.dp).background(Brush.linearGradient(listOf(Cyan, Purple)), CircleShape).padding(3.dp).background(Bg, CircleShape), contentAlignment = Alignment.Center) {
                    Text("M✦", color = White, fontSize = 42.sp, fontWeight = FontWeight.Black)
                }
            }
            Spacer(Modifier.height(25.dp))
            Text("MAXXA AI", color = White, fontSize = 30.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
            Text("YOUR PERSONAL AI", color = Cyan, fontSize = 10.sp, letterSpacing = 4.sp, modifier = Modifier.padding(top = 8.dp))
            Spacer(Modifier.height(35.dp))
            CircularProgressIndicator(color = Cyan, strokeWidth = 2.dp, modifier = Modifier.size(28.dp))
            Text("INITIALIZING…", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp, modifier = Modifier.padding(top = 12.dp))
        }
    }
}

@Composable
private fun QuickCard(title: String, subtitle: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(modifier = modifier.clickable(onClick = onClick), color = Panel, shape = RoundedCornerShape(18.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x4435E7FF))) {
        Column(Modifier.padding(15.dp)) {
            Text(title, color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Text(subtitle, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

@Composable
private fun SimplePage(title: String, body: String, label: String, value: String) {
    Column(Modifier.fillMaxWidth().padding(top = 16.dp)) {
        Text(title, color = Gold, fontSize = 12.sp, letterSpacing = 2.sp)
        Text(body, color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold, lineHeight = 27.sp, modifier = Modifier.padding(top = 12.dp))
        Spacer(Modifier.height(20.dp))
        Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text(label, color = Cyan, fontSize = 11.sp, letterSpacing = 1.5.sp)
                Text(value, color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
            }
        }
    }
}

private fun askGemini(apiKey: String, message: String): String {
    if (apiKey.isBlank()) return "API key missing. Open the menu → API Key and save your Gemini key first."
    return try {
        val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + java.net.URLEncoder.encode(apiKey, "UTF-8")
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 45000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
        }
        val payload = JSONObject().put("contents", org.json.JSONArray().put(JSONObject().put("role", "user").put("parts", org.json.JSONArray().put(JSONObject().put("text", message))))).toString()
        connection.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        connection.disconnect()
        val json = runCatching { JSONObject(body) }.getOrNull()
        if (code in 200..299) {
            val candidates = json?.optJSONArray("candidates")
            val content = candidates?.optJSONObject(0)?.optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            parts?.optJSONObject(0)?.optString("text")?.takeIf { it.isNotBlank() } ?: "Gemini returned an empty response."
        } else {
            val apiError = json?.optJSONObject("error")?.optString("message").orEmpty()
            "Gemini error: HTTP $code. ${apiError.ifBlank { "Check the API key, model access, and usage limits." }}"
        }
    } catch (e: Exception) {
        "Couldn't connect to Gemini. Check your internet connection and try again."
    }
}
