package com.maxxa.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Color(0xFFB388FF),
                background = Color(0xFF090A12),
                surface = Color(0xFF151626)
            )) { MaxxaHome() }
        }
    }
}

@Composable
private fun MaxxaHome() {
    var message by remember { mutableStateOf("") }
    var lastMessage by remember { mutableStateOf("") }
    Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF090A12)) {
        Column(
            modifier = Modifier.fillMaxSize().padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(28.dp))
            Text("MAXXA AI", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE7D9FF))
            Text("Your personal AI assistant", color = Color(0xFFB7B7CC), fontSize = 14.sp)
            Spacer(Modifier.height(28.dp))
            Box(
                Modifier.fillMaxWidth().weight(1f)
                    .background(Color(0xFF151626), RoundedCornerShape(20.dp)).padding(18.dp)
            ) {
                Column {
                    Text("MAXXA", color = Color(0xFFB388FF), fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        if (lastMessage.isBlank())
                            "Namaste! Main MAXXA AI hoon. Yeh starter app hai; AI backend abhi connect nahi hai."
                        else "Tumhara message: $lastMessage\n\nAI backend abhi connect nahi hai.",
                        color = Color.White, fontSize = 16.sp
                    )
                }
            }
            Spacer(Modifier.height(14.dp))
            OutlinedTextField(
                value = message, onValueChange = { message = it },
                modifier = Modifier.fillMaxWidth(), placeholder = { Text("Message likho...") },
                shape = RoundedCornerShape(16.dp), singleLine = true
            )
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = { lastMessage = message.trim(); message = "" },
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)
            ) { Text("Send") }
        }
    }
}
