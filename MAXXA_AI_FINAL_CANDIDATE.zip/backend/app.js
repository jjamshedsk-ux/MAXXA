'use strict';

const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

const MAX_MESSAGE_CHARS = 20_000;
const UPSTREAM_TIMEOUT_MS = 55_000;
const MAX_UPSTREAM_BYTES = 8 * 1024 * 1024;
const MAX_IMAGE_PROMPT_CHARS = 4_000;

async function readTextLimited(response, maxBytes) {
  if (!response.body) return '';
  const reader = response.body.getReader();
  const chunks = [];
  let total = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > maxBytes) {
        await reader.cancel();
        throw new Error('UPSTREAM_RESPONSE_TOO_LARGE');
      }
      chunks.push(Buffer.from(value));
    }
  } finally {
    reader.releaseLock();
  }
  return Buffer.concat(chunks, total).toString('utf8');
}

function createApp({ apiKey = process.env.GEMINI_API_KEY, model = process.env.GEMINI_MODEL || 'gemini-2.5-flash', fetchImpl = global.fetch } = {}) {
  const app = express();
  app.disable('x-powered-by');
  app.use(helmet());
  app.use(express.json({ limit: '64kb', strict: true }));
  app.use('/api/', rateLimit({ windowMs: 60_000, limit: 30, standardHeaders: 'draft-7', legacyHeaders: false }));

  app.get('/health', (_req, res) => res.json({ ok: true, service: 'MAXXA AI backend' }));

  app.post('/api/image', async (req, res) => {
    if (!apiKey) return res.status(503).json({ error: 'Backend is not configured. Set GEMINI_API_KEY on the server.' });
    const prompt = typeof req.body?.prompt === 'string' ? req.body.prompt.trim() : '';
    if (!prompt) return res.status(400).json({ error: 'prompt is required' });
    if (prompt.length > MAX_IMAGE_PROMPT_CHARS) return res.status(413).json({ error: `prompt is too long (${MAX_IMAGE_PROMPT_CHARS} characters maximum)` });
    const aspectRatio = ['1:1', '3:2', '2:3', '4:3', '3:4', '5:4', '4:5', '9:16', '16:9'].includes(req.body?.aspectRatio) ? req.body.aspectRatio : '1:1';
    const imageModel = process.env.GEMINI_IMAGE_MODEL || 'gemini-3.1-flash-image';
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 90_000);
    try {
      const upstream = await fetchImpl(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(imageModel)}:generateContent`, {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-goog-api-key': apiKey },
        body: JSON.stringify({
          contents: [{ role: 'user', parts: [{ text: prompt }] }],
          generationConfig: { responseModalities: ['IMAGE'], imageConfig: { aspectRatio } }
        }),
        signal: controller.signal,
      });
      const raw = await readTextLimited(upstream, MAX_UPSTREAM_BYTES);
      let data;
      try { data = JSON.parse(raw); } catch { return res.status(502).json({ error: 'Image provider returned an invalid response.' }); }
      if (!upstream.ok) {
        const providerMessage = typeof data?.error?.message === 'string' ? data.error.message.slice(0, 500) : `Image provider returned HTTP ${upstream.status}`;
        return res.status(upstream.status >= 500 ? 502 : upstream.status).json({ error: providerMessage });
      }
      const parts = data?.candidates?.[0]?.content?.parts || [];
      const image = parts.find(part => part?.inlineData?.data && /^image\/(png|jpeg|webp)$/.test(part.inlineData.mimeType || ''))?.inlineData;
      if (!image) return res.status(502).json({ error: 'Image provider returned no supported image. Check model access and billing/quota.' });
      return res.json({ mimeType: image.mimeType, imageBase64: image.data, model: imageModel });
    } catch (error) {
      return res.status(502).json({ error: error?.name === 'AbortError' ? 'Image generation timed out' : 'Could not reach image provider' });
    } finally { clearTimeout(timeout); }
  });

  app.post('/api/chat', async (req, res) => {
    if (!apiKey) return res.status(503).json({ error: 'Backend is not configured. Set GEMINI_API_KEY on the server.' });
    const message = typeof req.body?.message === 'string' ? req.body.message.trim() : '';
    if (!message) return res.status(400).json({ error: 'message is required' });
    if (message.length > MAX_MESSAGE_CHARS) return res.status(413).json({ error: `message is too long (${MAX_MESSAGE_CHARS} characters maximum)` });

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), UPSTREAM_TIMEOUT_MS);
    try {
      const upstream = await fetchImpl(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(apiKey)}`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: message }] }] }),
        signal: controller.signal,
      });
      const declaredLength = Number(upstream.headers?.get?.('content-length') || 0);
      if (declaredLength > MAX_UPSTREAM_BYTES) return res.status(502).json({ error: 'AI provider response exceeded the allowed size.' });
      let raw;
      try { raw = await readTextLimited(upstream, MAX_UPSTREAM_BYTES); }
      catch (error) {
        if (error?.message === 'UPSTREAM_RESPONSE_TOO_LARGE') return res.status(502).json({ error: 'AI provider response exceeded the allowed size.' });
        throw error;
      }
      let data;
      try { data = JSON.parse(raw); } catch { return res.status(502).json({ error: 'AI provider returned an invalid response.' }); }
      if (!upstream.ok) {
        const providerMessage = typeof data?.error?.message === 'string' ? data.error.message.slice(0, 500) : `AI provider returned HTTP ${upstream.status}`;
        return res.status(upstream.status >= 500 ? 502 : upstream.status).json({ error: providerMessage });
      }
      const text = (data?.candidates?.[0]?.content?.parts || []).map(part => typeof part?.text === 'string' ? part.text : '').filter(Boolean).join('\n').trim();
      if (!text) return res.status(502).json({ error: 'AI provider returned no text' });
      return res.json({ text });
    } catch (error) {
      return res.status(502).json({ error: error?.name === 'AbortError' ? 'AI provider timed out' : 'Could not reach AI provider' });
    } finally {
      clearTimeout(timeout);
    }
  });

  app.use((err, _req, res, _next) => {
    if (err?.type === 'entity.too.large') return res.status(413).json({ error: 'Request body is too large.' });
    if (err instanceof SyntaxError && 'body' in err) return res.status(400).json({ error: 'Request body must be valid JSON.' });
    return res.status(500).json({ error: 'Unexpected backend error.' });
  });
  return app;
}

module.exports = { createApp, MAX_MESSAGE_CHARS, MAX_IMAGE_PROMPT_CHARS, MAX_UPSTREAM_BYTES, readTextLimited };
