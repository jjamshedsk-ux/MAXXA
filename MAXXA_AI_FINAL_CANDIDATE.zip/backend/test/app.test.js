'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { createApp, MAX_MESSAGE_CHARS } = require('../app');

async function withServer(app, run) {
  const server = app.listen(0, '127.0.0.1');
  await new Promise(resolve => server.once('listening', resolve));
  try { await run(`http://127.0.0.1:${server.address().port}`); }
  finally { await new Promise((resolve, reject) => server.close(error => error ? reject(error) : resolve())); }
}

test('health endpoint reports service status', async () => {
  await withServer(createApp({ apiKey: '' }), async base => {
    const response = await fetch(`${base}/health`);
    assert.equal(response.status, 200);
    assert.equal((await response.json()).ok, true);
  });
});

test('chat rejects missing server credentials', async () => {
  await withServer(createApp({ apiKey: '' }), async base => {
    const response = await fetch(`${base}/api/chat`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ message: 'hello' }) });
    assert.equal(response.status, 503);
  });
});

test('chat rejects empty messages without contacting provider', async () => {
  let called = false;
  await withServer(createApp({ apiKey: 'test', fetchImpl: async () => { called = true; throw new Error('should not call'); } }), async base => {
    const response = await fetch(`${base}/api/chat`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ message: '  ' }) });
    assert.equal(response.status, 400);
    assert.equal(called, false);
  });
});

test('chat rejects oversized messages', async () => {
  await withServer(createApp({ apiKey: 'test' }), async base => {
    const response = await fetch(`${base}/api/chat`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ message: 'x'.repeat(MAX_MESSAGE_CHARS + 1) }) });
    assert.equal(response.status, 413);
  });
});

test('chat returns text from provider response', async () => {
  const fetchImpl = async (_url, options) => {
    assert.equal(options.method, 'POST');
    return new Response(JSON.stringify({ candidates: [{ content: { parts: [{ text: 'MAXXA reply' }] } }] }), { status: 200, headers: { 'content-type': 'application/json' } });
  };
  await withServer(createApp({ apiKey: 'test-secret', fetchImpl }), async base => {
    const response = await fetch(`${base}/api/chat`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ message: 'hello' }) });
    assert.equal(response.status, 200);
    assert.equal((await response.json()).text, 'MAXXA reply');
  });
});

test('chat sanitizes provider errors and maps upstream server errors', async () => {
  const fetchImpl = async () => new Response(JSON.stringify({ error: { message: 'temporary failure' } }), { status: 503 });
  await withServer(createApp({ apiKey: 'test', fetchImpl }), async base => {
    const response = await fetch(`${base}/api/chat`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ message: 'hello' }) });
    assert.equal(response.status, 502);
    assert.match((await response.json()).error, /temporary failure/);
  });
});

test('chat rejects invalid provider JSON', async () => {
  const fetchImpl = async () => new Response('not-json', { status: 200 });
  await withServer(createApp({ apiKey: 'test', fetchImpl }), async base => {
    const response = await fetch(`${base}/api/chat`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ message: 'hello' }) });
    assert.equal(response.status, 502);
  });
});

test('chat rejects provider response over the configured limit', async () => {
  const fetchImpl = async () => new Response('x'.repeat(2 * 1024 * 1024 + 1), { status: 200 });
  await withServer(createApp({ apiKey: 'test', fetchImpl }), async base => {
    const response = await fetch(`${base}/api/chat`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ message: 'hello' }) });
    assert.equal(response.status, 502);
  });
});

test('chat rejects malformed JSON with a client error', async () => {
  await withServer(createApp({ apiKey: 'test' }), async base => {
    const response = await fetch(`${base}/api/chat`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{bad json' });
    assert.equal(response.status, 400);
    assert.match((await response.json()).error, /valid JSON/i);
  });
});

test('chat maps provider timeout to a safe gateway error', async () => {
  const fetchImpl = async () => { const error = new Error('aborted'); error.name = 'AbortError'; throw error; };
  await withServer(createApp({ apiKey: 'test', fetchImpl }), async base => {
    const response = await fetch(`${base}/api/chat`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ message: 'hello' }) });
    assert.equal(response.status, 502);
    assert.match((await response.json()).error, /timed out/i);
  });
});


test('image generation requires server credentials', async () => {
  await withServer(createApp({ apiKey: '' }), async base => {
    const response = await fetch(`${base}/api/image`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ prompt: 'A landscape' }) });
    assert.equal(response.status, 503);
  });
});

test('image generation rejects empty prompts without contacting provider', async () => {
  let called = false;
  await withServer(createApp({ apiKey: 'test', fetchImpl: async () => { called = true; throw new Error('should not call'); } }), async base => {
    const response = await fetch(`${base}/api/image`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ prompt: '  ' }) });
    assert.equal(response.status, 400);
    assert.equal(called, false);
  });
});

test('image generation returns generated image bytes as base64', async () => {
  const fetchImpl = async (url, options) => {
    assert.match(url, /models\/gemini-3\.1-flash-image:generateContent/);
    assert.equal(options.headers['x-goog-api-key'], 'test-secret');
    const request = JSON.parse(options.body);
    assert.deepEqual(request.generationConfig.responseModalities, ['IMAGE']);
    return new Response(JSON.stringify({ candidates: [{ content: { parts: [{ inlineData: { mimeType: 'image/png', data: 'aGVsbG8=' } }] } }] }), { status: 200, headers: { 'content-type': 'application/json' } });
  };
  await withServer(createApp({ apiKey: 'test-secret', fetchImpl }), async base => {
    const response = await fetch(`${base}/api/image`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ prompt: 'A calm landscape', aspectRatio: '16:9' }) });
    assert.equal(response.status, 200);
    const body = await response.json();
    assert.equal(body.mimeType, 'image/png');
    assert.equal(body.imageBase64, 'aGVsbG8=');
  });
});
