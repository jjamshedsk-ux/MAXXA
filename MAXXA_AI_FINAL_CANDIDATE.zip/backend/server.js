'use strict';

const { createApp } = require('./app');

const PORT = Number(process.env.PORT || 8080);
if (!Number.isInteger(PORT) || PORT < 1 || PORT > 65535) {
  throw new Error('PORT must be an integer between 1 and 65535');
}

const app = createApp();
const server = app.listen(PORT, '0.0.0.0', () => {
  console.log(`MAXXA AI backend listening on port ${PORT}`);
});

function shutdown(signal) {
  console.log(`Received ${signal}; shutting down MAXXA AI backend`);
  server.close(error => {
    if (error) {
      console.error('Backend shutdown failed:', error);
      process.exitCode = 1;
    }
  });
  setTimeout(() => process.exit(1), 10_000).unref();
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
