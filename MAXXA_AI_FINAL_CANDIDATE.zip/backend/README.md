# MAXXA AI backend

This small Node.js service proxies text requests to Gemini so the provider key stays on the server, not inside the Android APK.

## Deploy
1. Deploy this `backend` directory to a Node.js host that supports Node 20+ and HTTPS (for example, a service you control).
2. Set `GEMINI_API_KEY` in the host's secret/environment settings. Do not commit a real `.env` file or API key.
3. Optionally set `GEMINI_MODEL` (default `gemini-2.5-flash`) and `PORT` (usually supplied by the host).
4. Run `npm install` and `npm start`.
5. Confirm `https://YOUR-HOST/health` returns `{ "ok": true, ... }`.
6. In MAXXA AI → API Key, save the backend base URL (including `https://`, no `/api/chat` suffix). The app will call `/api/chat`.

## API
`POST /api/chat` with JSON `{ "message": "..." }` returns `{ "text": "..." }`. It enforces a JSON body limit and a basic per-IP rate limit. The Android client requires an HTTPS backend URL; the provider key is never sent to the app. Add provider-specific budgets, authentication/abuse protection, monitoring and privacy disclosures before a public release. This is a starter backend, not a deployed service.

## Image generation

`POST /api/image` accepts `{ "prompt": "...", "aspectRatio": "1:1" }` and returns `{ "mimeType": "image/png", "imageBase64": "...", "model": "..." }`. The server uses `GEMINI_IMAGE_MODEL` (default `gemini-3.1-flash-image`) and the server-side `GEMINI_API_KEY`; the key is sent in the `x-goog-api-key` header and is never exposed to the Android client. Image model access, quota and billing depend on the Google AI project. Supported aspect ratios are validated server-side; unknown values fall back to `1:1`.
