package com.maxxa.ai

import android.Manifest
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import android.util.Base64

private val Bg = Color(0xFF090509)
private val Panel = Color(0xFF1A0B12)
private val Cyan = Color(0xFFFF426D)
private val Purple = Color(0xFFFF78B7)
private val Gold = Color(0xFFFFA6C8)
private val White = Color(0xFFF4F6FF)
private val Muted = Color(0xFFCC9BAE)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale("en", "IN")
        }
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        }
        setContent { MaxxaApp(
            onListen = { language, onResult -> listen(language, onResult) },
            onSpeak = { text, language ->
                val locale = when (language) {
                    "Hindi" -> Locale("hi", "IN")
                    "English" -> Locale("en", "IN")
                    else -> Locale("hi", "IN")
                }
                tts?.let { engine ->
                    val availability = engine.isLanguageAvailable(locale)
                    if (availability >= TextToSpeech.LANG_AVAILABLE) engine.language = locale
                    engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "maxxa-reply")
                }
            }
        ) }
    }

    private fun listen(language: String, onResult: (String) -> Unit) {
        val recognizer = speechRecognizer ?: run { onResult("Speech recognition is not available on this device."); return }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            val localeTag = when (language) {
                "English" -> "en-IN"
                "Hindi" -> "hi-IN"
                else -> "hi-IN"
            }
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, localeTag)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, localeTag)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "MAXXA is listening…")
        }
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { onResult("Voice input stopped. Please try again.") }
            override fun onResults(results: Bundle?) {
                onResult(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty().ifBlank { "I couldn't hear that clearly." })
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        recognizer.startListening(intent)
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}

private data class ChatLine(val text: String, val isUser: Boolean)

@Composable
private fun MaxxaApp(onListen: (String, (String) -> Unit) -> Unit, onSpeak: (String, String) -> Unit) {
    var showSplash by remember { mutableStateOf(true) }
    var menuOpen by remember { mutableStateOf(false) }
    var selectedPage by remember { mutableStateOf("Home") }
    var input by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Ready when you are") }
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("maxxa_settings", android.content.Context.MODE_PRIVATE) }
    val apiKey = "" // Provider keys are never stored in the Android app.
    var backendUrl by remember { mutableStateOf(prefs.getString("backend_url", "").orEmpty()) }
    var backendUrlInput by remember { mutableStateOf(backendUrl) }
    var keySaved by remember { mutableStateOf(false) }
    var permissionRefresh by remember { mutableIntStateOf(0) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        permissionRefresh++
    }
    var voiceEnabled by remember { mutableStateOf(prefs.getBoolean("voice_enabled", true)) }
    var replyLanguage by remember { mutableStateOf(prefs.getString("reply_language", "Hindi / Hinglish").orEmpty()) }
    val voicePermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        permissionRefresh++
        if (granted) onListen(replyLanguage, { spoken -> status = "You said: $spoken"; input = spoken; selectedPage = "Conversation" })
        else status = "Microphone permission is required for voice input."
    }
    var backendCheck by remember { mutableStateOf("") }
    var checkingBackend by remember { mutableStateOf(false) }
    val chats = remember {
        mutableStateListOf<ChatLine>().apply {
            val saved = runCatching { org.json.JSONArray(prefs.getString("chat_history", "[]")) }.getOrNull()
            if (saved != null) {
                for (i in 0 until saved.length()) {
                    val item = saved.optJSONObject(i) ?: continue
                    val text = item.optString("text")
                    if (text.isNotBlank()) add(ChatLine(text, item.optBoolean("isUser")))
                }
            }
            if (isEmpty()) add(ChatLine("Namaste! Main MAXXA AI hoon. Bolo, main kaise help karun?", false))
        }
    }
    LaunchedEffect(chats.size) {
        val saved = org.json.JSONArray()
        chats.forEach { line -> saved.put(JSONObject().put("text", line.text).put("isUser", line.isUser)) }
        prefs.edit().putString("chat_history", saved.toString()).apply()
    }
    val scope = rememberCoroutineScope()
    val pulse = rememberInfiniteTransition(label = "mic-pulse")
    val micScale by pulse.animateFloat(1f, 1.07f, infiniteRepeatable(tween(1250, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "mic-scale")

    LaunchedEffect(Unit) { delay(1450); showSplash = false }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Cyan, secondary = Purple, background = Bg, surface = Panel,
        onPrimary = Bg, onBackground = White, onSurface = White
    )) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1A0710), Bg, Color(0xFF080407))))) {
            if (showSplash) {
                SplashScreen()
            } else {
                Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
                    Row(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("☰", color = Cyan, fontSize = 29.sp, modifier = Modifier.clickable { menuOpen = true }.padding(end = 16.dp))
                        Column(Modifier.weight(1f)) {
                            Text("MAXXA AI", color = White, fontSize = 21.sp, fontWeight = FontWeight.Black)
                            Text("YOUR PERSONAL AI", color = Cyan, fontSize = 9.sp, letterSpacing = 2.sp)
                        }
                        Text("● ONLINE", color = Color(0xFFFF9FBE), fontSize = 10.sp)
                    }
                    when (selectedPage) {
                        "Home" -> {
                            Spacer(Modifier.height(18.dp))
                            Text("HELLO, I'M MAXXA ✦", color = Gold, fontSize = 11.sp, letterSpacing = 2.5.sp)
                            Text("Your Smart AI Assistant", color = White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 31.sp)
                            Text("Ask questions, write code, explore ideas — just speak or type.", color = Muted, fontSize = 13.sp, lineHeight = 19.sp, modifier = Modifier.padding(top = 8.dp))
                            Spacer(Modifier.height(30.dp))
                            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                                Box(Modifier.size(238.dp).background(Brush.radialGradient(listOf(Color(0x66FF426D), Color(0x229A5CFF), Color.Transparent)), CircleShape))
                                Box(Modifier.size(174.dp).scale(micScale).background(Brush.linearGradient(listOf(Color(0xFF3A1424), Color(0xFF240C18))), CircleShape), contentAlignment = Alignment.Center) {
                                    Box(Modifier.size(144.dp).background(Brush.linearGradient(listOf(Cyan, Purple)), CircleShape).padding(2.dp).background(Color(0xFF10070C), CircleShape), contentAlignment = Alignment.Center) {
                                        Text("🎙", fontSize = 52.sp)
                                    }
                                }
                            }
                            Spacer(Modifier.height(25.dp))
                            Text(status, color = Muted, fontSize = 13.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                            Spacer(Modifier.height(18.dp))
                            Button(
                                onClick = { status = "Listening…"; onListen(replyLanguage) { spoken ->
                                    status = "You said: $spoken"
                                    val command = spoken.lowercase()
                                    when {
                                        command.contains("open conversation") || command.contains("chat kholo") -> selectedPage = "Conversation"
                                        command.contains("open preferences") || command.contains("settings kholo") -> selectedPage = "Preferences"
                                        command.contains("stop listening") -> status = "Listening stopped"
                                        else -> { input = spoken; selectedPage = "Conversation" }
                                    }
                                } },
                                modifier = Modifier.fillMaxWidth().height(54.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Bg),
                                shape = RoundedCornerShape(18.dp)
                            ) { Text("🎙  TAP TO SPEAK", fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp) }
                            Spacer(Modifier.height(14.dp))
                            Surface(
                                color = Color(0xCC10070C),
                                shape = RoundedCornerShape(20.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x66FF426D)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(Modifier.padding(12.dp)) {
                                    Text("QUICK ACTIONS", color = White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.height(10.dp))
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        QuickCard("▣  IMAGE", "Image prompt", Modifier.weight(1f)) { selectedPage = "Image Generation" }
                                        QuickCard("⌘  CODE", "Generate code", Modifier.weight(1f)) { selectedPage = "Code Generator" }
                                    }
                                    Spacer(Modifier.height(8.dp))
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        QuickCard("▤  SUMMARIZE", "Shorten text", Modifier.weight(1f)) { selectedPage = "Summarize" }
                                        QuickCard("⇄  TRANSLATE", "Change language", Modifier.weight(1f)) { selectedPage = "Translate" }
                                    }
                                    Spacer(Modifier.height(8.dp))
                                    QuickCard("✎  WRITE ANYTHING", "Ideas, messages and more", Modifier.fillMaxWidth()) { selectedPage = "Conversation" }
                                }
                            }
                            Spacer(Modifier.height(14.dp))
                            Text("HOME  /  QUICK ACTIONS", color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp)
                        }
                        "Conversation", "Chat" -> {
                            Text("CONVERSATION", color = Gold, fontSize = 12.sp, letterSpacing = 2.sp, modifier = Modifier.padding(vertical = 10.dp))
                            LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(chats) { line ->
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.isUser) Arrangement.End else Arrangement.Start) {
                                        Surface(color = if (line.isUser) Color(0xFF57172A) else Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.widthIn(max = 310.dp)) {
                                            Text(line.text, color = White, modifier = Modifier.padding(13.dp), fontSize = 14.sp)
                                        }
                                    }
                                }
                                if (loading) item { Text("MAXXA is thinking…", color = Cyan, fontSize = 13.sp) }
                            }
                            Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("Message MAXXA…") }, shape = RoundedCornerShape(18.dp), singleLine = true)
                                Spacer(Modifier.width(8.dp))
                                Button(enabled = !loading && input.isNotBlank(), onClick = {
                                    val msg = input.trim(); input = ""; chats.add(ChatLine(msg, true)); loading = true
                                    scope.launch {
                                        try {
                                            val conversationContext = chats.takeLast(12).joinToString("\n") { line ->
                                                (if (line.isUser) "User: " else "MAXXA: ") + line.text
                                            }
                                            val answer = withContext(Dispatchers.IO) {
                                                askGemini(apiKey, "You are MAXXA AI, a helpful multilingual assistant. Reply primarily in $replyLanguage unless the user explicitly requests another language. Keep context from the conversation, answer accurately, and explain code step by step when asked.\n\nRecent conversation (the latest user message is included above):\n$conversationContext", backendUrl)
                                            }
                                            chats.add(ChatLine(answer, false))
                                            if (voiceEnabled && answer.isNotBlank()) onSpeak(answer, replyLanguage)
                                        } catch (e: Exception) {
                                            chats.add(ChatLine("MAXXA couldn't complete the request. Check your internet connection and API key, then try again.", false))
                                        } finally {
                                            loading = false
                                        }
                                    }
                                }, shape = CircleShape, contentPadding = PaddingValues(14.dp)) { Text("➤") }
                            }
                        }
                        "Voice" -> {
                            Spacer(Modifier.height(24.dp))
                            Text("ITACHI VOICE MODE", color = Gold, fontSize = 12.sp, letterSpacing = 2.sp)
                            Text("Speak to MAXXA", color = White, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 8.dp))
                            Text("Hindi, Hinglish ya English mein bolo. MAXXA aapki baat sunega.", color = Muted, fontSize = 13.sp, lineHeight = 19.sp, modifier = Modifier.padding(top = 8.dp))
                            Spacer(Modifier.weight(1f))
                            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                                Box(Modifier.size(230.dp).background(Brush.radialGradient(listOf(Color(0x66FF426D), Color(0x22FF78B7), Color.Transparent)), CircleShape))
                                Button(onClick = {
                                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                        status = "Listening…"
                                        onListen(replyLanguage, { spoken -> status = "You said: $spoken"; input = spoken; selectedPage = "Conversation" })
                                    } else voicePermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                }, modifier = Modifier.size(164.dp).scale(micScale), shape = CircleShape, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4B1024), contentColor = White)) {
                                    Text("🎙\nTAP TO SPEAK", textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, lineHeight = 22.sp)
                                }
                            }
                            Text(status, color = Cyan, fontSize = 13.sp, modifier = Modifier.fillMaxWidth().padding(top = 18.dp), textAlign = TextAlign.Center)
                            Spacer(Modifier.weight(1f))
                        }
                        "Permissions" -> {
                            // Read permission state again after every system permission dialog.
                            val permissionRows = listOf(
                                PermissionRow("🎙", "Microphone", "Voice commands", listOf(Manifest.permission.RECORD_AUDIO)),
                                PermissionRow("▣", "SMS", "Read & send messages", listOf(Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS)),
                                PermissionRow("♟", "Notifications", "Post notifications", if (android.os.Build.VERSION.SDK_INT >= 33) listOf(Manifest.permission.POST_NOTIFICATIONS) else emptyList()),
                                PermissionRow("⌖", "Location", "Location services", listOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)),
                                PermissionRow("☎", "Phone / Calls", "Phone state and place calls", listOf(Manifest.permission.READ_PHONE_STATE, Manifest.permission.CALL_PHONE)),
                                PermissionRow("▦", "Calendar", "Calendar events", listOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR)),
                                PermissionRow("▧", "Photos & Videos", "Media access", if (android.os.Build.VERSION.SDK_INT >= 33) listOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO) else listOf(Manifest.permission.READ_EXTERNAL_STORAGE))
                            )
                            Column(Modifier.fillMaxWidth().weight(1f)) {
                                Text("PERMISSIONS", color = Gold, fontSize = 12.sp, letterSpacing = 2.sp)
                                Text("Required for full features", color = Cyan, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp, bottom = 12.dp))
                                LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.weight(1f)) {
                                    items(permissionRows) { row ->
                                        val granted = row.permissions.isNotEmpty() && row.permissions.all { ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED }
                                        Surface(
                                            color = Color(0xEE1A0B12),
                                            shape = RoundedCornerShape(13.dp),
                                            border = androidx.compose.foundation.BorderStroke(1.dp, if (granted) Color(0xFFFF6A91) else Color(0xFF8C2948)),
                                            modifier = Modifier.fillMaxWidth().clickable {
                                                if (row.permissions.isEmpty()) {
                                                    permissionRefresh++
                                                } else {
                                                    permissionLauncher.launch(row.permissions.toTypedArray())
                                                }
                                            }
                                        ) {
                                            Row(Modifier.padding(horizontal = 11.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                                Box(Modifier.size(38.dp).background(if (granted) Color(0x33FF426D) else Color(0x33FF4E86), CircleShape), contentAlignment = Alignment.Center) {
                                                    Text(row.icon, color = if (granted) Cyan else Color(0xFFFF7DAB), fontSize = 18.sp)
                                                }
                                                Column(Modifier.weight(1f).padding(start = 10.dp)) {
                                                    Text(row.title, color = White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                                    Text(row.subtitle, color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 2.dp))
                                                }
                                                Column(horizontalAlignment = Alignment.End) {
                                                    Text(if (granted) "Allowed ✓" else "Not allowed ×", color = if (granted) Color(0xFFFF9FBE) else Color(0xFFFF628A), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                                    Text(if (granted) "Granted" else "Enable", color = Cyan, fontSize = 10.sp, modifier = Modifier.padding(top = 3.dp))
                                                }
                                            }
                                        }
                                    }
                                }
                                OutlinedButton(onClick = {
                                    runCatching { context.startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + context.packageName))) }
                                }, modifier = Modifier.fillMaxWidth().padding(top = 9.dp).height(48.dp), shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan)) {
                                    Text("⚙  MANAGE PERMISSIONS", fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
                                }
                                Text("Only enable permissions for features you use. SMS and phone permissions are sensitive.", color = Muted, fontSize = 10.sp, lineHeight = 14.sp, modifier = Modifier.padding(top = 6.dp, bottom = 4.dp))
                            }
                        }
                        "Voice Pack" -> {
                            SimplePage("VOICE PACK", "Choose how MAXXA responds.", "VOICE LANGUAGE", replyLanguage)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("Hindi / Hinglish", "English").forEach { lang ->
                                    OutlinedButton(onClick = { replyLanguage = lang; prefs.edit().putString("reply_language", lang).apply() }, modifier = Modifier.weight(1f)) { Text(lang, fontSize = 11.sp) }
                                }
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Speak replies", color = White, modifier = Modifier.weight(1f))
                                Switch(voiceEnabled, { enabled -> voiceEnabled = enabled; prefs.edit().putBoolean("voice_enabled", enabled).apply() })
                            }
                        }
                        "API Key" -> {
                            Spacer(Modifier.height(18.dp))
                            Text("SECURE GEMINI CONNECTION", color = Gold, fontSize = 11.sp, letterSpacing = 2.5.sp)
                            Text("Connect your backend", color = White, fontSize = 27.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                            Text("MAXXA does not store a Gemini API key on your phone. Deploy the included backend, set GEMINI_API_KEY as a server secret, then enter its HTTPS URL here.", color = Muted, fontSize = 13.sp, lineHeight = 19.sp, modifier = Modifier.padding(top = 8.dp, bottom = 20.dp))
                            Surface(color = Panel, shape = RoundedCornerShape(22.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x66FF426D)), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(16.dp)) {
                                    Text("BACKEND HTTPS URL", color = Cyan, fontSize = 11.sp, letterSpacing = 1.2.sp)
                                    Spacer(Modifier.height(8.dp))
                                    OutlinedTextField(value = backendUrlInput, onValueChange = { backendUrlInput = it; keySaved = false }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("https://your-server.example.com") }, singleLine = true, shape = RoundedCornerShape(14.dp))
                                    Button(onClick = {
                                        val candidate = backendUrlInput.trim().trimEnd('/')
                                        if (candidate.startsWith("https://")) {
                                            backendUrl = candidate
                                            prefs.edit().putString("backend_url", backendUrl).remove("gemini_api_key").apply()
                                            keySaved = true
                                        } else {
                                            backendUrl = ""
                                            keySaved = false
                                        }
                                    }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp).height(46.dp), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Bg)) { Text("SAVE HTTPS BACKEND", fontWeight = FontWeight.Bold) }
                                    Text("Only HTTPS URLs are accepted. API credentials stay on the server.", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 8.dp))
                                    OutlinedButton(
                                        enabled = backendUrl.isNotBlank() && !checkingBackend,
                                        onClick = {
                                            checkingBackend = true
                                            backendCheck = "Checking secure backend…"
                                            scope.launch {
                                                backendCheck = withContext(Dispatchers.IO) { checkBackendHealth(backendUrl) }
                                                checkingBackend = false
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth().padding(top = 10.dp).height(46.dp),
                                        shape = RoundedCornerShape(15.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan)
                                    ) { Text(if (checkingBackend) "CHECKING…" else "TEST BACKEND CONNECTION", fontWeight = FontWeight.Bold) }
                                    if (backendCheck.isNotBlank()) Text(backendCheck, color = if (backendCheck.startsWith("✓")) Color(0xFFFF9FBE) else Color(0xFFFF8A9E), fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
                                    OutlinedButton(onClick = { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey"))) } }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp).height(48.dp), shape = RoundedCornerShape(15.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan)) { Text("OPEN GOOGLE AI STUDIO", fontWeight = FontWeight.Bold) }
                                    if (keySaved) Text("✓ Secure backend URL saved", color = Color(0xFFFF9FBE), fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
                                }
                            }
                        }
                        "Preferences" -> PreferencesPage(
                            language = replyLanguage,
                            voiceEnabled = voiceEnabled,
                            onLanguageChange = { lang -> replyLanguage = lang; prefs.edit().putString("reply_language", lang).apply() },
                            onVoiceChange = { enabled -> voiceEnabled = enabled; prefs.edit().putBoolean("voice_enabled", enabled).apply() }
                        )
                        "Automation" -> AutomationPage()
                        "Additional Settings" -> AdditionalSettingsPage(
                            backendConfigured = backendUrl.isNotBlank(),
                            historyCount = chats.size,
                            onClearHistory = {
                                chats.clear()
                                chats.add(ChatLine("Chat history cleared. Namaste! Main MAXXA AI hoon.", false))
                                prefs.edit().putString("chat_history", "[]").apply()
                            },
                            onOpenAppSettings = {
                                runCatching { context.startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + context.packageName))) }
                            }
                        )
                        "Image Generation" -> ToolPage(
                            title = "IMAGE PROMPT STUDIO",
                            description = "Generate an image from your prompt using the Gemini image model configured on your secure backend.",
                            placeholder = "A cute chibi character under sakura trees…",
                            buttonText = "GENERATE IMAGE",
                            apiKey = "",
                            instruction = "Create a polished image from the user's description.",
                            backendUrl = backendUrl,
                            replyLanguage = replyLanguage,
                            imageGeneration = true
                        )
                        "Code Generator" -> ToolPage(
                            title = "CODE GENERATOR",
                            description = "Describe the program, platform and language. Ask for complete code plus setup and testing instructions.",
                            placeholder = "Make a Kotlin calculator app…",
                            buttonText = "GENERATE CODE",
                            apiKey = "",
                            instruction = "You are MAXXA AI, an expert programming assistant. Produce a complete, practical solution for the user's request. State assumptions, include code in fenced code blocks, explain where files go, dependencies, run steps and tests. Never claim code was executed unless it was.",
                            backendUrl = backendUrl,
                            replyLanguage = replyLanguage
                        )
                        "Summarize" -> ToolPage(
                            title = "SUMMARIZE",
                            description = "Paste an article, notes or long text. Choose a concise summary, key points and action items in your request.",
                            placeholder = "Paste the text you want summarized…",
                            buttonText = "SUMMARIZE TEXT",
                            apiKey = "",
                            instruction = "You are MAXXA AI. Summarize the user's supplied text accurately without adding unsupported facts. Provide a short overview, key points and any action items when relevant.",
                            backendUrl = backendUrl,
                            replyLanguage = replyLanguage
                        )
                        "Translate" -> ToolPage(
                            title = "TRANSLATE",
                            description = "Paste text and mention the target language, for example Hindi, Hinglish or English.",
                            placeholder = "Text to translate and target language…",
                            buttonText = "TRANSLATE TEXT",
                            apiKey = "",
                            instruction = "You are MAXXA AI, a careful translator. Translate the user's text into the target language they specify. Preserve meaning, tone, names and formatting. If the target language is missing, ask which language they want.",
                            backendUrl = backendUrl,
                            replyLanguage = replyLanguage
                        )
                        "Help & Support" -> SimplePage("HELP & SUPPORT", "For help, check your API key and internet connection. This build has no support ticket integration.", "SUPPORT", "Local help")
                        "About" -> SimplePage("ABOUT MAXXA AI", "MAXXA AI • Itachi and Sakura inspired UI concept.", "VERSION", "Development build")
                        else -> SimplePage(selectedPage.uppercase(), "Itachi Sakura theme • red neon cards • cute anime artwork.", "THEME", "Itachi • Sakura • Crimson Neon")
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.Center) {
                        Text("✦  SMARTER CONVERSATIONS WITH MAXXA AI  ✦", color = Cyan, fontSize = 9.sp, letterSpacing = 0.7.sp)
                    }
                }
                AnimatedVisibility(
                    visible = menuOpen,
                    enter = fadeIn(tween(160)) + slideInHorizontally(tween(220)) { -it },
                    exit = fadeOut(tween(120)) + slideOutHorizontally(tween(180)) { -it }
                ) {
                    Row(Modifier.fillMaxSize().background(Color(0xCC050205))) {
                        Column(Modifier.fillMaxHeight().fillMaxWidth(0.82f).background(Brush.verticalGradient(listOf(Color(0xFF210A13), Bg))).padding(20.dp)) {
                            Surface(color = Color(0x33FF426D), shape = RoundedCornerShape(18.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x66FF426D)), modifier = Modifier.fillMaxWidth()) {
                                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.size(48.dp).background(Brush.linearGradient(listOf(Cyan, Purple)), CircleShape), contentAlignment = Alignment.Center) {
                                        Image(painter = painterResource(id = R.drawable.maxxa_logo), contentDescription = "MAXXA logo", modifier = Modifier.fillMaxSize().padding(2.dp))
                                    }
                                    Column(Modifier.padding(start = 12.dp)) {
                                        Text("MAXXA AI", color = White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                                        Text("PERSONAL ASSISTANT", color = Cyan, fontSize = 9.sp, letterSpacing = 1.5.sp)
                                    }
                                }
                            }
                            Spacer(Modifier.height(22.dp))
                            listOf("Home", "Chat", "Voice Pack", "API Key", "Conversation", "Permissions", "Preferences", "Automation", "Additional Settings", "Help & Support", "About").forEach { item ->
                                Row(Modifier.fillMaxWidth().clickable { selectedPage = item; menuOpen = false }.padding(vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(menuIcon(item), color = if (selectedPage == item) Cyan else Gold, fontSize = 18.sp, modifier = Modifier.width(36.dp))
                                    Text(item, color = if (selectedPage == item) Cyan else White, fontSize = 15.sp, fontWeight = if (selectedPage == item) FontWeight.Bold else FontWeight.Normal)
                                }
                            }
                            Spacer(Modifier.weight(1f))
                            Text("Built for your voice.", color = Muted, fontSize = 12.sp)
                        }
                        Box(Modifier.fillMaxSize().clickable { menuOpen = false })
                    }
                }
            }
        }
    }
}

@Composable
private fun ToolPage(
    title: String,
    description: String,
    placeholder: String,
    buttonText: String,
    apiKey: String,
    instruction: String,
    backendUrl: String = "",
    replyLanguage: String = "Hindi / Hinglish",
    imageGeneration: Boolean = false
) {
    var request by remember(title) { mutableStateOf("") }
    var result by remember(title) { mutableStateOf("") }
    var generatedImage by remember(title) { mutableStateOf<androidx.compose.ui.graphics.ImageBitmap?>(null) }
    var running by remember(title) { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(top = 14.dp, bottom = 12.dp)) {
        Text(title, color = Gold, fontSize = 12.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
        Text(description, color = Muted, fontSize = 13.sp, lineHeight = 19.sp, modifier = Modifier.padding(top = 10.dp, bottom = 16.dp))
        OutlinedTextField(
            value = request,
            onValueChange = { request = it },
            modifier = Modifier.fillMaxWidth().heightIn(min = 130.dp, max = 220.dp),
            placeholder = { Text(placeholder) },
            shape = RoundedCornerShape(16.dp),
            minLines = 4
        )
        Button(
            enabled = !running && request.isNotBlank(),
            onClick = {
                val userRequest = request.trim()
                running = true
                result = ""
                generatedImage = null
                scope.launch {
                    result = try {
                        if (imageGeneration) {
                            val image = withContext(Dispatchers.IO) { requestGeneratedImage(userRequest, backendUrl) }
                            generatedImage = BitmapFactory.decodeByteArray(image.first, 0, image.first.size)?.asImageBitmap()
                            if (generatedImage == null) "Image was returned but could not be decoded on this device." else "Image generated successfully • ${image.second}"
                        } else {
                            withContext(Dispatchers.IO) { askGemini(apiKey, "You are MAXXA AI. Reply primarily in $replyLanguage unless the user requests another language.\n\n$instruction\n\nUser request:\n$userRequest", backendUrl) }
                        }
                    } catch (error: Exception) {
                        error.message?.takeIf { it.isNotBlank() } ?: "MAXXA couldn't complete this request. Check your backend URL and internet connection, then try again."
                    } finally {
                        running = false
                    }
                }
            },
            modifier = Modifier.fillMaxWidth().padding(top = 12.dp).height(50.dp),
            shape = RoundedCornerShape(15.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Bg)
        ) { Text(if (running) "WORKING…" else buttonText, fontWeight = FontWeight.Bold) }
        if (running) {
            LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 12.dp), color = Cyan, trackColor = Panel)
        }
        generatedImage?.let { bitmap ->
            Image(bitmap = bitmap, contentDescription = "Generated image", modifier = Modifier.fillMaxWidth().heightIn(max = 420.dp))
        }
        if (result.isNotBlank()) {
            Text("RESULT", color = Gold, fontSize = 11.sp, letterSpacing = 2.sp, modifier = Modifier.padding(top = 18.dp, bottom = 8.dp))
            Surface(
                color = Panel,
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x66FF426D)),
                modifier = Modifier.fillMaxWidth().weight(1f, fill = false)
            ) {
                LazyColumn(Modifier.padding(14.dp).heightIn(max = 360.dp)) {
                    item { Text(result, color = White, fontSize = 13.sp, lineHeight = 19.sp) }
                }
            }
        }
    }
}

private data class PermissionRow(val icon: String, val title: String, val subtitle: String, val permissions: List<String>)

private fun menuIcon(item: String) = when (item) {
    "Home" -> "⌂"; "Chat" -> "☷"; "Voice" -> "♫"; "Permissions" -> "◈"; "Voice Pack" -> "♫"; "API Key" -> "⌘"
    "Conversation" -> "☷"; "Preferences" -> "⚙"; "Automation" -> "⌁"; else -> "⋯"
}

@Composable
private fun SplashScreen() {
    val transition = rememberInfiniteTransition(label = "splash")
    val pulse by transition.animateFloat(0.94f, 1.06f, infiniteRepeatable(tween(950), RepeatMode.Reverse), label = "splash-pulse")
    Box(Modifier.fillMaxSize().background(Color(0xFF090509))) {
        Image(
            painter = painterResource(id = R.drawable.itachi_splash_art),
            contentDescription = "Cute Itachi Uchiha with sakura blossoms",
            modifier = Modifier.fillMaxSize(),
            contentScale = androidx.compose.ui.layout.ContentScale.Crop
        )
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x55060005), Color(0x9910060C), Color(0xEE090509)))))
        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 30.dp, vertical = 42.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(104.dp).scale(pulse).background(Brush.radialGradient(listOf(Color(0x88FF426D), Color(0x33FF78B7), Color.Transparent)), CircleShape), contentAlignment = Alignment.Center) {
                Box(Modifier.size(78.dp).background(Brush.linearGradient(listOf(Cyan, Purple)), CircleShape).padding(3.dp).background(Bg, CircleShape), contentAlignment = Alignment.Center) {
                    Image(painter = painterResource(id = R.drawable.maxxa_logo), contentDescription = "MAXXA AI logo", modifier = Modifier.fillMaxSize().padding(4.dp))
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("MAXXA AI", color = White, fontSize = 30.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
            Text("YOUR CUTE AI COMPANION", color = Color(0xFFFFA6C8), fontSize = 10.sp, letterSpacing = 2.4.sp, modifier = Modifier.padding(top = 7.dp))
            Spacer(Modifier.height(22.dp))
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth().height(5.dp), color = Cyan, trackColor = Color(0x55FF426D))
            Text("AWAKENING THE SHARINGAN…", color = White, fontSize = 10.sp, letterSpacing = 1.5.sp, modifier = Modifier.padding(top = 12.dp))
        }
    }
}

@Composable
private fun QuickCard(title: String, subtitle: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(modifier = modifier.clickable(onClick = onClick), color = Panel, shape = RoundedCornerShape(18.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x66FF426D))) {
        Column(Modifier.padding(15.dp)) {
            Text(title, color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Text(subtitle, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

@Composable
private fun PreferencesPage(
    language: String,
    voiceEnabled: Boolean,
    onLanguageChange: (String) -> Unit,
    onVoiceChange: (Boolean) -> Unit
) {
    Column(Modifier.fillMaxWidth().padding(top = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("PREFERENCES", color = Gold, fontSize = 12.sp, letterSpacing = 2.sp)
        Text("Make MAXXA work your way", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("RESPONSE LANGUAGE", color = Cyan, fontSize = 11.sp, letterSpacing = 1.sp)
                listOf("Hindi / Hinglish", "English").forEach { option ->
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().clickable { onLanguageChange(option) }) {
                        RadioButton(selected = language == option, onClick = { onLanguageChange(option) })
                        Text(option, color = White, fontSize = 14.sp)
                    }
                }
                Divider(color = Color(0x553D2530))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Speak AI replies", color = White, fontWeight = FontWeight.SemiBold)
                        Text("Read MAXXA responses aloud", color = Muted, fontSize = 11.sp)
                    }
                    Switch(checked = voiceEnabled, onCheckedChange = onVoiceChange)
                }
            }
        }
        Text("Your choices are saved on this device.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun AutomationPage() {
    val context = LocalContext.current
    fun launch(intent: Intent, fallback: String) {
        runCatching { context.startActivity(intent) }.onFailure {
            android.widget.Toast.makeText(context, fallback, android.widget.Toast.LENGTH_SHORT).show()
        }
    }
    Column(Modifier.fillMaxWidth().padding(top = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("SAFE PHONE SHORTCUTS", color = Gold, fontSize = 12.sp, letterSpacing = 2.sp)
        Text("You stay in control", color = White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text("These shortcuts open Android apps. MAXXA will not send messages, place calls, or change settings without your action.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
        Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { launch(Intent(Intent.ACTION_DIAL), "Dialer is unavailable") }, modifier = Modifier.fillMaxWidth()) { Text("OPEN PHONE DIALER") }
                OutlinedButton(onClick = { launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")), "Browser is unavailable") }, modifier = Modifier.fillMaxWidth()) { Text("OPEN BROWSER") }
                OutlinedButton(onClick = { launch(Intent(android.provider.Settings.ACTION_SETTINGS), "Settings are unavailable") }, modifier = Modifier.fillMaxWidth()) { Text("OPEN ANDROID SETTINGS") }
                OutlinedButton(onClick = { launch(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING), "Messaging app is unavailable") }, modifier = Modifier.fillMaxWidth()) { Text("OPEN MESSAGING APP") }
            }
        }
        Text("Advanced automation is not enabled in this build. No hidden monitoring or automatic actions.", color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun AdditionalSettingsPage(
    backendConfigured: Boolean,
    historyCount: Int,
    onClearHistory: () -> Unit,
    onOpenAppSettings: () -> Unit
) {
    var confirmClear by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().padding(top = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("ADDITIONAL SETTINGS", color = Gold, fontSize = 12.sp, letterSpacing = 2.sp)
        Text("App management", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("BACKEND", color = Cyan, fontSize = 11.sp)
                Text(if (backendConfigured) "HTTPS backend URL saved" else "Backend not configured", color = White, fontSize = 13.sp)
                Divider(color = Color(0x553D2530))
                Text("CHAT HISTORY", color = Cyan, fontSize = 11.sp)
                Text("$historyCount messages stored locally", color = White, fontSize = 13.sp)
                OutlinedButton(onClick = { confirmClear = true }, modifier = Modifier.fillMaxWidth()) { Text("CLEAR CHAT HISTORY") }
                OutlinedButton(onClick = onOpenAppSettings, modifier = Modifier.fillMaxWidth()) { Text("OPEN ANDROID APP SETTINGS") }
                Text("MAXXA AI • Development build", color = Muted, fontSize = 10.sp)
            }
        }
    }
    if (confirmClear) AlertDialog(
        onDismissRequest = { confirmClear = false },
        title = { Text("Clear chat history?") },
        text = { Text("This removes locally saved conversation messages from this device.") },
        confirmButton = { TextButton(onClick = { onClearHistory(); confirmClear = false }) { Text("Clear") } },
        dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } }
    )
}

@Composable
private fun SimplePage(title: String, body: String, label: String, value: String) {
    Column(Modifier.fillMaxWidth().padding(top = 16.dp)) {
        Text(title, color = Gold, fontSize = 12.sp, letterSpacing = 2.sp)
        Text(body, color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold, lineHeight = 27.sp, modifier = Modifier.padding(top = 12.dp))
        Spacer(Modifier.height(20.dp))
        Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text(label, color = Cyan, fontSize = 11.sp, letterSpacing = 1.5.sp)
                Text(value, color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
            }
        }
    }
}

private fun checkBackendHealth(backendUrl: String): String {
    if (!backendUrl.trim().startsWith("https://")) return "Only HTTPS backend URLs are accepted."
    var connection: HttpURLConnection? = null
    return try {
        val base = backendUrl.trim().trimEnd('/')
        connection = (URL("$base/health").openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 10_000
            readTimeout = 10_000
            setRequestProperty("Accept", "application/json")
        }
        val code = connection.responseCode
        val body = (if (code in 200..299) connection.inputStream else connection.errorStream)
            ?.bufferedReader()?.use { it.readText() }.orEmpty()
        val json = runCatching { JSONObject(body) }.getOrNull()
        if (code in 200..299 && json?.optBoolean("ok") == true) "✓ Backend is reachable and healthy."
        else "Backend health check failed (HTTP $code). Verify deployment and server logs."
    } catch (_: Exception) {
        "Backend is unreachable. Check the HTTPS URL, deployment and internet connection."
    } finally {
        connection?.disconnect()
    }
}

private fun requestGeneratedImage(prompt: String, backendUrl: String): Pair<ByteArray, String> {
    require(backendUrl.trim().startsWith("https://")) { "Configure a secure HTTPS backend in the API Key screen first." }
    var connection: HttpURLConnection? = null
    try {
        val base = backendUrl.trim().trimEnd('/')
        connection = (URL("$base/api/image").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20_000
            readTimeout = 100_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
        }
        val payload = JSONObject().put("prompt", prompt).put("aspectRatio", "1:1").toString()
        connection.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val body = (if (code in 200..299) connection.inputStream else connection.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
        val json = runCatching { JSONObject(body) }.getOrNull()
        if (code !in 200..299) throw IllegalStateException("Image backend error (HTTP $code): ${json?.optString("error").orEmpty().ifBlank { "Check model access, quota and server logs." }}")
        val encoded = json?.optString("imageBase64").orEmpty()
        if (encoded.isBlank()) throw IllegalStateException("Backend returned no image data.")
        val mime = json?.optString("mimeType").orEmpty().ifBlank { "image/png" }
        return Base64.decode(encoded, Base64.DEFAULT) to mime
    } finally { connection?.disconnect() }
}

private fun askGemini(apiKey: String, message: String, backendUrl: String = ""): String {
    if (backendUrl.isBlank()) {
        return "No secure backend configured. Open the menu → API Key and save your deployed HTTPS backend URL."
    }
    var proxy: HttpURLConnection? = null
    return try {
        val base = backendUrl.trim().trimEnd('/')
        if (!base.startsWith("https://")) return "For security, MAXXA accepts HTTPS backend URLs only."
        proxy = (URL("$base/api/chat").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 60000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
        }
        val payload = JSONObject().put("message", message).toString()
        proxy.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
        val code = proxy.responseCode
        val body = (if (code in 200..299) proxy.inputStream else proxy.errorStream)
            ?.bufferedReader()?.use { it.readText() }.orEmpty()
        val json = runCatching { JSONObject(body) }.getOrNull()
        if (code in 200..299) {
            json?.optString("text")?.takeIf { it.isNotBlank() }
                ?: json?.optString("answer")?.takeIf { it.isNotBlank() }
                ?: "Backend returned an empty response."
        } else {
            "Backend error (HTTP $code): ${json?.optString("error").orEmpty().ifBlank { "Check backend configuration and server logs." }}"
        }
    } catch (_: Exception) {
        "Couldn't reach the secure backend. Check its HTTPS URL, deployment status and internet connection."
    } finally {
        proxy?.disconnect()
    }
}
