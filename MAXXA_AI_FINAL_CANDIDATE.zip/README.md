# MAXXA AI — Android project

Kotlin + Jetpack Compose Android app (`com.maxxa.ai`) with an Itachi/Sakura-inspired interface and a separate Node.js backend.

## Included
- Home, chat, navigation, secure-backend configuration and voice input/output screens.
- Gemini text chat routed through the HTTPS backend; provider credentials stay on the server.
- Recent conversation context and locally stored chat messages.
- AI-assisted Code Generator, Summarize and Translate prompt screens.
- Gemini-powered image generation through the secure backend (`/api/image`); generated image is displayed in the app. Requires access/quota for the configured image model.
- Backend health endpoint, request limits, rate limiting, bounded provider responses and automated Node tests.
- A single hardened backend app is now used by both tests and the production server entry point; graceful shutdown and port validation are included.
- GitHub Actions workflow that runs backend checks and builds/uploads a debug APK.

## Important limitations
This is a development build, not a finished production release. Complete phone automation/accessibility actions, cloud sync, user accounts, production abuse monitoring, release signing and Play Store compliance are not implemented. Image generation is wired end-to-end but requires a deployed backend and an enabled Gemini image model. The Android APK build and on-device runtime behavior must be verified by a successful GitHub Actions run and device testing. Backend automated tests could not be executed in this workspace because npm registry DNS/network access was unavailable; JavaScript syntax checks passed. The backend must be deployed separately and given a `GEMINI_API_KEY` secret by its host.

## GitHub build
1. Upload the extracted project folders and files to a GitHub repository (not only the ZIP file).
2. Push to `main`/`master`, open **Actions**, or run **Build MAXXA AI** manually.
3. Confirm both **Backend syntax and tests** and **Build Android debug APK** jobs pass.
4. Download the `MAXXA-AI-debug-APK` artifact from the successful workflow run.

Backend changes now trigger the workflow too. The workflow installs Node.js 22 dependencies, runs `node --check` on both backend files and executes `npm test` before the Android build.

## Backend configuration
See [`backend/README.md`](backend/README.md). Deploy the backend to a host that supports Node.js 20+, set `GEMINI_API_KEY` as a server-side secret, and configure the resulting HTTPS base URL in the app's API Key screen. Never commit `.env`, real API keys, signing keys or keystores.

## Art and distribution
The included anime-inspired artwork may be copyrighted. Replace it with original or licensed artwork before public distribution.
