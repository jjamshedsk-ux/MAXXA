# MAXXA AI — Android Project

Kotlin + Jetpack Compose Android app project.

## Included screens
- Animated splash/loading screen
- Home dashboard with MAXXA logo, greeting, AI access card, Chat/Voice/Image shortcuts, microphone action
- Side navigation drawer
- Conversation screen using the configured Gemini API key
- API key settings
- Voice Pack settings with Hindi/Hinglish and English choices, TTS test, speech input
- Permissions screen
- Preferences screen
- Automation shortcut guide
- Additional Settings and local API-key removal

## Build
Open this folder in Android Studio and sync Gradle. Use JDK 17 and Android SDK 35. Then run the `app` configuration on a device with internet access.

## Important limitations
- This source has not been compiled or device-tested in the current environment.
- The supplied `maxxa_ui_reference.png` is a visual reference montage, not a live UI skin. A pixel-perfect match to every reference panel has not been verified.
- Gemini calls require the user to provide a valid API key in the app. Storing a key directly on-device is not secure for a public release; use a backend proxy before distributing the app.
- Image exploration and actual device automation are placeholders; they are not implemented as full AI image understanding or unrestricted phone control.
