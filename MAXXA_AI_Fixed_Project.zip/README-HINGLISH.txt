MAXXA AI Android project

1. ZIP extract karo.
2. Is project ke files apni GitHub repository mein upload/replace karo.
3. Firebase Console mein project maxxa-ai ke andar AI Logic enable karo.
4. GitHub repository ke Actions tab mein 'Build MAXXA AI' workflow run karo.
5. Successful build ke baad Actions run ke Artifacts section se MAXXA-AI-debug-APK download karo.

Note: ZIP generate hua hai, lekin is environment mein Android Gradle build run karke verify nahi kiya gaya.
Debug App Check token ko Firebase Console mein register karna pad sakta hai.
Debug token ya debug APK ko public production release ke liye use mat karo.
