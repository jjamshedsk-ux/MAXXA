#!/usr/bin/env python3
"""Offline source-contract checks for MAXXA AI; not a substitute for Android builds/tests."""
from pathlib import Path
import re
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
ANDROID_NS = '{http://schemas.android.com/apk/res/android}'


def require(condition: bool, message: str) -> None:
    if not condition:
        raise SystemExit(f'FAIL: {message}')
    print(f'PASS: {message}')

manifest = ET.parse(ROOT / 'app/src/main/AndroidManifest.xml').getroot()
app = manifest.find('application')
require(app is not None, 'Android application element exists')
require(app.attrib.get(ANDROID_NS + 'usesCleartextTraffic') == 'false', 'cleartext traffic disabled')
service = app.find("service[@{0}name='.MaxxaAccessibilityService']".format(ANDROID_NS))
require(service is not None, 'AccessibilityService declared')
require(service.attrib.get(ANDROID_NS + 'permission') == 'android.permission.BIND_ACCESSIBILITY_SERVICE', 'AccessibilityService is system-bound')
require(service.attrib.get(ANDROID_NS + 'exported') == 'true', 'AccessibilityService exported for Android binding')

cfg = ET.parse(ROOT / 'app/src/main/res/xml/maxxa_accessibility_service.xml').getroot()
require(cfg.attrib.get(ANDROID_NS + 'canRetrieveWindowContent') == 'false', 'Accessibility cannot retrieve window content')
require(cfg.attrib.get(ANDROID_NS + 'canPerformGestures') == 'false', 'Accessibility cannot perform gestures')
require(cfg.attrib.get(ANDROID_NS + 'accessibilityEventTypes') == 'typeWindowStateChanged', 'Accessibility event scope is minimized')

service_src = (ROOT / 'app/src/main/java/com/maxxa/ai/MaxxaAccessibilityService.kt').read_text()
for action in ('GLOBAL_ACTION_BACK', 'GLOBAL_ACTION_HOME', 'GLOBAL_ACTION_RECENTS',
               'GLOBAL_ACTION_NOTIFICATIONS', 'GLOBAL_ACTION_QUICK_SETTINGS'):
    require(action in service_src, f'phone action mapping exists: {action}')
require('getRootInActiveWindow' not in service_src and 'dispatchGesture' not in service_src,
        'no screen scraping or gesture automation APIs in service')

app_gradle = (ROOT / 'app/build.gradle.kts').read_text()
root_gradle = (ROOT / 'build.gradle.kts').read_text()
workflow = (ROOT / '.github/workflows/android-build.yml').read_text()
require('compileSdk = 35' in app_gradle and 'targetSdk = 35' in app_gradle, 'Android SDK levels configured')
require('8.7.3' in root_gradle and '2.0.21' in root_gradle, 'Android/Kotlin plugin versions pinned')
require('java-version: \'17\'' in workflow and 'gradle-version: \'8.9\'' in workflow,
        'CI Java and Gradle versions configured')
require('assembleDebug' in workflow and 'upload-artifact@v4' in workflow,
        'CI builds and uploads debug APK artifact')

for file_name in ('backend/app.js', 'backend/server.js', 'backend/test/app.test.js'):
    require((ROOT / file_name).is_file(), f'backend source present: {file_name}')
print('All offline source-contract checks passed. This does not prove Kotlin compilation or runtime behavior.')
