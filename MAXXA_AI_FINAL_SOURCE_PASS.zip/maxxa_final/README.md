# MAXXA AI — Android project

Kotlin + Jetpack Compose Android app (`com.maxxa.ai`) with an Itachi/Sakura-inspired interface and a separate Node.js backend.

## Included
- Home, chat, navigation, secure-backend configuration and voice input/output screens, including a stop-listening control.
- Gemini text chat routed through the HTTPS backend; provider credentials stay on the server.
- Recent conversation context and locally stored chat messages.
- AI-assisted Code Generator, Summarize and Translate prompt screens.
- Gemini-powered image generation through the secure backend (`/api/image`); generated image is displayed in the app. Requires access/quota for the configured image model.
- Backend health endpoint, request limits, rate limiting, bounded provider responses and automated Node tests.
- Strict HTTPS backend URL validation (hostname required; URL credentials, query strings and fragments rejected).
- Local app backup is disabled so chat history and preferences are not included in Android device backups.
- A single hardened backend app is now used by both tests and the production server entry point; graceful shutdown and port validation are included.
- User-enabled, least-privilege Accessibility bridge for five explicit navigation actions: Back, Home, Recents, Notifications and Quick Settings. It does not inspect screen content, tap arbitrary controls, type, or make calls.
- GitHub Actions workflow that runs backend checks, offline source-contract checks, and builds/uploads a debug APK.

## Important limitations
This is a development build, not a finished production release. Unrestricted automation of arbitrary third-party apps, cloud sync, user accounts, production abuse monitoring, release signing and Play Store compliance are not implemented. Phone control is intentionally limited to five user-triggered Android global navigation actions. Image generation is wired end-to-end but requires a deployed backend and an enabled Gemini image model. The Android APK build and on-device runtime behavior must be verified by a successful GitHub Actions run and device testing. An offline source-contract script validates key manifest, accessibility-scope and CI configuration assumptions, but it is not a substitute for compilation or runtime tests. Backend automated tests could not be executed in this workspace because npm registry DNS/network access was unavailable; JavaScript syntax checks passed. A follow-up guard was added for oversized image responses based on declared Content-Length. The backend must be deployed separately and given a `GEMINI_API_KEY` secret by its host. The backend supports an optional bearer access token (`MAXXA_CLIENT_TOKEN`), stricter per-IP chat/image limits, bounded upstream responses and configurable trusted-proxy hops. Set a random 32+ character token before public deployment and enter it in the app's Backend Access Token field; the app encrypts it with Android Keystore. Rate-limit counters are in-memory and reset on restart, so production multi-instance deployments still need a shared rate-limit store, provider spending budgets and monitoring.

## Android build configuration
- Android Gradle Plugin 8.7.3 with Gradle 8.9 and Java 17.
- Compile SDK / target SDK 35 (Android 15); minimum SDK 26.
- CI explicitly installs Android SDK Platform 35 and Build Tools 35.0.0 before compiling.
- Manifest declares speech-recognition and text-to-speech service queries for Android package-visibility behavior.

## GitHub build
1. Upload the extracted project folders and files to a GitHub repository (not only the ZIP file).
2. Push to `main`/`master`, open **Actions**, or run **Build MAXXA AI** manually.
3. Confirm the **Build Android debug APK** job passes. The separate backend job can fail independently if npm dependencies or backend tests fail.
4. Download the `MAXXA-AI-debug-APK` artifact from the successful Android workflow run.

Backend changes now trigger the workflow too. The workflow installs Node.js 22 dependencies, runs `node --check` on both backend files and executes `npm test` in its backend job. The Android job separately installs Java 17, Android SDK Platform 35 / Build Tools 35.0.0 and Gradle 8.9, then runs `assembleDebug`.

## Backend configuration
See [`backend/README.md`](backend/README.md). Deploy the backend to a Node.js 20+ host or with the included Dockerfile, set `GEMINI_API_KEY` and a random 32+ character `MAXXA_CLIENT_TOKEN` as server-side secrets, and configure the HTTPS base URL plus matching access token in the app's API Key screen. Never commit `.env`, real API keys, signing keys or keystores.

## Art and distribution
The included anime-inspired artwork may be copyrighted. Replace it with original or licensed artwork before public distribution.

### AI feature connection
Configure the deployed HTTPS backend URL and the same `MAXXA_CLIENT_TOKEN` in the app's API Key screen. The Gemini provider key belongs only in the backend environment as `GEMINI_API_KEY`. Chat, Code Generator, Summarize, Translate, and Image Generation use the backend proxy; the Android app must not contain the Gemini provider key.

## Phone control
Open MAXXA AI → Phone Control → Enable Accessibility Actions. Android requires the user to enable the service manually in system Accessibility settings. The service is designed to use only explicit global navigation actions and does not request window-content or gesture access. Availability of individual global actions may vary by Android version and device manufacturer.
