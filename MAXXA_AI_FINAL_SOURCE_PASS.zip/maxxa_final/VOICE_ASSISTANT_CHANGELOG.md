# MAXXA AI Voice Assistant — Consolidated Source Pass

## Updated
- Hindi, English, and Hindi/Hinglish recognition prompts.
- SpeechRecognizer error mapping for network, timeout, no-match, microphone permission, busy service, and service errors.
- Defensive handling when speech recognition is unavailable or cannot start.
- Voice errors now remain status messages instead of being submitted as user chat text.
- Text-to-Speech locale fallback if a requested voice is unavailable.
- Stop Listening stops pending recognition and speech output.
- Activity teardown cancels recognition and releases speech resources.

## Device-dependent checks still required
- Confirm Google/Android speech recognition service is installed and enabled.
- Grant microphone permission and test Hindi/Hinglish/English recognition on-device.
- Confirm installed TTS engine has Hindi and English voices; fallback is English if Hindi is unavailable.
- Verify network-dependent recognition behavior, interruptions, Bluetooth/headset routing, and screen lifecycle on the target phone.
- Compile the Android app and test on a physical device.

## Final source review fixes (2026-10-31)
- Invalid backend URL saves now clear the previously saved endpoint and encrypted access token instead of leaving an old backend silently active.
- Reset Settings now also clears the in-memory backend token fields and connection-check state, matching the cleared preferences.
- These are source-level state/security consistency fixes; Android compilation and device validation remain intentionally pending.
