package com.maxxa.ai

import android.Manifest
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import android.util.Base64
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.spec.GCMParameterSpec
import java.security.KeyStore

private val Bg = Color(0xFF090509)
private val Panel = Color(0xFF1A0B12)
private val Cyan = Color(0xFFFF426D)
private val Purple = Color(0xFFFF78B7)
private val Gold = Color(0xFFFFA6C8)
private val White = Color(0xFFF4F6FF)
private val Muted = Color(0xFFCC9BAE)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var ignoreSpeechCallback = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val engine = tts ?: return@TextToSpeech
                val preferred = Locale("hi", "IN")
                val availability = engine.isLanguageAvailable(preferred)
                engine.language = if (availability >= TextToSpeech.LANG_AVAILABLE) preferred else Locale("en", "IN")
                engine.setSpeechRate(1.0f)
                engine.setPitch(1.0f)
            }
        }
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        }
        setContent { MaxxaApp(
            onListen = { language, onResult -> listen(language, onResult) },
            onStopListening = {
                ignoreSpeechCallback = true
                speechRecognizer?.cancel()
                tts?.stop()
            },
            onSpeak = { text, language ->
                val locale = when (language) {
                    "Hindi" -> Locale("hi", "IN")
                    "English" -> Locale("en", "IN")
                    else -> Locale("hi", "IN")
                }
                tts?.let { engine ->
                    val availability = engine.isLanguageAvailable(locale)
                    val selectedLocale = if (availability >= TextToSpeech.LANG_AVAILABLE) locale else Locale("en", "IN")
                    engine.language = selectedLocale
                    engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "maxxa-reply")
                }
            }
        ) }
    }

    private fun listen(language: String, onResult: (String) -> Unit) {
        ignoreSpeechCallback = false
        val recognizer = speechRecognizer ?: run { onResult("VOICE_ERROR::Speech recognition is unavailable. Install or enable a speech recognition service in Android settings."); return }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            val localeTag = when (language) {
                "English" -> "en-IN"
                "Hindi" -> "hi-IN"
                else -> "hi-IN"
            }
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, localeTag)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, localeTag)
            putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PROMPT, if (language == "English") "Speak in English" else if (language == "Hindi") "हिंदी में बोलें" else "Hindi or Hinglish mein boliye")
        }
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                if (ignoreSpeechCallback) {
                    ignoreSpeechCallback = false
                } else {
                    val message = when (error) {
                        SpeechRecognizer.ERROR_AUDIO -> "Microphone audio error. Please try again."
                        SpeechRecognizer.ERROR_CLIENT -> "Voice service was interrupted. Tap to try again."
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is missing. Allow it in Android settings."
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech service network unavailable. Check your internet connection."
                        SpeechRecognizer.ERROR_NO_MATCH -> "I couldn't understand that. Please speak clearly and try again."
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Voice service is busy. Wait a moment and try again."
                        SpeechRecognizer.ERROR_SERVER -> "Speech service error. Please try again later."
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech detected. Tap the microphone and speak."
                        else -> "Voice input failed (code $error). Please try again."
                    }
                    onResult("VOICE_ERROR::$message")
                }
            }
            override fun onResults(results: Bundle?) {
                if (ignoreSpeechCallback) {
                    ignoreSpeechCallback = false
                } else {
                    val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty().trim()
                    if (spoken.isBlank()) onResult("VOICE_ERROR::I couldn't hear that clearly. Please try again.") else onResult(spoken)
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        try {
            recognizer.startListening(intent)
        } catch (exception: SecurityException) {
            onResult("VOICE_ERROR::Microphone permission is required. Allow microphone access and try again.")
        } catch (exception: IllegalStateException) {
            onResult("VOICE_ERROR::Voice service is busy. Wait a moment and try again.")
        } catch (exception: RuntimeException) {
            onResult("VOICE_ERROR::Could not start voice input. Please restart the app and try again.")
        }
    }

    override fun onDestroy() {
        ignoreSpeechCallback = true
        speechRecognizer?.cancel()
        speechRecognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

private data class ChatLine(val text: String, val isUser: Boolean)

@Composable
private fun MaxxaApp(
    onListen: (String, (String) -> Unit) -> Unit,
    onStopListening: () -> Unit,
    onSpeak: (String, String) -> Unit
) {
    var showSplash by remember { mutableStateOf(true) }
    var menuOpen by remember { mutableStateOf(false) }
    var selectedPage by remember { mutableStateOf("Home") }
    var input by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Ready when you are") }
    var isListening by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("maxxa_settings", android.content.Context.MODE_PRIVATE) }
    val apiKey = "" // Provider keys are never stored in the Android app.
    var backendUrl by remember { mutableStateOf(prefs.getString("backend_url", "").orEmpty()) }
    var backendUrlInput by remember { mutableStateOf(backendUrl) }
    var backendToken by remember { mutableStateOf(decryptBackendToken(context, prefs.getString("backend_token_enc", "").orEmpty())) }
    var backendTokenInput by remember { mutableStateOf(backendToken) }
    var keySaved by remember { mutableStateOf(false) }
    var permissionRefresh by remember { mutableIntStateOf(0) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        permissionRefresh++
    }
    var voiceEnabled by remember { mutableStateOf(prefs.getBoolean("voice_enabled", true)) }
    var autoSave by remember { mutableStateOf(prefs.getBoolean("auto_save", true)) }
    var typingIndicator by remember { mutableStateOf(prefs.getBoolean("typing_indicator", true)) }
    var textSize by remember { mutableStateOf(prefs.getString("text_size", "Medium").orEmpty()) }
    var chatStyle by remember { mutableStateOf(prefs.getString("chat_style", "Modern").orEmpty()) }
    var replyLanguage by remember { mutableStateOf(prefs.getString("reply_language", "Hindi / Hinglish").orEmpty()) }
    val voicePermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        permissionRefresh++
        if (granted) {
            isListening = true
            status = "Listening…"
            selectedPage = "Voice"
            onListen(replyLanguage, { spoken ->
                isListening = false
                if (spoken.startsWith("VOICE_ERROR::")) {
                    status = spoken.removePrefix("VOICE_ERROR::")
                } else {
                    status = "You said: $spoken"
                    input = spoken
                    selectedPage = "Chat"
                }
            })
        } else status = "Microphone permission is required for voice input."
    }
    var backendCheck by remember { mutableStateOf("") }
    var checkingBackend by remember { mutableStateOf(false) }
    val chats = remember {
        mutableStateListOf<ChatLine>().apply {
            val saved = runCatching { org.json.JSONArray(prefs.getString("chat_history", "[]")) }.getOrNull()
            if (saved != null) {
                for (i in 0 until saved.length()) {
                    val item = saved.optJSONObject(i) ?: continue
                    val text = item.optString("text")
                    if (text.isNotBlank()) add(ChatLine(text, item.optBoolean("isUser")))
                }
            }
            if (isEmpty()) add(ChatLine("Namaste! Main MAXXA AI hoon. Bolo, main kaise help karun?", false))
        }
    }
    LaunchedEffect(chats.size, autoSave) {
        if (autoSave) {
            val saved = org.json.JSONArray()
            chats.forEach { line -> saved.put(JSONObject().put("text", line.text).put("isUser", line.isUser)) }
            prefs.edit().putString("chat_history", saved.toString()).apply()
        }
    }
    val scope = rememberCoroutineScope()
    val pulse = rememberInfiniteTransition(label = "mic-pulse")
    val micScale by pulse.animateFloat(1f, 1.07f, infiniteRepeatable(tween(1250, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "mic-scale")

    LaunchedEffect(Unit) { delay(1750); showSplash = false }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Cyan, secondary = Purple, background = Bg, surface = Panel,
        onPrimary = Bg, onBackground = White, onSurface = White
    )) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1A0710), Bg, Color(0xFF080407))))) {
            Image(
                painter = painterResource(id = R.drawable.itachi_splash_art),
                contentDescription = null,
                modifier = Modifier.fillMaxSize().alpha(0.13f),
                contentScale = androidx.compose.ui.layout.ContentScale.Crop
            )
            AnimatedVisibility(
                visible = showSplash,
                enter = fadeIn(tween(260)),
                exit = fadeOut(tween(360))
            ) {
                SplashScreen()
            }
            if (!showSplash) {
                Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
                    Row(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(if (selectedPage == "Home") "☰" else "‹", color = Cyan, fontSize = 29.sp, modifier = Modifier.clickable { if (selectedPage == "Home") menuOpen = true else selectedPage = "Home" }.padding(end = 16.dp))
                        if (selectedPage == "Home") {
                            Column(Modifier.weight(1f)) {
                                Text("MAXXA AI", color = White, fontSize = 21.sp, fontWeight = FontWeight.Black)
                                Text("YOUR AI ASSISTANT", color = Cyan, fontSize = 9.sp, letterSpacing = 2.sp)
                            }
                            Text("♙", color = Gold, fontSize = 20.sp, modifier = Modifier.clickable { selectedPage = "Additional Settings" }.padding(horizontal = 8.dp))
                            Text("♧", color = Gold, fontSize = 20.sp, modifier = Modifier.clickable { selectedPage = "Permissions" }.padding(horizontal = 5.dp))
                        } else {
                            Column(Modifier.weight(1f)) {
                                Text(if (selectedPage == "Chat") "MAXXA AI" else selectedPage, color = White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                                Text(if (selectedPage == "Chat") "● ONLINE" else "MAXXA AI • PERSONAL ASSISTANT", color = if (selectedPage == "Chat") Color(0xFFFF9FBE) else Muted, fontSize = 9.sp, letterSpacing = 1.sp)
                            }
                        }
                    }
                    Box(Modifier.weight(1f).fillMaxWidth()) {
                        AnimatedContent(
                            targetState = selectedPage,
                            transitionSpec = {
                                (fadeIn(tween(190)) + slideInVertically(tween(190)) { it / 24 }) togetherWith
                                    (fadeOut(tween(120)) + slideOutVertically(tween(120)) { -it / 32 })
                            },
                            label = "maxxa-page-transition"
                        ) { page ->
                            Column(Modifier.fillMaxSize()) {
                                when (page) {
                        "Home" -> {
                            LazyColumn(
                                modifier = Modifier.weight(1f).fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(14.dp),
                                contentPadding = PaddingValues(bottom = 8.dp)
                            ) {
                                item {
                                    Box(
                                        Modifier.fillMaxWidth().height(242.dp),
                                        contentAlignment = Alignment.BottomStart
                                    ) {
                                        Image(
                                            painter = painterResource(id = R.drawable.itachi_splash_art),
                                            contentDescription = "MAXXA anime artwork",
                                            modifier = Modifier.fillMaxSize(),
                                            contentScale = androidx.compose.ui.layout.ContentScale.Crop
                                        )
                                        Box(
                                            Modifier.fillMaxSize().background(
                                                Brush.verticalGradient(listOf(Color(0x22090005), Color(0xAA090509), Color(0xF5090509)))
                                            )
                                        )
                                        Column(Modifier.fillMaxWidth().padding(16.dp)) {
                                            Text("HELLO, I'M MAXXA", color = Color(0xFFFFA6C8), fontSize = 11.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                                            Text("Your AI Assistant", color = White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                                            Text("Ask me anything…", color = Muted, fontSize = 12.sp)
                                        }
                                    }
                                }
                                item {
                                    Surface(
                                        color = Color(0xEE160A11),
                                        shape = RoundedCornerShape(18.dp),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xAAFF426D)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(Modifier.padding(start = 12.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                            OutlinedTextField(
                                                value = input,
                                                onValueChange = { input = it },
                                                modifier = Modifier.weight(1f),
                                                placeholder = { Text("Ask me anything…", color = Muted) },
                                                singleLine = true,
                                                shape = RoundedCornerShape(14.dp),
                                                colors = OutlinedTextFieldDefaults.colors(
                                                    unfocusedBorderColor = Color.Transparent,
                                                    focusedBorderColor = Color.Transparent,
                                                    cursorColor = Cyan
                                                )
                                            )
                                            IconButton(onClick = {
                                                if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                                    status = "Listening…"
                                                    isListening = true
                                                    selectedPage = "Voice"
                                                    onListen(replyLanguage) { spoken ->
                                                        isListening = false
                                                        if (spoken.startsWith("VOICE_ERROR::")) {
                                                            status = spoken.removePrefix("VOICE_ERROR::")
                                                        } else {
                                                            status = "You said: $spoken"
                                                            input = spoken
                                                            selectedPage = "Chat"
                                                        }
                                                    }
                                                } else voicePermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                            }) { Text("🎙", fontSize = 21.sp) }
                                            IconButton(onClick = { selectedPage = "Chat" }) {
                                                Text("➤", color = Cyan, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                                item {
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                                        listOf("Chat" to "☷", "Voice" to "🎙", "Image Generation" to "▧", "Code Generator" to "⌘").forEach { (page, icon) ->
                                            Surface(
                                                modifier = Modifier.weight(1f).height(76.dp).clickable { selectedPage = page },
                                                color = Panel,
                                                shape = RoundedCornerShape(16.dp),
                                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x77FF426D))
                                            ) {
                                                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                                    Text(icon, color = Cyan, fontSize = 22.sp)
                                                    Text(if (page == "Image Generation") "Image" else if (page == "Code Generator") "Code" else page, color = White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                                }
                                            }
                                        }
                                    }
                                }
                                item {
                                    Text("QUICK ACTIONS", color = White, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                    Spacer(Modifier.height(8.dp))
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        QuickCard("▣  GENERATE CODE", "Create a program", Modifier.weight(1f)) { selectedPage = "Code Generator" }
                                        QuickCard("▤  SUMMARIZE", "Key points", Modifier.weight(1f)) { selectedPage = "Summarize" }
                                    }
                                    Spacer(Modifier.height(8.dp))
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        QuickCard("⇄  TRANSLATE", "Hindi • English", Modifier.weight(1f)) { selectedPage = "Translate" }
                                        QuickCard("✎  WRITE ANYTHING", "Messages and ideas", Modifier.weight(1f)) { selectedPage = "Chat" }
                                    }
                                }
                                item {
                                    Text("✦  SMARTER CONVERSATIONS WITH MAXXA AI  ✦", color = Muted, fontSize = 9.sp, letterSpacing = 0.7.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                                }
                            }
                        }
                        "Chat" -> {
                            Text("CONVERSATION", color = Gold, fontSize = 12.sp, letterSpacing = 2.sp, modifier = Modifier.padding(vertical = 10.dp))
                            LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(chats) { line ->
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.isUser) Arrangement.End else Arrangement.Start) {
                                        Surface(color = if (line.isUser) Color(0xFF57172A) else Panel, shape = if (chatStyle == "Classic") RoundedCornerShape(8.dp) else RoundedCornerShape(16.dp), modifier = Modifier.widthIn(max = 310.dp)) {
                                            Text(line.text, color = White, modifier = Modifier.padding(13.dp), fontSize = when (textSize) { "Small" -> 12.sp; "Large" -> 16.sp; else -> 14.sp })
                                        }
                                    }
                                }
                                if (loading && typingIndicator) item { Text("MAXXA is thinking…", color = Cyan, fontSize = 13.sp) }
                            }
                            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf("Explain", "Code", "Translate", "More").forEach { action ->
                                    Surface(color = Color(0xEE1A0B12), shape = RoundedCornerShape(18.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x88FF426D)), modifier = Modifier.weight(1f).clickable {
                                        when (action) {
                                            "Code" -> selectedPage = "Code Generator"
                                            "Translate" -> selectedPage = "Translate"
                                            "Explain" -> input = if (input.isBlank()) "Explain this in simple words: " else "Explain: $input"
                                            else -> menuOpen = true
                                        }
                                    }) { Text(action, color = White, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) }
                                }
                            }
                            Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("Type a message…") }, shape = RoundedCornerShape(18.dp), singleLine = true)
                                Spacer(Modifier.width(8.dp))
                                Button(enabled = !loading && input.isNotBlank(), onClick = {
                                    val msg = input.trim(); input = ""; chats.add(ChatLine(msg, true)); loading = true
                                    scope.launch {
                                        try {
                                            val conversationContext = chats.takeLast(12).joinToString("\n") { line ->
                                                (if (line.isUser) "User: " else "MAXXA: ") + line.text
                                            }
                                            val answer = withContext(Dispatchers.IO) {
                                                askGemini(apiKey, "You are MAXXA AI, a helpful multilingual assistant. Reply primarily in $replyLanguage unless the user explicitly requests another language. Keep context from the conversation, answer accurately, and explain code step by step when asked.\n\nRecent conversation (the latest user message is included above):\n$conversationContext", backendUrl, backendToken)
                                            }
                                            chats.add(ChatLine(answer, false))
                                            if (voiceEnabled && answer.isNotBlank()) onSpeak(answer, replyLanguage)
                                        } catch (e: Exception) {
                                            chats.add(ChatLine("MAXXA couldn't complete the request. Check your internet connection and API key, then try again.", false))
                                        } finally {
                                            loading = false
                                        }
                                    }
                                }, shape = CircleShape, contentPadding = PaddingValues(14.dp)) { Text("➤") }
                            }
                        }
                        "Conversation" -> ConversationHistoryPage(
                            messages = chats,
                            onOpenConversation = { selectedPage = "Chat" },
                            onClearHistory = {
                                chats.clear()
                                chats.add(ChatLine("Chat history cleared. Namaste! Main MAXXA AI hoon.", false))
                                prefs.edit().putString("chat_history", "[]").apply()
                            }
                        )
                        "Voice" -> {
                            Spacer(Modifier.height(22.dp))
                            Text("VOICE ASSISTANT", color = Gold, fontSize = 11.sp, letterSpacing = 2.4.sp, fontWeight = FontWeight.Bold)
                            Text("Speak to MAXXA", color = White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 7.dp))
                            Text("Hindi, Hinglish ya English mein bolo. Main sun raha hoon.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp, modifier = Modifier.padding(top = 7.dp))
                            Spacer(Modifier.weight(1f))
                            Box(Modifier.fillMaxWidth().height(300.dp), contentAlignment = Alignment.Center) {
                                Image(painter = painterResource(id = R.drawable.itachi_splash_art), contentDescription = null, modifier = Modifier.fillMaxSize().alpha(0.38f), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x66090005), Color(0xAA090509), Color(0xEE090509)))))
                                Box(Modifier.size(286.dp).background(Brush.radialGradient(listOf(Color(0x77FF426D), Color(0x33FF78B7), Color.Transparent)), CircleShape))
                                Surface(color = Color(0x55200814), shape = CircleShape, border = androidx.compose.foundation.BorderStroke(2.dp, Color(0xAAFF426D)), modifier = Modifier.size(224.dp)) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Surface(color = Color(0xAA310B1B), shape = CircleShape, border = androidx.compose.foundation.BorderStroke(2.dp, Color(0xFFFF78B7)), modifier = Modifier.size(174.dp)) { Box(contentAlignment = Alignment.Center) { Text("🎙", color = White, fontSize = 42.sp) } }
                                    }
                                }
                                Button(enabled = !isListening, onClick = {
                                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                        status = "Listening…"
                                        isListening = true
                                        onListen(replyLanguage, { spoken ->
                isListening = false
                if (spoken.startsWith("VOICE_ERROR::")) {
                    status = spoken.removePrefix("VOICE_ERROR::")
                } else {
                    status = "You said: $spoken"
                    input = spoken
                    selectedPage = "Chat"
                }
            })
                                    } else voicePermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                }, modifier = Modifier.size(148.dp).scale(if (isListening) micScale else 1f), shape = CircleShape, border = androidx.compose.foundation.BorderStroke(2.dp, Color(0xFFFF9FBE)), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF68162F), contentColor = White)) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(if (isListening) "LISTENING…" else "TAP TO SPEAK", fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                    }
                                }
                            }
                            Row(Modifier.fillMaxWidth().padding(top = 2.dp, bottom = 10.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                                val heights = listOf(10, 18, 28, 16, 36, 22, 42, 18, 30, 14, 24, 10, 18)
                                heights.forEachIndexed { index, height ->
                                    Box(Modifier.padding(horizontal = 2.dp).width(3.dp).height((if (isListening) height + (index % 3) * 4 else 8).dp).background(if (isListening) Cyan else Color(0xFF9A526D), RoundedCornerShape(4.dp)))
                                }
                            }
                            Text(status, color = Cyan, fontSize = 12.sp, modifier = Modifier.fillMaxWidth().padding(top = 4.dp), textAlign = TextAlign.Center, maxLines = 2)
                            if (isListening) {
                                OutlinedButton(onClick = {
                                    onStopListening()
                                    isListening = false
                                    status = "Listening stopped."
                                }, modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 10.dp), shape = RoundedCornerShape(24.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan)) {
                                    Text("■  STOP LISTENING", fontWeight = FontWeight.Bold, letterSpacing = 0.6.sp)
                                }
                            }
                            Spacer(Modifier.weight(1f))
                        }
                        "Permissions" -> {
                            // Read permission state again after every system permission dialog.
                            // Request only permissions declared in the manifest and used by this build.
                            // Sensitive SMS, call, location and calendar access is intentionally not requested.
                            val permissionRows = listOf(
                                PermissionRow("🎙", "Microphone", "Voice input", listOf(Manifest.permission.RECORD_AUDIO))
                            )
                            Column(Modifier.fillMaxWidth().weight(1f)) {
                                Text("PERMISSIONS", color = Gold, fontSize = 12.sp, letterSpacing = 2.sp)
                                Text("Required for full features", color = Cyan, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp, bottom = 12.dp))
                                LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.weight(1f)) {
                                    items(permissionRows) { row ->
                                        val granted = row.permissions.isNotEmpty() && row.permissions.all { ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED }
                                        Surface(
                                            color = Color(0xEE1A0B12),
                                            shape = RoundedCornerShape(13.dp),
                                            border = androidx.compose.foundation.BorderStroke(1.dp, if (granted) Color(0xFFFF6A91) else Color(0xFF8C2948)),
                                            modifier = Modifier.fillMaxWidth().clickable {
                                                if (row.permissions.isEmpty()) {
                                                    permissionRefresh++
                                                } else {
                                                    permissionLauncher.launch(row.permissions.toTypedArray())
                                                }
                                            }
                                        ) {
                                            Row(Modifier.padding(horizontal = 11.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                                Box(Modifier.size(38.dp).background(if (granted) Color(0x33FF426D) else Color(0x33FF4E86), CircleShape), contentAlignment = Alignment.Center) {
                                                    Text(row.icon, color = if (granted) Cyan else Color(0xFFFF7DAB), fontSize = 18.sp)
                                                }
                                                Column(Modifier.weight(1f).padding(start = 10.dp)) {
                                                    Text(row.title, color = White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                                    Text(row.subtitle, color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 2.dp))
                                                }
                                                Column(horizontalAlignment = Alignment.End) {
                                                    Text(if (granted) "Allowed ✓" else "Not allowed ×", color = if (granted) Color(0xFFFF9FBE) else Color(0xFFFF628A), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                                    Text(if (granted) "Granted" else "Enable", color = Cyan, fontSize = 10.sp, modifier = Modifier.padding(top = 3.dp))
                                                }
                                            }
                                        }
                                    }
                                }
                                OutlinedButton(onClick = {
                                    runCatching { context.startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + context.packageName))) }
                                }, modifier = Modifier.fillMaxWidth().padding(top = 9.dp).height(48.dp), shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan)) {
                                    Text("⚙  MANAGE PERMISSIONS", fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
                                }
                                Text("Only enable permissions for features you use. SMS and phone permissions are sensitive.", color = Muted, fontSize = 10.sp, lineHeight = 14.sp, modifier = Modifier.padding(top = 6.dp, bottom = 4.dp))
                            }
                        }
                        "Voice Pack" -> {
                            VoicePackPage(
                                language = replyLanguage,
                                voiceEnabled = voiceEnabled,
                                onLanguageChange = { lang -> replyLanguage = lang; prefs.edit().putString("reply_language", lang).apply() },
                                onVoiceChange = { enabled -> voiceEnabled = enabled; prefs.edit().putBoolean("voice_enabled", enabled).apply() },
                                onPreview = { sample, lang -> onSpeak(sample, lang) }
                            )
                        }
                        "API Key" -> {
                            Spacer(Modifier.height(18.dp))
                            Text("SECURE GEMINI CONNECTION", color = Gold, fontSize = 11.sp, letterSpacing = 2.5.sp)
                            Text("Connect your backend", color = White, fontSize = 27.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                            Text("MAXXA does not store a Gemini API key on your phone. Deploy the included backend, set GEMINI_API_KEY as a server secret, then enter its HTTPS URL here.", color = Muted, fontSize = 13.sp, lineHeight = 19.sp, modifier = Modifier.padding(top = 8.dp, bottom = 20.dp))
                            Surface(color = Panel, shape = RoundedCornerShape(22.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x66FF426D)), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(16.dp)) {
                                    Text("BACKEND HTTPS URL", color = Cyan, fontSize = 11.sp, letterSpacing = 1.2.sp)
                                    Spacer(Modifier.height(8.dp))
                                    OutlinedTextField(value = backendUrlInput, onValueChange = { backendUrlInput = it; keySaved = false }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("https://your-server.example.com") }, singleLine = true, shape = RoundedCornerShape(14.dp))
                                    Text("OPTIONAL BACKEND ACCESS TOKEN", color = Cyan, fontSize = 11.sp, letterSpacing = 1.2.sp, modifier = Modifier.padding(top = 14.dp))
                                    OutlinedTextField(value = backendTokenInput, onValueChange = { backendTokenInput = it; keySaved = false }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Paste the server MAXXA_CLIENT_TOKEN") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), shape = RoundedCornerShape(14.dp))
                                    Text("If MAXXA_CLIENT_TOKEN is enabled on your server, paste the same token here. It is encrypted with Android Keystore on this device.", color = Muted, fontSize = 10.sp, lineHeight = 14.sp, modifier = Modifier.padding(top = 6.dp))
                                    Button(onClick = {
                                        val candidate = backendUrlInput.trim().trimEnd('/')
                                        if (isValidHttpsBackendUrl(candidate)) {
                                            backendUrl = candidate
                                            backendToken = backendTokenInput.trim()
                                            val encryptedToken = runCatching { encryptBackendToken(context, backendToken) }.getOrElse { "" }
                                            prefs.edit().putString("backend_url", backendUrl).remove("gemini_api_key").apply {
                                                if (backendToken.isBlank()) remove("backend_token_enc") else putString("backend_token_enc", encryptedToken)
                                            }.apply()
                                            keySaved = backendToken.isBlank() || encryptedToken.isNotBlank()
                                        } else {
                                            // Do not leave an older, previously saved endpoint active after an invalid save.
                                            backendUrl = ""
                                            backendToken = ""
                                            backendTokenInput = ""
                                            prefs.edit().remove("backend_url").remove("backend_token_enc").apply()
                                            backendCheck = ""
                                            keySaved = false
                                        }
                                    }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp).height(46.dp), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Bg)) { Text("SAVE HTTPS BACKEND", fontWeight = FontWeight.Bold) }
                                    Text("Only HTTPS URLs are accepted. API credentials stay on the server.", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 8.dp))
                                    OutlinedButton(
                                        enabled = backendUrl.isNotBlank() && !checkingBackend,
                                        onClick = {
                                            checkingBackend = true
                                            backendCheck = "Checking secure backend…"
                                            scope.launch {
                                                backendCheck = withContext(Dispatchers.IO) { checkBackendHealth(backendUrl) }
                                                checkingBackend = false
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth().padding(top = 10.dp).height(46.dp),
                                        shape = RoundedCornerShape(15.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan)
                                    ) { Text(if (checkingBackend) "CHECKING…" else "TEST BACKEND CONNECTION", fontWeight = FontWeight.Bold) }
                                    if (backendCheck.isNotBlank()) Text(backendCheck, color = if (backendCheck.startsWith("✓")) Color(0xFFFF9FBE) else Color(0xFFFF8A9E), fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
                                    OutlinedButton(onClick = { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey"))) } }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp).height(48.dp), shape = RoundedCornerShape(15.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan)) { Text("OPEN GOOGLE AI STUDIO", fontWeight = FontWeight.Bold) }
                                    if (keySaved) Text("✓ Secure backend URL saved", color = Color(0xFFFF9FBE), fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
                                }
                            }
                        }
                        "Preferences" -> PreferencesPage(
                            language = replyLanguage,
                            voiceEnabled = voiceEnabled,
                            autoSave = autoSave,
                            typingIndicator = typingIndicator,
                            textSize = textSize,
                            chatStyle = chatStyle,
                            onTextSizeChange = { textSize = it; prefs.edit().putString("text_size", it).apply() },
                            onChatStyleChange = { chatStyle = it; prefs.edit().putString("chat_style", it).apply() },
                            onLanguageChange = { lang -> replyLanguage = lang; prefs.edit().putString("reply_language", lang).apply() },
                            onVoiceChange = { enabled -> voiceEnabled = enabled; prefs.edit().putBoolean("voice_enabled", enabled).apply() },
                            onAutoSaveChange = { enabled -> autoSave = enabled; prefs.edit().putBoolean("auto_save", enabled).apply() },
                            onTypingIndicatorChange = { enabled -> typingIndicator = enabled; prefs.edit().putBoolean("typing_indicator", enabled).apply() }
                        )
                        "Language Selection" -> LanguageSelectionPage(
                            language = replyLanguage,
                            onLanguageChange = { lang -> replyLanguage = lang; prefs.edit().putString("reply_language", lang).apply() },
                            onContinue = { selectedPage = "Home" }
                        )
                        "Automation" -> AutomationPage()
                        "Phone Control" -> PhoneControlPage()
                        "Additional Settings" -> AdditionalSettingsPage(
                            backendConfigured = backendUrl.isNotBlank(),
                            historyCount = chats.size,
                            onClearHistory = {
                                chats.clear()
                                chats.add(ChatLine("Chat history cleared. Namaste! Main MAXXA AI hoon.", false))
                                prefs.edit().putString("chat_history", "[]").apply()
                            },
                            onOpenAppSettings = {
                                runCatching { context.startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + context.packageName))) }
                            },
                            onNavigate = { destination -> selectedPage = destination },
                            onClearCache = {
                                runCatching { context.cacheDir.deleteRecursively(); context.cacheDir.mkdirs() }
                                android.widget.Toast.makeText(context, "App cache cleared", android.widget.Toast.LENGTH_SHORT).show()
                            },
                            onResetSettings = {
                                prefs.edit().clear().apply()
                                backendUrl = ""
                                backendUrlInput = ""
                                backendToken = ""
                                backendTokenInput = ""
                                keySaved = false
                                checkingBackend = false
                                voiceEnabled = true
                                autoSave = true
                                typingIndicator = true
                                textSize = "Medium"
                                chatStyle = "Modern"
                                replyLanguage = "Hindi / Hinglish"
                                backendCheck = ""
                            }
                        )
                        "Image Generation" -> ToolPage(
                            title = "IMAGE PROMPT STUDIO",
                            description = "Generate an image from your prompt using the Gemini image model configured on your secure backend.",
                            placeholder = "A cute chibi character under sakura trees…",
                            buttonText = "GENERATE IMAGE",
                            apiKey = "",
                            instruction = "Create a polished image from the user's description.",
                            backendUrl = backendUrl,
                            backendToken = backendToken,
                            replyLanguage = replyLanguage,
                            imageGeneration = true
                        )
                        "Code Generator" -> ToolPage(
                            title = "CODE GENERATOR",
                            description = "Describe the program, platform and language. Ask for complete code plus setup and testing instructions.",
                            placeholder = "Make a Kotlin calculator app…",
                            buttonText = "GENERATE CODE",
                            apiKey = "",
                            instruction = "You are MAXXA AI, an expert programming assistant. Produce a complete, practical solution for the user's request. State assumptions, include code in fenced code blocks, explain where files go, dependencies, run steps and tests. Never claim code was executed unless it was.",
                            backendUrl = backendUrl,
                            backendToken = backendToken,
                            replyLanguage = replyLanguage
                        )
                        "Summarize" -> ToolPage(
                            title = "SUMMARIZE",
                            description = "Paste an article, notes or long text. Choose a concise summary, key points and action items in your request.",
                            placeholder = "Paste the text you want summarized…",
                            buttonText = "SUMMARIZE TEXT",
                            apiKey = "",
                            instruction = "You are MAXXA AI. Summarize the user's supplied text accurately without adding unsupported facts. Provide a short overview, key points and any action items when relevant.",
                            backendUrl = backendUrl,
                            backendToken = backendToken,
                            replyLanguage = replyLanguage
                        )
                        "Translate" -> ToolPage(
                            title = "TRANSLATE",
                            description = "Paste text and mention the target language, for example Hindi, Hinglish or English.",
                            placeholder = "Text to translate and target language…",
                            buttonText = "TRANSLATE TEXT",
                            apiKey = "",
                            instruction = "You are MAXXA AI, a careful translator. Translate the user's text into the target language they specify. Preserve meaning, tone, names and formatting. If the target language is missing, ask which language they want.",
                            backendUrl = backendUrl,
                            backendToken = backendToken,
                            replyLanguage = replyLanguage
                        )
                        "Help & Support" -> HelpSupportPage()
                        "About" -> AboutPage()
                        else -> SimplePage(page.uppercase(), "Itachi Sakura theme • red neon cards • cute anime artwork.", "THEME", "Itachi • Sakura • Crimson Neon")
                                }
                            }
                        }
                    }
                    Surface(
                        color = Color(0xF5160A11),
                        shape = RoundedCornerShape(18.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x553F1B2A)),
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 8.dp)
                    ) {
                        Row(Modifier.fillMaxWidth().padding(vertical = 9.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                            listOf("Home" to "⌂", "Chat" to "☷", "Voice" to "♫", "More" to "•••").forEach { (page, icon) ->
                                Column(
                                    modifier = Modifier.clickable { if (page == "More") menuOpen = true else selectedPage = page },
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(icon, color = if ((page == "Home" && selectedPage == "Home") || (page == "Chat" && selectedPage in listOf("Chat", "Conversation")) || (page == "Voice" && selectedPage == "Voice")) Cyan else Muted, fontSize = 18.sp)
                                    Text(page, color = White, fontSize = 9.sp)
                                }
                            }
                        }
                    }
                }
                AnimatedVisibility(
                    visible = menuOpen,
                    enter = fadeIn(tween(160)) + slideInHorizontally(tween(220)) { -it },
                    exit = fadeOut(tween(120)) + slideOutHorizontally(tween(180)) { -it }
                ) {
                    Row(Modifier.fillMaxSize().background(Color(0xCC050205))) {
                        Column(Modifier.fillMaxHeight().fillMaxWidth(0.82f).background(Brush.verticalGradient(listOf(Color(0xFF210A13), Bg))).verticalScroll(rememberScrollState()).padding(20.dp)) {
                            Surface(color = Color(0x33FF426D), shape = RoundedCornerShape(18.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x66FF426D)), modifier = Modifier.fillMaxWidth()) {
                                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.size(48.dp).background(Brush.linearGradient(listOf(Cyan, Purple)), CircleShape), contentAlignment = Alignment.Center) {
                                        Image(painter = painterResource(id = R.drawable.maxxa_logo), contentDescription = "MAXXA logo", modifier = Modifier.fillMaxSize().padding(2.dp))
                                    }
                                    Column(Modifier.padding(start = 12.dp)) {
                                        Text("MAXXA AI", color = White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                                        Text("PERSONAL ASSISTANT", color = Cyan, fontSize = 9.sp, letterSpacing = 1.5.sp)
                                    }
                                }
                            }
                            Spacer(Modifier.height(22.dp))
                            listOf("Home", "Chat", "Voice Pack", "API Key", "Conversation", "Permissions", "Preferences", "Language Selection", "Automation", "Phone Control", "Additional Settings", "Help & Support", "About").forEach { item ->
                                Row(Modifier.fillMaxWidth().clickable { selectedPage = item; menuOpen = false }.padding(vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(menuIcon(item), color = if (selectedPage == item) Cyan else Gold, fontSize = 18.sp, modifier = Modifier.width(36.dp))
                                    Text(item, color = if (selectedPage == item) Cyan else White, fontSize = 15.sp, fontWeight = if (selectedPage == item) FontWeight.Bold else FontWeight.Normal)
                                }
                            }
                            Spacer(Modifier.height(20.dp))
                            Text("Built for your voice.", color = Muted, fontSize = 12.sp)
                        }
                        Box(Modifier.fillMaxSize().clickable { menuOpen = false })
                    }
                }
            }
        }
    }
}

@Composable
private fun ConversationHistoryPage(
    messages: List<ChatLine>,
    onOpenConversation: () -> Unit,
    onClearHistory: () -> Unit
) {
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ReferencePageHeading("CONVERSATION", "Your chat history", "Saved locally on this device when Auto Save is enabled.")
        val latest = messages.lastOrNull()?.text.orEmpty()
        Surface(
            color = Color(0xEE1A0B12),
            shape = RoundedCornerShape(17.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xAAFF426D)),
            modifier = Modifier.fillMaxWidth().clickable(onClick = onOpenConversation)
        ) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(38.dp).background(Color(0x33FF426D), CircleShape), contentAlignment = Alignment.Center) {
                        Text("☷", color = Cyan, fontSize = 20.sp)
                    }
                    Column(Modifier.weight(1f).padding(start = 10.dp)) {
                        Text("Current conversation", color = White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text("${messages.size} messages • Stored on this device", color = Muted, fontSize = 10.sp)
                    }
                    Text("›", color = Cyan, fontSize = 24.sp)
                }
                Divider(color = Color(0x553D2530))
                Text(latest.ifBlank { "Start a new conversation with MAXXA." }.take(180), color = Muted, fontSize = 11.sp, lineHeight = 16.sp, maxLines = 3)
                Text("OPEN CHAT  →", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
        ReferenceInfoCard("Privacy", "Your messages remain in this app's local preferences. Cloud sync and multiple chat threads are not included in this development build.")
        OutlinedButton(onClick = onClearHistory, modifier = Modifier.fillMaxWidth()) { Text("CLEAR CONVERSATION HISTORY") }
    }
}

@Composable
private fun ToolPage(
    title: String,
    description: String,
    placeholder: String,
    buttonText: String,
    apiKey: String,
    instruction: String,
    backendUrl: String = "",
    backendToken: String = "",
    replyLanguage: String = "Hindi / Hinglish",
    imageGeneration: Boolean = false
) {
    var request by remember(title) { mutableStateOf("") }
    var result by remember(title) { mutableStateOf("") }
    var generatedImage by remember(title) { mutableStateOf<androidx.compose.ui.graphics.ImageBitmap?>(null) }
    var selectedAspectRatio by remember(title) { mutableStateOf("1:1") }
    var aspectMenuExpanded by remember(title) { mutableStateOf(false) }
    var running by remember(title) { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(top = 12.dp, bottom = 12.dp)) {
        ReferencePageHeading(title, description, if (imageGeneration) "Create artwork with your configured image model." else "Powered by your secure HTTPS Gemini backend.")
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = request,
            onValueChange = { request = it },
            modifier = Modifier.fillMaxWidth().heightIn(min = 130.dp, max = 220.dp),
            placeholder = { Text(placeholder) },
            shape = RoundedCornerShape(16.dp),
            minLines = 4
        )
        if (imageGeneration) {
            Box {
                OutlinedButton(onClick = { aspectMenuExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("ASPECT RATIO  •  $selectedAspectRatio")
                }
                DropdownMenu(expanded = aspectMenuExpanded, onDismissRequest = { aspectMenuExpanded = false }) {
                    listOf("1:1", "3:2", "2:3", "4:3", "3:4", "5:4", "4:5", "9:16", "16:9").forEach { ratio ->
                        DropdownMenuItem(text = { Text(ratio) }, onClick = { selectedAspectRatio = ratio; aspectMenuExpanded = false })
                    }
                }
            }
        }
        Button(
            enabled = !running && request.isNotBlank(),
            onClick = {
                val userRequest = request.trim()
                running = true
                result = ""
                generatedImage = null
                scope.launch {
                    result = try {
                        if (imageGeneration) {
                            val image = withContext(Dispatchers.IO) { requestGeneratedImage(userRequest, backendUrl, selectedAspectRatio, backendToken) }
                            generatedImage = BitmapFactory.decodeByteArray(image.first, 0, image.first.size)?.asImageBitmap()
                            if (generatedImage == null) "Image was returned but could not be decoded on this device." else "Image generated successfully • ${image.second}"
                        } else {
                            withContext(Dispatchers.IO) { askGemini(apiKey, "You are MAXXA AI. Reply primarily in $replyLanguage unless the user requests another language.\n\n$instruction\n\nUser request:\n$userRequest", backendUrl, backendToken) }
                        }
                    } catch (error: Exception) {
                        error.message?.takeIf { it.isNotBlank() } ?: "MAXXA couldn't complete this request. Check your backend URL and internet connection, then try again."
                    } finally {
                        running = false
                    }
                }
            },
            modifier = Modifier.fillMaxWidth().padding(top = 12.dp).height(50.dp),
            shape = RoundedCornerShape(15.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Bg)
        ) { Text(if (running) "WORKING…" else buttonText, fontWeight = FontWeight.Bold) }
        if (running) {
            LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 12.dp), color = Cyan, trackColor = Panel)
        }
        generatedImage?.let { bitmap ->
            Image(bitmap = bitmap, contentDescription = "Generated image", modifier = Modifier.fillMaxWidth().heightIn(max = 420.dp))
        }
        if (result.isNotBlank()) {
            Text("RESULT", color = Gold, fontSize = 11.sp, letterSpacing = 2.sp, modifier = Modifier.padding(top = 18.dp, bottom = 8.dp))
            Surface(
                color = Panel,
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x66FF426D)),
                modifier = Modifier.fillMaxWidth().weight(1f, fill = false)
            ) {
                LazyColumn(Modifier.padding(14.dp).heightIn(max = 360.dp)) {
                    item { Text(result, color = White, fontSize = 13.sp, lineHeight = 19.sp) }
                }
            }
        }
    }
}

private data class PermissionRow(val icon: String, val title: String, val subtitle: String, val permissions: List<String>)

private fun menuIcon(item: String) = when (item) {
    "Home" -> "⌂"; "Chat" -> "☷"; "Voice" -> "♫"; "Permissions" -> "◈"; "Voice Pack" -> "♫"; "API Key" -> "⌘"
    "Conversation" -> "☷"; "Preferences" -> "⚙"; "Automation" -> "⌁"; "Phone Control" -> "▣"; "Language Selection" -> "文"; else -> "⋯"
}

@Composable
private fun SplashScreen() {
    val transition = rememberInfiniteTransition(label = "splash")
    val pulse by transition.animateFloat(0.94f, 1.06f, infiniteRepeatable(tween(950), RepeatMode.Reverse), label = "splash-pulse")
    Box(Modifier.fillMaxSize().background(Color(0xFF090509))) {
        Image(
            painter = painterResource(id = R.drawable.itachi_splash_art),
            contentDescription = "Cute Itachi Uchiha with sakura blossoms",
            modifier = Modifier.fillMaxSize(),
            contentScale = androidx.compose.ui.layout.ContentScale.Crop
        )
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x55060005), Color(0x9910060C), Color(0xEE090509)))))
        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 30.dp, vertical = 42.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(104.dp).scale(pulse).background(Brush.radialGradient(listOf(Color(0x88FF426D), Color(0x33FF78B7), Color.Transparent)), CircleShape), contentAlignment = Alignment.Center) {
                Box(Modifier.size(78.dp).background(Brush.linearGradient(listOf(Cyan, Purple)), CircleShape).padding(3.dp).background(Bg, CircleShape), contentAlignment = Alignment.Center) {
                    Image(painter = painterResource(id = R.drawable.maxxa_logo), contentDescription = "MAXXA AI logo", modifier = Modifier.fillMaxSize().padding(4.dp))
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("MAXXA", color = White, fontSize = 32.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp)
            Text("AI", color = Cyan, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 5.sp)
            Text("YOUR AI ASSISTANT", color = Color(0xFFFFA6C8), fontSize = 10.sp, letterSpacing = 2.4.sp, modifier = Modifier.padding(top = 6.dp))
            Spacer(Modifier.height(22.dp))
            Surface(
                color = Color(0xAA160A11),
                shape = RoundedCornerShape(24.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x77FF426D)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 13.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth().height(4.dp), color = Cyan, trackColor = Color(0x55FF426D))
                    Text("THE TRUTH LIVES IN SILENCE", color = White, fontSize = 9.sp, letterSpacing = 1.8.sp, modifier = Modifier.padding(top = 11.dp))
                }
            }
        }
    }
}

@Composable
private fun QuickCard(title: String, subtitle: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(modifier = modifier.animateContentSize().clickable(onClick = onClick), color = Panel, shape = RoundedCornerShape(18.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x66FF426D))) {
        Column(Modifier.padding(15.dp)) {
            Text(title, color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Text(subtitle, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

@Composable
private fun PreferencesPage(
    language: String,
    voiceEnabled: Boolean,
    autoSave: Boolean,
    typingIndicator: Boolean,
    textSize: String,
    chatStyle: String,
    onTextSizeChange: (String) -> Unit,
    onChatStyleChange: (String) -> Unit,
    onLanguageChange: (String) -> Unit,
    onVoiceChange: (Boolean) -> Unit,
    onAutoSaveChange: (Boolean) -> Unit,
    onTypingIndicatorChange: (Boolean) -> Unit
) {
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(top = 12.dp, bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ReferencePageHeading("PREFERENCES", "Make MAXXA work your way", "Personalize language, appearance and chat behavior.")
        Surface(color = Color(0xEE1A0B12), shape = RoundedCornerShape(17.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x553F1B2A)), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("LANGUAGE", color = Cyan, fontSize = 10.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold)
                listOf("Hindi / Hinglish", "English").forEach { option ->
                    Row(Modifier.fillMaxWidth().clickable { onLanguageChange(option) }.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(if (language == option) "◉" else "○", color = Cyan, fontSize = 18.sp, modifier = Modifier.width(30.dp))
                        Text(option, color = White, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        if (language == option) Text("SELECTED", color = Color(0xFFFF9FBE), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Divider(color = Color(0x553D2530))
                PreferenceSwitchRow("Speak AI replies", "Read MAXXA responses aloud", voiceEnabled, onVoiceChange)
                Divider(color = Color(0x553D2530))
                PreferenceSwitchRow("Auto Save Conversation", "Keep chat history on this device", autoSave, onAutoSaveChange)
                PreferenceSwitchRow("Show Typing Indicator", "Show when MAXXA is preparing a reply", typingIndicator, onTypingIndicatorChange)
                Divider(color = Color(0x553D2530))
                Text("TEXT SIZE", color = Cyan, fontSize = 10.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf("Small", "Medium", "Large").forEach { size ->
                        FilterChip(selected = textSize == size, onClick = { onTextSizeChange(size) }, label = { Text(size, fontSize = 10.sp) })
                    }
                }
                Text("CHAT STYLE", color = Cyan, fontSize = 10.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf("Modern", "Classic").forEach { style ->
                        FilterChip(selected = chatStyle == style, onClick = { onChatStyleChange(style) }, label = { Text(style, fontSize = 10.sp) })
                    }
                }
            }
        }
        Text("Your choices are saved on this device.", color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun PreferenceSwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Muted, fontSize = 10.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun LanguageSelectionPage(language: String, onLanguageChange: (String) -> Unit, onContinue: () -> Unit) {
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(top = 12.dp, bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
        ReferencePageHeading("LANGUAGE SELECTION", "Choose your language", "MAXXA will use this as its default response language.")
        listOf("English", "Hindi", "Hinglish").forEach { option ->
            Surface(color = Color(0xEE1A0B12), shape = RoundedCornerShape(16.dp), border = androidx.compose.foundation.BorderStroke(1.dp, if (language == option) Cyan else Color(0x553F1B2A)), modifier = Modifier.fillMaxWidth().clickable { onLanguageChange(option) }) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(when (option) { "English" -> "A"; "Hindi" -> "अ"; else -> "हि" }, color = White, fontSize = 22.sp, modifier = Modifier.width(42.dp))
                    Text(option, color = White, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    Text(if (language == option) "✓" else "○", color = Cyan, fontSize = 20.sp)
                }
            }
        }
        Button(onClick = onContinue, modifier = Modifier.fillMaxWidth().height(49.dp), shape = RoundedCornerShape(15.dp), colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Bg)) { Text("CONTINUE", fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun AutomationPage() {
    val context = LocalContext.current
    fun launch(intent: Intent, fallback: String) {
        runCatching { context.startActivity(intent) }.onFailure {
            android.widget.Toast.makeText(context, fallback, android.widget.Toast.LENGTH_SHORT).show()
        }
    }
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(top = 12.dp, bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
        ReferencePageHeading("AUTOMATION", "Your phone, one tap away", "Choose a shortcut. MAXXA always asks Android to open the action; it does not secretly control your device.")
        ReferenceActionRow("▣", "Open Dialer", "Open the phone app without placing a call", "OPEN") { launch(Intent(Intent.ACTION_DIAL), "Dialer is unavailable") }
        ReferenceActionRow("⌕", "Search & Browse", "Open your browser to search the web", "OPEN") { launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")), "Browser is unavailable") }
        ReferenceActionRow("⚙", "Device Settings", "Manage Wi-Fi, Bluetooth and system settings", "OPEN") { launch(Intent(android.provider.Settings.ACTION_SETTINGS), "Settings are unavailable") }
        ReferenceActionRow("▤", "Messages", "Open your default messaging app", "OPEN") { launch(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING), "Messaging app is unavailable") }
        ReferenceActionRow("◉", "App permissions", "Review MAXXA's Android permissions", "REVIEW") { launch(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + context.packageName)), "App settings are unavailable") }
        ReferenceInfoCard("Privacy first", "MAXXA does not silently monitor your screen, read private messages or place calls. Every shortcut opens an Android app or settings page for you to review.")
    }
}

@Composable
private fun PhoneControlPage() {
    val context = LocalContext.current
    fun launch(intent: Intent, fallback: String) {
        runCatching { context.startActivity(intent) }.onFailure {
            android.widget.Toast.makeText(context, fallback, android.widget.Toast.LENGTH_SHORT).show()
        }
    }
    val accessibilityEnabled = remember { mutableStateOf(MaxxaAccessibilityService.isEnabled()) }
    fun runPhoneAction(action: PhoneAction, label: String) {
        val ok = MaxxaAccessibilityService.perform(action)
        android.widget.Toast.makeText(context, if (ok) "$label requested" else "Enable MAXXA AI Phone Actions in Accessibility settings first", android.widget.Toast.LENGTH_LONG).show()
        accessibilityEnabled.value = MaxxaAccessibilityService.isEnabled()
    }
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(top = 12.dp, bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
        ReferencePageHeading("PHONE CONTROL", "User-approved device actions", "Enable the optional Android Accessibility service, then tap an action. MAXXA does not read screen contents or control other apps with hidden taps.")
        ReferenceActionRow("♿", "Enable Accessibility Actions", if (accessibilityEnabled.value) "Service is connected" else "Open Android Accessibility settings and enable MAXXA AI Phone Actions", if (accessibilityEnabled.value) "ON" else "ENABLE") {
            launch(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS), "Accessibility settings are unavailable")
        }
        ReferenceActionRow("↶", "Back", "Navigate back one screen", "RUN") { runPhoneAction(PhoneAction.BACK, "Back") }
        ReferenceActionRow("⌂", "Home", "Return to your device launcher", "RUN") { runPhoneAction(PhoneAction.HOME, "Home") }
        ReferenceActionRow("▢", "Recent Apps", "Open Android's recent-apps overview", "RUN") { runPhoneAction(PhoneAction.RECENTS, "Recents") }
        ReferenceActionRow("▤", "Notifications", "Open the notification shade", "RUN") { runPhoneAction(PhoneAction.NOTIFICATIONS, "Notifications") }
        ReferenceActionRow("☷", "Quick Settings", "Open Android Quick Settings", "RUN") { runPhoneAction(PhoneAction.QUICK_SETTINGS, "Quick Settings") }
        ReferenceActionRow("⚙", "Open Settings", "Open the Android system settings screen", "OPEN") { launch(Intent(android.provider.Settings.ACTION_SETTINGS), "Settings are unavailable") }
        ReferenceActionRow("▣", "Open App Settings", "Manage MAXXA permissions and storage", "OPEN") { launch(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + context.packageName)), "App settings are unavailable") }
        ReferenceActionRow("⌕", "Open Browser", "Launch a browser for web search", "OPEN") { launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")), "Browser is unavailable") }
        ReferenceInfoCard("Privacy & limits", "Android requires you to enable Accessibility manually. This service only runs the five navigation actions you tap. It does not read screen text, inspect messages, perform gestures, type, make calls, or change protected toggles. Android/device policy may restrict some actions.")
    }
}

@Composable
private fun HelpSupportPage() {
    var expanded by remember { mutableStateOf(-1) }
    val questions = listOf(
        "How do I connect Gemini?" to "Deploy the included backend, add GEMINI_API_KEY as a server secret, then open API Key in MAXXA and save your HTTPS backend URL.",
        "Why is chat not responding?" to "Check your internet connection, confirm that the backend URL uses HTTPS, and use Test Backend Connection on the API Key page. The backend must be deployed and configured.",
        "Why is voice input unavailable?" to "Allow microphone permission in Android settings. Speech recognition availability and supported languages depend on the device and its installed speech services.",
        "Where are my conversations stored?" to "When Auto Save is enabled, chat history is stored locally in MAXXA's app preferences on this device. It is not cloud-synced in this build."
    )
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(top = 12.dp, bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
        ReferencePageHeading("HELP & SUPPORT", "How can we help?", "Quick answers for setup, chat and voice features.")
        questions.forEachIndexed { index, item ->
            Surface(color = Color(0xEE1A0B12), shape = RoundedCornerShape(15.dp), border = androidx.compose.foundation.BorderStroke(1.dp, if (expanded == index) Cyan else Color(0x553F1B2A)), modifier = Modifier.fillMaxWidth().clickable { expanded = if (expanded == index) -1 else index }) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("?", color = Cyan, fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(30.dp))
                        Text(item.first, color = White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Text(if (expanded == index) "−" else "+", color = Cyan, fontSize = 20.sp)
                    }
                    AnimatedVisibility(visible = expanded == index, enter = fadeIn(tween(120)), exit = fadeOut(tween(100))) {
                        Text(item.second, color = Muted, fontSize = 11.sp, lineHeight = 17.sp, modifier = Modifier.padding(start = 30.dp, top = 9.dp))
                    }
                }
            }
        }
        ReferenceInfoCard("Still need help?", "This development build does not yet include a support-ticket or live-contact service. You can report bugs to the project maintainer with the screen name and steps to reproduce.")
    }
}

@Composable
private fun AboutPage() {
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(top = 12.dp, bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(12.dp))
        Box(Modifier.size(112.dp).background(Brush.radialGradient(listOf(Color(0xAAFF426D), Color(0x22FF78B7), Color.Transparent)), CircleShape), contentAlignment = Alignment.Center) {
            Image(painter = painterResource(id = R.drawable.maxxa_logo), contentDescription = "MAXXA AI logo", modifier = Modifier.size(82.dp))
        }
        Text("MAXXA AI", color = White, fontSize = 28.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
        Text("YOUR PERSONAL AI ASSISTANT", color = Cyan, fontSize = 10.sp, letterSpacing = 1.8.sp)
        ReferenceInfoCard("Version", "1.0.0 • Development build")
        ReferenceInfoCard("Made for", "Hindi • Hinglish • English\nChat • Voice • Code • Image tools • Translation")
        ReferenceInfoCard("Design", "Crimson neon interface with Itachi and Sakura-inspired artwork.")
        ReferenceInfoCard("Build status", "Some features require a deployed HTTPS backend. Device compatibility, live API behavior and release signing must be verified before public release.")
    }
}

@Composable
private fun AdditionalSettingsPage(
    backendConfigured: Boolean,
    historyCount: Int,
    onClearHistory: () -> Unit,
    onOpenAppSettings: () -> Unit,
    onNavigate: (String) -> Unit,
    onClearCache: () -> Unit,
    onResetSettings: () -> Unit
) {
    var confirmClear by remember { mutableStateOf(false) }
    var confirmCache by remember { mutableStateOf(false) }
    var confirmReset by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(top = 12.dp, bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
        ReferencePageHeading("ADDITIONAL SETTINGS", "Manage MAXXA AI", "App information, storage and device-level settings.")
        ReferenceActionRow("ⓘ", "About MAXXA AI", "App information and version", "OPEN") { onNavigate("About") }
        ReferenceActionRow("?", "Help & Support", "Setup help and common questions", "OPEN") { onNavigate("Help & Support") }
        ReferenceActionRow("★", "Rate App", "Rating will be available after public release", "SOON") { }
        Surface(color = Color(0xEE1A0B12), shape = RoundedCornerShape(15.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x553F1B2A)), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("CONNECTION", color = Cyan, fontSize = 10.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold)
                Text(if (backendConfigured) "Secure HTTPS backend URL saved" else "Backend not configured", color = White, fontSize = 12.sp)
                Divider(color = Color(0x553D2530))
                Text("LOCAL STORAGE", color = Cyan, fontSize = 10.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold)
                Text("$historyCount messages stored on this device", color = White, fontSize = 12.sp)
                OutlinedButton(onClick = { confirmClear = true }, modifier = Modifier.fillMaxWidth()) { Text("CLEAR CHAT HISTORY") }
            }
        }
        ReferenceActionRow("▤", "Clear Cache", "Remove temporary app files", "CLEAR") { confirmCache = true }
        ReferenceActionRow("⚙", "App Permissions", "Open Android permission controls", "OPEN", onOpenAppSettings)
        ReferenceActionRow("↺", "Reset Settings", "Restore MAXXA preferences to defaults", "RESET") { confirmReset = true }
        Text("MAXXA AI • Version 1.0.0 • Development build", color = Muted, fontSize = 10.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
    }
    if (confirmClear) AlertDialog(
        onDismissRequest = { confirmClear = false },
        title = { Text("Clear chat history?") },
        text = { Text("This removes locally saved conversation messages from this device.") },
        confirmButton = { TextButton(onClick = { onClearHistory(); confirmClear = false }) { Text("Clear") } },
        dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } }
    )
    if (confirmCache) AlertDialog(
        onDismissRequest = { confirmCache = false },
        title = { Text("Clear app cache?") },
        text = { Text("Temporary cached files will be removed. Your saved conversations and settings will remain.") },
        confirmButton = { TextButton(onClick = { onClearCache(); confirmCache = false }) { Text("Clear cache") } },
        dismissButton = { TextButton(onClick = { confirmCache = false }) { Text("Cancel") } }
    )
    if (confirmReset) AlertDialog(
        onDismissRequest = { confirmReset = false },
        title = { Text("Reset MAXXA settings?") },
        text = { Text("This resets preferences and removes the saved backend URL. Chat history is not cleared.") },
        confirmButton = { TextButton(onClick = { onResetSettings(); confirmReset = false }) { Text("Reset") } },
        dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Cancel") } }
    )
}

@Composable
private fun SimplePage(title: String, body: String, label: String, value: String) {
    Column(Modifier.fillMaxWidth().padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ReferencePageHeading(title, body, "MAXXA AI • Itachi and Sakura inspired experience")
        ReferenceInfoCard(label, value)
        if (title.contains("HELP")) {
            ReferenceActionRow("?", "Frequently Asked Questions", "Backend setup, voice input and app features", "HELP") { }
            ReferenceActionRow("✉", "Contact & Support", "Support ticket integration is not configured", "INFO") { }
            ReferenceActionRow("⚑", "Report a Bug", "Share the issue with the project maintainer", "INFO") { }
        } else if (title.contains("ABOUT")) {
            ReferenceInfoCard("Built for", "Hindi • Hinglish • English\nChat • Voice • Code • Translate")
            ReferenceInfoCard("Current status", "Development build. Some features require a deployed HTTPS backend and have not been verified on a physical device.")
        }
    }
}

@Composable
private fun VoicePackPage(
    language: String,
    voiceEnabled: Boolean,
    onLanguageChange: (String) -> Unit,
    onVoiceChange: (Boolean) -> Unit,
    onPreview: (String, String) -> Unit
) {
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(top = 12.dp, bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ReferencePageHeading("VOICE PACK", "Choose MAXXA's voice", "Select a response language and preview speech.")
        listOf(
            Triple("Hindi / Hinglish", "Hindi • Hinglish", "Namaste! Main MAXXA AI hoon. Aapki kya madad karun?"),
            Triple("English", "Clear • Friendly", "Hello! I'm MAXXA AI. How can I help you today?")
        ).forEach { (name, subtitle, sample) ->
            Surface(
                color = Color(0xEE1A0B12), shape = RoundedCornerShape(17.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (language == name) Cyan else Color(0x663D2530)),
                modifier = Modifier.fillMaxWidth().clickable { onLanguageChange(name) }
            ) {
                Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).background(Color(0x33FF426D), CircleShape), contentAlignment = Alignment.Center) { Text(if (name == "English") "A" else "अ", color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                    Column(Modifier.weight(1f).padding(start = 11.dp)) {
                        Text(name, color = White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Text(subtitle, color = Muted, fontSize = 10.sp)
                    }
                    Text(if (language == name) "✓" else "○", color = Cyan, fontSize = 20.sp)
                    TextButton(onClick = { onPreview(sample, name) }) { Text("▶", color = Cyan) }
                }
            }
        }
        Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Speak AI replies", color = White, fontWeight = FontWeight.SemiBold)
                    Text("Read MAXXA's answers aloud", color = Muted, fontSize = 11.sp)
                }
                Switch(checked = voiceEnabled, onCheckedChange = onVoiceChange)
            }
        }
        ReferenceInfoCard("Voice availability", "Speech quality and available voices depend on the Text-to-Speech engine installed on your Android device.")
    }
}

@Composable
private fun ReferencePageHeading(eyebrow: String, title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(bottom = 2.dp)) {
        Text(eyebrow, color = Gold, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
        Text(title, color = White, fontSize = 21.sp, lineHeight = 26.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 6.dp))
        Text(subtitle, color = Muted, fontSize = 11.sp, lineHeight = 16.sp, modifier = Modifier.padding(top = 5.dp))
    }
}

@Composable
private fun ReferenceInfoCard(title: String, body: String) {
    Surface(
        color = Color(0xEE1A0B12), shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x663D2530)),
        modifier = Modifier.fillMaxWidth().animateContentSize()
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(title.uppercase(), color = Cyan, fontSize = 10.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold)
            Text(body, color = White, fontSize = 12.sp, lineHeight = 18.sp, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

@Composable
private fun ReferenceActionRow(icon: String, title: String, subtitle: String, action: String, onClick: () -> Unit) {
    Surface(
        color = Color(0xEE1A0B12), shape = RoundedCornerShape(15.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x553F1B2A)),
        modifier = Modifier.fillMaxWidth().animateContentSize().clickable(onClick = onClick)
    ) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(38.dp).background(Color(0x33FF426D), CircleShape), contentAlignment = Alignment.Center) {
                Text(icon, color = Color(0xFFFF9FBE), fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.weight(1f).padding(start = 11.dp)) {
                Text(title, color = White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = Muted, fontSize = 10.sp, lineHeight = 14.sp)
            }
            Text(action, color = Cyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            Text("  ›", color = White, fontSize = 19.sp)
        }
    }
}

private const val BACKEND_TOKEN_KEY_ALIAS = "maxxa_backend_access_token_v1"

private fun getBackendTokenKey(): java.security.Key {
    val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
    (keyStore.getKey(BACKEND_TOKEN_KEY_ALIAS, null) as? java.security.Key)?.let { return it }
    val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
    generator.init(KeyGenParameterSpec.Builder(
        BACKEND_TOKEN_KEY_ALIAS,
        KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
    ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
        .setRandomizedEncryptionRequired(true)
        .build())
    return generator.generateKey()
}

private fun encryptBackendToken(context: android.content.Context, token: String): String {
    if (token.isBlank()) return ""
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.ENCRYPT_MODE, getBackendTokenKey())
    val encrypted = cipher.doFinal(token.toByteArray(Charsets.UTF_8))
    val packed = cipher.iv + encrypted
    return Base64.encodeToString(packed, Base64.NO_WRAP)
}

private fun decryptBackendToken(context: android.content.Context, encoded: String): String {
    if (encoded.isBlank()) return ""
    return runCatching {
        val packed = Base64.decode(encoded, Base64.NO_WRAP)
        require(packed.size > 12)
        val iv = packed.copyOfRange(0, 12)
        val encrypted = packed.copyOfRange(12, packed.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, getBackendTokenKey(), GCMParameterSpec(128, iv))
        String(cipher.doFinal(encrypted), Charsets.UTF_8)
    }.getOrDefault("")
}

private fun isValidHttpsBackendUrl(value: String): Boolean {
    val parsed = runCatching { Uri.parse(value.trim()) }.getOrNull() ?: return false
    return parsed.scheme.equals("https", ignoreCase = true) &&
        !parsed.host.isNullOrBlank() &&
        parsed.userInfo == null &&
        parsed.query == null &&
        parsed.fragment == null
}

private fun checkBackendHealth(backendUrl: String): String {
    if (!isValidHttpsBackendUrl(backendUrl)) return "Enter a valid HTTPS backend URL with a hostname."
    var connection: HttpURLConnection? = null
    return try {
        val base = backendUrl.trim().trimEnd('/')
        connection = (URL("$base/health").openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            instanceFollowRedirects = false
            connectTimeout = 10_000
            readTimeout = 10_000
            setRequestProperty("Accept", "application/json")
        }
        val code = connection.responseCode
        val body = (if (code in 200..299) connection.inputStream else connection.errorStream)
            ?.bufferedReader()?.use { it.readText() }.orEmpty()
        val json = runCatching { JSONObject(body) }.getOrNull()
        if (code in 200..299 && json?.optBoolean("ok") == true) "✓ Backend is reachable and healthy."
        else "Backend health check failed (HTTP $code). Verify deployment and server logs."
    } catch (_: Exception) {
        "Backend is unreachable. Check the HTTPS URL, deployment and internet connection."
    } finally {
        connection?.disconnect()
    }
}

private fun requestGeneratedImage(prompt: String, backendUrl: String, aspectRatio: String, backendToken: String = ""): Pair<ByteArray, String> {
    require(isValidHttpsBackendUrl(backendUrl)) { "Configure a valid HTTPS backend URL in the API Key screen first." }
    var connection: HttpURLConnection? = null
    try {
        val base = backendUrl.trim().trimEnd('/')
        connection = (URL("$base/api/image").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            instanceFollowRedirects = false
            connectTimeout = 20_000
            readTimeout = 100_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
            if (backendToken.isNotBlank()) setRequestProperty("Authorization", "Bearer $backendToken")
        }
        val payload = JSONObject().put("prompt", prompt).put("aspectRatio", aspectRatio).toString()
        connection.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val body = (if (code in 200..299) connection.inputStream else connection.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
        val json = runCatching { JSONObject(body) }.getOrNull()
        if (code !in 200..299) throw IllegalStateException("Image backend error (HTTP $code): ${json?.optString("error").orEmpty().ifBlank { "Check model access, quota and server logs." }}")
        val encoded = json?.optString("imageBase64").orEmpty()
        if (encoded.isBlank()) throw IllegalStateException("Backend returned no image data.")
        val mime = json?.optString("mimeType").orEmpty().ifBlank { "image/png" }
        return Base64.decode(encoded, Base64.DEFAULT) to mime
    } finally { connection?.disconnect() }
}

private fun askGemini(apiKey: String, message: String, backendUrl: String = "", backendToken: String = ""): String {
    if (backendUrl.isBlank()) {
        return "No secure backend configured. Open the menu → API Key and save your deployed HTTPS backend URL."
    }
    var proxy: HttpURLConnection? = null
    return try {
        val base = backendUrl.trim().trimEnd('/')
        if (!isValidHttpsBackendUrl(base)) return "For security, enter a valid HTTPS backend URL only."
        proxy = (URL("$base/api/chat").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            instanceFollowRedirects = false
            connectTimeout = 15000
            readTimeout = 60000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
            if (backendToken.isNotBlank()) setRequestProperty("Authorization", "Bearer $backendToken")
        }
        val payload = JSONObject().put("message", message).toString()
        proxy.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
        val code = proxy.responseCode
        val body = (if (code in 200..299) proxy.inputStream else proxy.errorStream)
            ?.bufferedReader()?.use { it.readText() }.orEmpty()
        val json = runCatching { JSONObject(body) }.getOrNull()
        if (code in 200..299) {
            json?.optString("text")?.takeIf { it.isNotBlank() }
                ?: json?.optString("answer")?.takeIf { it.isNotBlank() }
                ?: "Backend returned an empty response."
        } else {
            "Backend error (HTTP $code): ${json?.optString("error").orEmpty().ifBlank { "Check backend configuration and server logs." }}"
        }
    } catch (_: Exception) {
        "Couldn't reach the secure backend. Check its HTTPS URL, deployment status and internet connection."
    } finally {
        proxy?.disconnect()
    }
}
